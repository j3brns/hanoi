# Bedrock Agent Memory Configuration Guide

## Overview

The orchestrator pattern implements **AWS Bedrock Agent Memory** to enable agents to retain conversational context across multiple sessions. This allows customers to have natural, continuous conversations with agents even when sessions are interrupted or span multiple days.

---

## What is Agent Memory?

Agent memory allows Bedrock agents to:
- **Recall previous conversations** with the same user
- **Reference past interactions** without requiring users to re-explain context
- **Provide personalized experiences** based on conversation history
- **Maintain continuity** across multiple sessions (days, weeks, or months)

### Example Use Case

**Without Memory:**
```
Session 1 (Monday 9am):
User: "Book appointment for Friday at 2pm"
Agent: "Appointment booked for Friday 2pm" ✅

Session 2 (Monday 11am - new session):
User: "Can I reschedule my appointment?"
Agent: "Which appointment would you like to reschedule?" ❌
User: "The one I just booked..."
Agent: "I don't have a record of that. Can you provide the appointment ID?"
```

**With Memory Enabled:**
```
Session 1 (Monday 9am):
User: "Book appointment for Friday at 2pm"
Agent: "Appointment booked for Friday 2pm" ✅

Session 2 (Monday 11am - new session):
User: "Can I reschedule my appointment?"
Agent: "I found your Friday 2pm appointment. What time works better?" ✅
```

---

## Current Implementation

### Memory Configuration

All agents in the orchestrator pattern have memory enabled:

| Agent | Memory Enabled | Storage Duration | Purpose |
|-------|----------------|------------------|---------|
| **Orchestrator** | ✅ Yes | 30-90 days | Maintains overall conversation flow |
| **agent_01 (appointments)** | ✅ Yes | 30-90 days | Recalls booking history |
| **agent_02 (time)** | ✅ Yes | 30-90 days | Remembers timezone preferences |
| **agent_03 (calendar)** | ✅ Yes | 30-90 days | Tracks calendar patterns |
| **agent_04 (notifications)** | ✅ Yes | 30-90 days | Recalls notification preferences |
| **agent_05 (analytics)** | ✅ Yes | 30-90 days | Remembers requested reports |

### Memory Type

- **Type:** `SESSION_SUMMARY`
- **How it works:** After each session, Bedrock generates a summary of key information (appointments booked, preferences stated, issues discussed)
- **Storage:** Summaries are stored for the configured duration (30-90 days depending on environment)
- **Retrieval:** When a user starts a new session, the agent can access summaries from previous sessions

---

## Configuration Parameters

### Terraform Variables

```hcl
# terraform/orchestrator-root/variables.tf

variable "enable_memory" {
  description = "Enable agent memory to retain conversational context across sessions"
  type        = bool
  default     = true
}

variable "memory_storage_days" {
  description = "Number of days to retain agent memory (1-365)"
  type        = number
  default     = 30
  validation {
    condition     = var.memory_storage_days >= 1 && var.memory_storage_days <= 365
    error_message = "Memory storage days must be between 1 and 365"
  }
}
```

### Environment-Specific Settings

| Environment | Storage Days | Rationale |
|-------------|--------------|-----------|
| **Dev** | 7 days | Short retention for testing, reduces costs |
| **Staging** | 30 days | Standard retention for pre-production validation |
| **Production** | 90 days | Extended retention to support customer service SLA |

### Terraform Configuration

```hcl
# In agent module (terraform/modules/orchestrator/agent/main.tf)

resource "aws_bedrockagent_agent" "collaborators" {
  # ... other configuration ...

  dynamic "memory_configuration" {
    for_each = var.enable_memory ? [1] : []
    content {
      enabled_memory_types = ["SESSION_SUMMARY"]
      storage_days        = var.memory_storage_days
    }
  }
}
```

---

## Cost Implications

### Memory Storage Pricing

**AWS Bedrock Agent Memory costs approximately:**
- **~$0.10 per 1,000 session summaries stored per month**

### Example Cost Calculation

**Scenario:** Telecommunications appointment center
- **Sessions per day:** 100 customer conversations
- **Sessions per month:** 3,000
- **Storage duration:** 90 days
- **Sessions stored:** 9,000 (3,000 × 3 months)

**Monthly cost:**
- 9,000 summaries × ($0.10 / 1,000) = **~$0.90/month** for memory

**Total orchestrator cost with memory:**
- Provisioned concurrency: $55/month
- Memory storage (6 agents × $0.90): $5.40/month
- **Total: ~$60-65/month**

---

## Model Compatibility

Memory is supported on **all foundation models EXCEPT:**
- ❌ Amazon Titan Text Premier
- ❌ Anthropic Claude Instant

**Current model:** ✅ `anthropic.claude-3-5-sonnet-20241022-v2:0` - **FULLY SUPPORTED**

---

## How to Use Memory

### For Users (API Invocation)

When invoking the agent via API, you **must** provide a `memoryId` to enable memory storage:

```python
import boto3

bedrock = boto3.client('bedrock-agent-runtime')

response = bedrock.invoke_agent(
    agentId='AGENT_ID',
    agentAliasId='ALIAS_ID',
    sessionId='unique-session-id',
    memoryId='customer-12345',  # ← Critical: Unique per user
    inputText='Can I reschedule my appointment?'
)
```

**Important:**
- Use a **consistent** `memoryId` for the same user across sessions
- Typically: `customer-{customer_id}` or `user-{user_id}`
- Different users must have different `memoryId` values
- Without `memoryId`, that conversation won't be stored in memory

### Console Testing

When testing in AWS Console:
1. Navigate to **Bedrock → Agents → [Your Agent]**
2. Click **Test** to open the test interface
3. Enable **"Use memory"** toggle
4. Provide a **Memory ID** (e.g., `test-user-123`)
5. Have multi-turn conversations across sessions

---

## When to Enable/Disable Memory

### ✅ Enable Memory If:

- **Recurring users:** Customers call back multiple times (appointments, support, etc.)
- **Multi-turn conversations:** Complex interactions spanning multiple sessions
- **Personalization:** Need to remember user preferences, history, or context
- **Customer service:** Support agents need conversation history
- **Long-running workflows:** Tasks that take days/weeks to complete

### ❌ Disable Memory If:

- **Anonymous users:** Each session is with a different, unknown user
- **Privacy requirements:** Regulations prohibit storing conversation history
- **Single-use APIs:** Each request is independent (e.g., weather lookup)
- **Cost optimization:** Minimizing infrastructure costs is critical
- **High-volume, low-value interactions:** Millions of simple, stateless queries

---

## Privacy and Compliance

### Data Retention

- Memory is stored in **AWS Bedrock managed storage**
- Configured retention period: **1-365 days**
- After expiration, summaries are **automatically deleted**

### Data Security

- ✅ Encrypted at rest
- ✅ Encrypted in transit
- ✅ Isolated per AWS account
- ✅ IAM-controlled access

### GDPR/Privacy Compliance

For right-to-erasure requests:
1. Stop using the user's `memoryId` for new sessions
2. Memory will auto-delete after retention period (30-90 days)
3. For immediate deletion, contact AWS Support

**Recommendation:** Set `memory_storage_days` to the **minimum** required for your use case.

---

## Monitoring and Observability

### CloudWatch Metrics

Monitor memory usage with CloudWatch:

```bash
# Check agent invocations with memory
aws cloudwatch get-metric-statistics \
  --namespace AWS/Bedrock \
  --metric-name AgentInvocations \
  --dimensions Name=AgentId,Value=YOUR_AGENT_ID \
  --start-time 2026-01-01T00:00:00Z \
  --end-time 2026-01-11T00:00:00Z \
  --period 86400 \
  --statistics Sum
```

### X-Ray Tracing

Memory retrieval is traced in AWS X-Ray:
- View memory lookup latency
- Debug memory access issues
- Optimize session summarization

---

## Troubleshooting

### Memory Not Working?

**Checklist:**
1. ✅ Is `enable_memory = true` in your tfvars?
2. ✅ Did you run `terraform apply` after enabling memory?
3. ✅ Are you providing a `memoryId` when invoking the agent?
4. ✅ Is the `memoryId` consistent across sessions for the same user?
5. ✅ Is your model compatible? (Claude 3.5 Sonnet = ✅)
6. ✅ Has enough time passed for memory to accumulate? (Try multiple sessions)

### Memory Contains Wrong Information

- Memory is based on **session summaries** generated by the LLM
- If incorrect info was discussed, it may be stored
- **Solution:** Start a new `memoryId` for that user or wait for retention period to expire

### Memory Retrieval Slow

- Memory lookup adds ~50-100ms latency to first request in session
- Use **provisioned concurrency** (already enabled) to minimize impact
- Reduce `memory_storage_days` if too many summaries are stored

---

## Configuration Examples

### Development (Cost-Optimized)
```hcl
# environments/dev.tfvars
enable_memory        = true
memory_storage_days = 7  # One week retention
```

### Staging (Standard Testing)
```hcl
# environments/staging.tfvars
enable_memory        = true
memory_storage_days = 30  # One month retention
```

### Production (Customer Service SLA)
```hcl
# environments/prod.tfvars
enable_memory        = true
memory_storage_days = 90  # Three months retention
```

### Disable Memory Completely
```hcl
# Any environment
enable_memory = false
# memory_storage_days is ignored when disabled
```

---

## References

- [AWS Bedrock Agent Memory Documentation](https://docs.aws.amazon.com/bedrock/latest/userguide/agents-memory.html)
- [Enable Agent Memory](https://docs.aws.amazon.com/bedrock/latest/userguide/agents-configure-memory.html)
- [Terraform aws_bedrockagent_agent Resource](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/bedrockagent_agent)
- [AWS Bedrock Pricing](https://aws.amazon.com/bedrock/pricing/)

---

## Summary

✅ **Memory is ENABLED by default** in all environments
- Dev: 7 days retention
- Staging: 30 days retention
- Production: 90 days retention

✅ **Cost impact: ~$5-10/month** for typical usage

✅ **Use case alignment:** Perfect for telecommunications appointment orchestrator where customers call back to reschedule, cancel, or inquire about appointments

✅ **Privacy compliant:** Auto-deletion after retention period, encrypted storage

For questions or issues, consult the AWS Bedrock documentation or open an issue in this repository.
