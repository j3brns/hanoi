# Bedrock Agents Orchestrator Pattern - Deployment Guide

## Overview

This guide covers the deployment of a production-ready Bedrock Agents Orchestrator pattern with five specialized collaborator agents and a central orchestrator controller.

## Architecture

### Three-Tier Module Pattern

The deployment follows a strict separation of concerns across three tiers:

```
┌─────────────────────────────────────────────────────────────────┐
│                    TIER 3: ORCHESTRATION                        │
│  (Agent Anna / MLE Alice)                                       │
│  ┌──────────────┐  ┌────────────────────────────────────────┐  │
│  │ Orchestrator │──│ 5 Collaborator Agents                  │  │
│  │   Agent      │  │ - Appointments (API)                   │  │
│  │              │  │ - Time Management (Python)             │  │
│  │  + Prepare   │  │ - Calendar Operations (Python)         │  │
│  │  + Alias     │  │ - Notifications (Python)               │  │
│  │              │  │ - Analytics (Python)                   │  │
│  └──────────────┘  └────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                   TIER 2: ACTION GROUPS                         │
│  (MLE Alice / Dev Bob)                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────────┐   │
│  │  Lambda      │  │  OpenAPI     │  │  Lambda            │   │
│  │  Functions   │  │  Schemas     │  │  Permissions       │   │
│  │  (5 total)   │  │  (S3)        │  │  (Bedrock invoke)  │   │
│  └──────────────┘  └──────────────┘  └────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────────────────────────────────────────┐
│                    TIER 1: SECURITY & IAM                       │
│  (SecOps Serena / Infra Dan)                                    │
│  ┌──────────────┐  ┌──────────────┐  ┌────────────────────┐   │
│  │  IAM Roles   │  │  KMS Keys    │  │  Trust Policies    │   │
│  │  (6 agents)  │  │  (Session)   │  │  (Confused Deputy) │   │
│  └──────────────┘  └──────────────┘  └────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### Agent Responsibilities

| Agent | Type | Purpose | Action Groups |
|-------|------|---------|---------------|
| **Orchestrator** | Controller | Routes requests to specialized agents | None (agent collaboration) |
| **agent_01_appointments** | API | Manages appointments via external API | appointments_api |
| **agent_02_time** | Python | Time management and validation | time_management |
| **agent_03_calendar** | Python | Calendar operations | calendar_ops |
| **agent_04_notifications** | Python | Multi-channel notifications | notifications |
| **agent_05_analytics** | Python | Insights and reporting | analytics |

## Deployment Steps

### Prerequisites

1. **AWS Account** with Bedrock access enabled
2. **Terraform** >= 1.5.0
3. **AWS CLI** configured with appropriate credentials
4. **Python 3.11+** for Lambda function packaging
5. **Bedrock Model Access**: Ensure `anthropic.claude-3-5-sonnet-20241022-v2:0` is enabled

### Step 1: Configure Environment

Choose your environment and configure variables:

```bash
cd terraform/orchestrator-root

# For Development
export ENV=dev
export TFVARS_FILE=environments/dev.tfvars

# For Staging
export ENV=staging
export TFVARS_FILE=environments/staging.tfvars

# For Production
export ENV=prod
export TFVARS_FILE=environments/prod.tfvars
```

### Step 2: Review Configuration

Edit the environment-specific `.tfvars` file:

```hcl
# environments/prod.tfvars
project_name = "bedrock-orchestrator"
environment  = "prod"

foundation_model_id = "anthropic.claude-3-5-sonnet-20241022-v2:0"
enable_guardrails   = true
guardrail_id        = "YOUR_GUARDRAIL_ID"  # Set this!
```

### Step 3: Initialize Terraform

```bash
terraform init
```

### Step 4: Plan Deployment

```bash
terraform plan -var-file=$TFVARS_FILE -out=tfplan
```

Review the plan carefully. You should see:
- **6 Bedrock Agents** (1 orchestrator + 5 collaborators)
- **5 Lambda functions** (action handlers)
- **6 IAM roles** (one per agent)
- **1 KMS key** (session state encryption)
- **6 Agent Aliases** (environment alias per agent)
- **Prepare associations** for all agents

Note: Only the `appointments_api` and `time_management` OpenAPI schemas are present in
`src/orchestrator/action_handlers/` today. Add schemas for the other action groups before
enabling them in production.

### Step 5: Apply Configuration

```bash
terraform apply tfplan
```

This will:
1. **Tier 1**: Create IAM roles and KMS keys (30-60 seconds)
2. **Tier 2**: Deploy Lambda functions and upload schemas (60-90 seconds)
3. **Tier 3**: Create agents, prepare them, and set up aliases (120-180 seconds)

Total deployment time: **3-5 minutes**

### Step 6: Verify Deployment

```bash
# Get orchestrator alias ARN
terraform output -json orchestration_outputs | jq -r '.orchestrator_alias_arn'

# Test orchestrator invocation (requires AWS CLI)
aws bedrock-agent-runtime invoke-agent \
  --agent-id $(terraform output -json orchestration_outputs | jq -r '.orchestrator_agent_id') \
  --agent-alias-id $(terraform output -json orchestration_outputs | jq -r '.orchestrator_alias_id') \
  --session-id "test-session-001" \
  --input-text "List my appointments" \
  output.txt
```

## Deployment Model

The orchestrator stack uses a single environment alias per agent (`dev`, `staging`, `prod`).
Each `terraform apply` prepares a new agent version and repoints the alias to that version.
There is no weighted or blue/green aliasing in this module today; introduce additional aliases
or a separate promotion pipeline if you need staged rollouts.

## Managing the "Prepare" Lifecycle

### The Prepare Trap (CRITICAL)

⚠️ **Without `aws_bedrockagent_agent_agent_version`, your changes will NOT be live!**

The Bedrock Agent API has a hidden "Prepare" step:
1. `UpdateAgent` → Changes exist as "Working Draft"
2. **`PrepareAgent`** → Creates a versioned snapshot (this is what we deploy!)
3. `UpdateAlias` → Points alias to prepared version

Our implementation uses `aws_bedrockagent_agent_agent_version` which triggers `PrepareAgent` automatically.

### Version Lifecycle

```
Working Draft → Prepare → Version 1 → Alias "prod" → Traffic
```

Every `terraform apply`:
1. Updates the Working Draft
2. Triggers Prepare (via `aws_bedrockagent_agent_agent_version`)
3. Creates new version (auto-incremented: 1, 2, 3...)
4. Updates alias to point to new version

### Rollback Procedure

To rollback, revert the Terraform inputs (or git commit) that produced the undesired agent version
and re-apply. The environment alias always points to the latest prepared version.

```bash
# Example: revert the last change and re-apply
git revert HEAD
cd terraform/orchestrator-root
terraform apply -var-file=environments/prod.tfvars
```

## Monitoring and Validation

### CloudWatch Logs

Each Lambda function has its own log group:

```bash
/aws/lambda/bedrock-orchestrator-appointments_api
/aws/lambda/bedrock-orchestrator-time_management
/aws/lambda/bedrock-orchestrator-calendar_ops
/aws/lambda/bedrock-orchestrator-notifications
/aws/lambda/bedrock-orchestrator-analytics
```

### Key Metrics to Monitor

1. **Agent Invocations**: `aws/bedrock/agent/invocations`
2. **Action Group Errors**: Lambda error metrics
3. **Latency**: p50, p99 latency for agent responses
4. **Throttling**: Check for throttled requests

### Testing the Orchestrator

```python
import boto3
import json

client = boto3.client('bedrock-agent-runtime')

response = client.invoke_agent(
    agentId='YOUR_AGENT_ID',
    agentAliasId='YOUR_ALIAS_ID',
    sessionId='test-session',
    inputText='I need to book a repair appointment for tomorrow at 2 PM'
)

# Stream response
for event in response['completion']:
    if 'chunk' in event:
        print(event['chunk']['bytes'].decode('utf-8'))
```

## Cost Optimization

### Development Environment
- **Log Retention**: 7 days
- **KMS Deletion**: 7 days (minimum)
- **No Lambda Layer**: Faster iteration
- **Estimated Monthly Cost**: $50-100

### Production Environment
- **Log Retention**: 90 days
- **KMS Deletion**: 30 days (maximum)
- **Lambda Layer**: Code reuse
- **Estimated Monthly Cost**: $200-500 (depending on usage)

**Cost Breakdown:**
- Bedrock Agent Invocations: $0.002 per 1K tokens
- Lambda Invocations: $0.20 per 1M requests
- CloudWatch Logs: $0.50/GB ingested
- S3 Storage (schemas): Negligible
- KMS: $1/month per key

## Troubleshooting

### Issue: "Agent not found"
**Cause**: Alias not pointing to prepared version
**Solution**: Check `aws_bedrockagent_agent_agent_version` resource exists

### Issue: "Permission denied calling Lambda"
**Cause**: Missing `aws_lambda_permission` for Bedrock
**Solution**: Verify resource-based policy allows `bedrock.amazonaws.com`

### Issue: "Action group schema not found"
**Cause**: S3 object not uploaded or incorrect path
**Solution**: Check `aws_s3_object` resources and bucket name

### Issue: Changes not appearing
**Cause**: Prepare step not triggered
**Solution**: Ensure `depends_on` chains are correct: `agent → action_groups → agent_version → alias`

## Security Best Practices

1. **IAM Least Privilege**: Each agent has unique role with minimal permissions
2. **Confused Deputy Prevention**: Trust policies include `SourceAccount` condition
3. **KMS Encryption**: Agent session state encrypted at rest
4. **Guardrails**: Enable in staging/prod for content filtering
5. **Secrets Management**: Use AWS Secrets Manager for API keys (agent_01)

## Maintenance

### Updating Agent Instructions

1. Edit prompt file: `terraform/modules/orchestrator/agent/prompts/agent_01_appointments.txt`
2. Run `terraform apply -var-file=environments/dev.tfvars -target=module.agent`
3. New version automatically created and deployed via the environment alias

### Updating Lambda Functions

1. Edit handler: `src/orchestrator/action_handlers/agent_02_time/handler.py`
2. Run `terraform apply -var-file=environments/dev.tfvars -target=module.action_groups`
3. Lambda updated (agent action groups reference the function ARN directly)

### Updating OpenAPI Schemas

1. Edit schema: `src/orchestrator/action_handlers/appointments_api/openapi_schema.json`
2. Run `terraform apply -var-file=environments/dev.tfvars -target=module.action_groups`
3. S3 object updated (new etag). To propagate schema changes to Bedrock, trigger a new
   agent version (for example by updating the schema object key in the agent module or
   recreating the agent version resource).

## CI/CD Integration

### GitLab CI Example

```yaml
deploy-orchestrator:
  stage: deploy
  script:
    - cd terraform/orchestrator-root
    - terraform init
    - terraform plan -var-file=environments/${ENV}.tfvars -out=tfplan
    - terraform apply tfplan
  only:
    - main
  environment:
    name: production
```

### Staged Rollouts

This module does not define weighted aliases for canary rollouts. If you need staged traffic
shifts, introduce additional aliases or a separate promotion pipeline.

## Support

For issues or questions:
- Check CloudWatch Logs for Lambda errors
- Review Terraform state: `terraform show`
- Verify IAM permissions: `aws sts get-caller-identity`
- Test individual agents via AWS Console

## Next Steps

1. **Implement Guardrails**: Create content filtering policies
2. **Add Monitoring**: Set up CloudWatch alarms for errors/latency
3. **Create Tests**: Build integration tests for each agent
4. **Document APIs**: Generate API documentation from OpenAPI schemas
5. **Optimize Costs**: Implement Lambda reserved concurrency based on usage patterns

---

**Version**: 1.0.0
**Last Updated**: 2026-01-10
**Maintained By**: Platform Engineering Team
