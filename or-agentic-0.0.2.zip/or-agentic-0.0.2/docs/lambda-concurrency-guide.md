# Lambda Concurrency Configuration Guide

## Overview

The orchestrator pattern implements **provisioned concurrency = 1** for all Lambda functions. This keeps one warm instance per function to eliminate cold starts without requiring Lambda alias updates to adjust concurrency.

---

## Reserved vs Provisioned Concurrency

### Provisioned Concurrency (IMPLEMENTED ✓)

**Current Configuration:** `provisioned_concurrency = 1` per function

**What it does:**
- Pre-warms Lambda instances to eliminate cold starts
- Keeps 1 warm instance per function always ready
- Reduces latency to <100ms consistently
- No Lambda alias updates needed to adjust concurrency

**Cost:** ~$0.015/hr per provisioned instance

**Monthly cost for this pattern:**
- 5 functions × 1 instance each × 730 hours × $0.015 = **~$55/month**

**Why provisioned_concurrency = 1:**
- Eliminates cold starts for first invocation of each function
- Minimal cost impact compared to running multiple warm instances
- Provides consistent low-latency response for agent orchestration
- Simple configuration without alias management overhead

---

### Reserved Concurrency (Alternative Approach)

**What it does:**
- Guarantees a specific number of concurrent executions for your function
- Prevents other functions from consuming all account concurrency
- Limits the function's maximum concurrency

**Cost:** **FREE** (just reserves capacity from your account pool)

**When to consider instead of provisioned:**
- Need to prevent runaway scaling
- Guarantee capacity but cold starts are acceptable
- Cost-sensitive deployments

**Note:** This pattern uses provisioned concurrency = 1, but you can switch to reserved concurrency by changing the variable configuration.

---

## Current Configuration (All Environments)

### Development, Staging, and Production
```hcl
# terraform/orchestrator-root/environments/{env}.tfvars
provisioned_concurrency = 1
```

**Benefits:**
- ✅ Eliminates cold starts for all environments
- ✅ Consistent performance across dev/staging/prod
- ✅ Simple configuration without per-environment tuning
- ✅ No alias management required to adjust concurrency
- ✅ Minimal cost (~$55/month total across 5 functions)

**Alternative (Cost Optimization):**
If you want to disable provisioned concurrency (e.g., in dev):
```hcl
provisioned_concurrency = null  # Disables provisioned concurrency
```

---

## AWS Account Concurrency Limits

**Default account limits:**
- **Unreserved concurrency pool:** 1,000 (can request increase)
- **Provisioned concurrency:** No hard limit (pay per instance)

**Orchestrator impact:**
- 5 functions × 1 provisioned instance = 5 warm instances
- Minimal impact on account concurrency limits ✅

---

## Monitoring

### CloudWatch Metrics to Watch

```bash
# Check concurrent executions
aws cloudwatch get-metric-statistics \
  --namespace AWS/Lambda \
  --metric-name ConcurrentExecutions \
  --dimensions Name=FunctionName,Value=bedrock-orchestrator-appointments_api \
  --start-time 2026-01-10T00:00:00Z \
  --end-time 2026-01-11T00:00:00Z \
  --period 3600 \
  --statistics Maximum
```

### Key Metrics

| Metric | Threshold | Action |
|--------|-----------|--------|
| `ProvisionedConcurrencyInvocations` | Monitor usage | Ensure provisioned instances are being used |
| `ProvisionedConcurrencySpilloverInvocations` | > 10% | Consider increasing provisioned_concurrency |
| `ConcurrentExecutions` | Monitor trends | Understand scaling patterns |
| `Throttles` | > 0 | Investigate capacity issues |

---

## Cold Start Behavior

### Without Provisioned Concurrency
```
Request arrives → Initialize runtime → Load code → Execute
Total latency: 500ms-2s (cold start) + execution time
```

### With Provisioned Concurrency = 1
```
Request arrives → Execute (warm instance already ready)
Total latency: <100ms + execution time ✅
```

**Spillover:** If concurrent requests exceed 1, additional instances spin up (may cold start)

---

## Cost Comparison

### Scenario: 5 Lambda functions in orchestrator pattern

| Configuration | Monthly Cost | Cold Starts | Latency |
|---------------|--------------|-------------|---------|
| **Unreserved** | $0 (baseline) | Yes (500ms-2s) | Variable |
| **Reserved (20 per function)** | $0 (FREE) | Yes (500ms-2s) | Variable |
| **Provisioned (1 per function)** | ~$55/month | No | <100ms ✅ |
| **Provisioned (10 per function)** | ~$547/month | No | <100ms |

**Current Configuration:** Provisioned concurrency = 1 provides optimal cost/performance balance.

---

## When to Increase Provisioned Concurrency

**Symptoms:**
- High `ProvisionedConcurrencySpilloverInvocations` (requests exceeding warm instances)
- Cold starts observed despite provisioned concurrency
- Multiple concurrent requests causing variable latency

**Action:**
```hcl
# Increase provisioned concurrency
provisioned_concurrency = 3  # Was 1, now 3 warm instances per function
```

**Cost impact:**
- 5 functions × 3 instances × 730hr × $0.015 = ~$164/month (up from $55)

**When to decrease:**
- Spillover invocations consistently low (<5%)
- Cost optimization needed
- Traffic patterns reduced

---

## Alternative: Burst Scaling

If you don't want to reserve capacity, Lambda has built-in burst scaling:

**Burst limits:**
- **Initial burst:** 3,000 concurrent executions
- **After burst:** +500 per minute scaling

**This means:**
- 0 → 3,000 concurrent: Instant
- 3,000 → 3,500: 1 minute
- 3,500 → 4,000: 1 minute

For most workloads, this is sufficient without reserved concurrency.

---

## Summary

✅ **Current Implementation: Provisioned Concurrency = 1**
- Eliminates cold starts for all agent action handlers
- Minimal cost (~$55/month for 5 functions)
- No Lambda alias management required
- Consistent low-latency performance across all environments

**When to Consider Alternatives:**

💰 **Switch to Unreserved (Cost Optimization):**
- Set `provisioned_concurrency = null`
- Saves $55/month but accepts cold starts
- Good for dev environments or non-critical workloads

📈 **Increase to Higher Provisioned (Performance):**
- Set `provisioned_concurrency = 3` or higher
- Handles multiple concurrent requests without spillover
- Costs ~$33/month per additional instance per function

🔒 **Switch to Reserved Concurrency (Capacity Management):**
- FREE but doesn't eliminate cold starts
- Good for preventing throttling without cost
- Use when cold starts are acceptable

---

## Configuration Examples

### Current Implementation (Recommended)
```hcl
provisioned_concurrency = 1  # One warm instance per function
```
**Best for:** Production workloads requiring consistent low latency

### High Performance (More Warm Instances)
```hcl
provisioned_concurrency = 5  # Five warm instances per function
```
**Cost:** ~$274/month (5 functions × 5 instances × 730hr × $0.015)
**Best for:** High-throughput workloads with many concurrent requests

### Cost Optimized (No Provisioned Concurrency)
```hcl
provisioned_concurrency = null  # Disabled, cold starts may occur
```
**Best for:** Development environments or cost-sensitive deployments

---

## References

- [AWS Lambda Concurrency](https://docs.aws.amazon.com/lambda/latest/dg/configuration-concurrency.html)
- [Reserved vs Provisioned Concurrency](https://docs.aws.amazon.com/lambda/latest/dg/provisioned-concurrency.html)
- [Lambda Pricing](https://aws.amazon.com/lambda/pricing/)
