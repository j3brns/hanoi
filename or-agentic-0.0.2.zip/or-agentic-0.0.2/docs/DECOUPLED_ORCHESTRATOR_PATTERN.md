# Decoupled Orchestrator Pattern

## Overview

This document describes the recommended **infrastructure + agents decoupled** pattern for the Bedrock orchestrator. In this repository, the orchestration stack lives under `terraform/orchestrator-root` and is composed of the `modules/orchestrator/*` tiers. A split can be achieved by running targeted Terraform applies against those tiers.

## Key Principle

> **Infrastructure is static. Agent configuration is dynamic.**
> Deploy them independently. Coordinate only when the action group Lambda surface changes.

---

## Architecture

### Two-Pipeline Approach

```
┌─────────────────────────────────────────────────────────────────┐
│ PIPELINE 1: INFRASTRUCTURE (Deploy Rarely)                      │
│  Triggered by: Lambda code changes, IAM updates, schema breaks  │
│  Deployment: Weeks/Months                                        │
├─────────────────────────────────────────────────────────────────┤
│  • Lambda functions (5 action handlers)                         │
│  • IAM execution roles (6 agents)                               │
│  • S3 buckets for schemas                                       │
│  • KMS keys for encryption                                      │
│  • Base Bedrock Agent resources (empty agents)                  │
└─────────────────────────────────────────────────────────────────┘
                            ↓ (provides action group outputs)
┌─────────────────────────────────────────────────────────────────┐
│ PIPELINE 2: AGENT CONFIGURATION (Deploy Frequently)             │
│  Triggered by: Prompt changes, schema tweaks                    │
│  Deployment: Days/Hours                                          │
├─────────────────────────────────────────────────────────────────┤
│  • Agent instructions (system prompts)                          │
│  • Action group definitions + OpenAPI schemas                   │
│  • Agent prepare + versioning                                   │
│  • Aliases (environment-specific)                               │
└─────────────────────────────────────────────────────────────────┘
```

---

## Directory Structure (Current Repo)

```
terraform/
├── orchestrator-root/               # Root module (tiers 1–3)
│   ├── main.tf                      # Wires security, action_groups, agent
│   ├── variables.tf
│   └── environments/
│       ├── dev.tfvars
│       ├── staging.tfvars
│       └── prod.tfvars
│
└── modules/orchestrator/            # Tiered modules
    ├── security/                    # Tier 1: IAM/KMS
    ├── action_groups/               # Tier 2: Lambdas + schemas
    └── agent/                       # Tier 3: agents + aliases
```

---

## Deployment Workflows

### Infrastructure Deployment (Rare)

**Triggers:**
- Lambda function signature changes
- New action group added/removed
- Breaking schema changes
- IAM policy updates

**Process:**
```bash
cd terraform/orchestrator-root

# Deploy Tier 1 + Tier 2 only (security + action groups)
terraform apply -var-file=environments/dev.tfvars \
  -target=module.security \
  -target=module.action_groups

# Outputs: action_groups_outputs, security_outputs
# Save these to SSM Parameter Store or Terraform state if decoupling pipelines

# Agent teams can now iterate independently!
```

**Frequency:** Weeks to months

---

### Agent Configuration Deployment (Frequent)

**Triggers:**
- Prompt/instruction updates
- Schema tweaks (non-breaking)

**Process:**
```bash
cd terraform/orchestrator-root

# Deploy Tier 3 only (agent config + prepare + aliases)
terraform apply -var-file=environments/dev.tfvars \
  -target=module.agent

# This triggers:
# 1. Agent updates in working draft
# 2. Agent prepare/versioning
# 3. Alias updates
```

**Frequency:** Daily to weekly

---

## Configuration Variables

### Shared Configuration (orchestrator-root)

```hcl
# environments/dev.tfvars
project_name = "bedrock-orchestrator"
environment  = "dev"

# Lambda configuration (tiers 1–2)
lambda_runtime     = "python3.11"
log_retention_days = 7
log_level          = "DEBUG"
create_lambda_layer = false

# Bedrock + guardrails (tier 3)
foundation_model_id = "anthropic.claude-3-5-sonnet-20241022-v2:0"
enable_guardrails   = false
enable_memory       = true
memory_storage_days = 7
```

---

## Realistic OpenAPI Schemas

### Example: Appointments API v1.2.0

```json
{
  "openapi": "3.0.0",
  "info": {
    "title": "Appointment Management API",
    "version": "1.2.0",
    "description": "Telecommunications service appointment management"
  },
  "servers": [
    {
      "url": "https://api.example.com/v1",
      "description": "Production"
    }
  ],
  "paths": {
    "/appointments": {
      "get": {
        "operationId": "listAppointments",
        "summary": "List appointments",
        "description": "Retrieve paginated list of appointments with filtering",
        "parameters": [
          {
            "name": "customer_id",
            "in": "query",
            "required": false,
            "schema": { "type": "string", "pattern": "^CUST-[0-9]{6}$" }
          },
          {
            "name": "status",
            "in": "query",
            "schema": {
              "type": "string",
              "enum": ["scheduled", "in_progress", "completed", "cancelled"]
            }
          },
          {
            "name": "date_from",
            "in": "query",
            "schema": { "type": "string", "format": "date" }
          },
          {
            "name": "date_to",
            "in": "query",
            "schema": { "type": "string", "format": "date" }
          },
          {
            "name": "page",
            "in": "query",
            "schema": { "type": "integer", "minimum": 1, "default": 1 }
          },
          {
            "name": "page_size",
            "in": "query",
            "schema": { "type": "integer", "minimum": 10, "maximum": 100, "default": 20 }
          }
        ],
        "responses": {
          "200": {
            "description": "Successful response",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "data": {
                      "type": "array",
                      "items": { "$ref": "#/components/schemas/Appointment" }
                    },
                    "pagination": { "$ref": "#/components/schemas/Pagination" }
                  }
                }
              }
            }
          },
          "400": {
            "description": "Invalid request parameters",
            "content": {
              "application/json": {
                "schema": { "$ref": "#/components/schemas/Error" }
              }
            }
          },
          "429": {
            "description": "Rate limit exceeded",
            "headers": {
              "X-RateLimit-Limit": {
                "schema": { "type": "integer" }
              },
              "X-RateLimit-Remaining": {
                "schema": { "type": "integer" }
              }
            }
          }
        }
      },
      "post": {
        "operationId": "createAppointment",
        "summary": "Create appointment",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "required": ["customer_id", "slot_id", "service_type"],
                "properties": {
                  "customer_id": {
                    "type": "string",
                    "pattern": "^CUST-[0-9]{6}$"
                  },
                  "slot_id": {
                    "type": "string",
                    "pattern": "^SLOT-[0-9]{8}-[0-9]{2}$"
                  },
                  "service_type": {
                    "type": "string",
                    "enum": ["installation", "repair", "upgrade", "maintenance"]
                  },
                  "priority": {
                    "type": "string",
                    "enum": ["low", "normal", "high", "urgent"],
                    "default": "normal"
                  },
                  "notes": {
                    "type": "string",
                    "maxLength": 500
                  },
                  "contact_phone": {
                    "type": "string",
                    "pattern": "^\\+?[1-9]\\d{1,14}$"
                  },
                  "equipment_ids": {
                    "type": "array",
                    "items": { "type": "string" },
                    "maxItems": 10
                  }
                }
              }
            }
          }
        },
        "responses": {
          "201": {
            "description": "Appointment created",
            "content": {
              "application/json": {
                "schema": { "$ref": "#/components/schemas/Appointment" }
              }
            }
          },
          "409": {
            "description": "Slot no longer available",
            "content": {
              "application/json": {
                "schema": {
                  "allOf": [
                    { "$ref": "#/components/schemas/Error" },
                    {
                      "type": "object",
                      "properties": {
                        "alternative_slots": {
                          "type": "array",
                          "items": { "$ref": "#/components/schemas/TimeSlot" }
                        }
                      }
                    }
                  ]
                }
              }
            }
          }
        }
      }
    }
  },
  "components": {
    "schemas": {
      "Appointment": {
        "type": "object",
        "required": ["appointment_id", "customer_id", "slot_id", "service_type", "status"],
        "properties": {
          "appointment_id": {
            "type": "string",
            "pattern": "^APT-[0-9]{8}$"
          },
          "customer_id": { "type": "string" },
          "slot_id": { "type": "string" },
          "service_type": {
            "type": "string",
            "enum": ["installation", "repair", "upgrade", "maintenance"]
          },
          "status": {
            "type": "string",
            "enum": ["scheduled", "in_progress", "completed", "cancelled"]
          },
          "technician_id": { "type": "string" },
          "scheduled_start": {
            "type": "string",
            "format": "date-time"
          },
          "scheduled_end": {
            "type": "string",
            "format": "date-time"
          },
          "actual_start": {
            "type": "string",
            "format": "date-time"
          },
          "actual_end": {
            "type": "string",
            "format": "date-time"
          },
          "notes": { "type": "string" },
          "created_at": {
            "type": "string",
            "format": "date-time"
          },
          "updated_at": {
            "type": "string",
            "format": "date-time"
          }
        }
      },
      "TimeSlot": {
        "type": "object",
        "properties": {
          "slot_id": { "type": "string" },
          "start_time": { "type": "string", "format": "date-time" },
          "end_time": { "type": "string", "format": "date-time" },
          "available": { "type": "boolean" },
          "technician_id": { "type": "string" }
        }
      },
      "Pagination": {
        "type": "object",
        "properties": {
          "page": { "type": "integer" },
          "page_size": { "type": "integer" },
          "total_pages": { "type": "integer" },
          "total_items": { "type": "integer" }
        }
      },
      "Error": {
        "type": "object",
        "required": ["error_code", "message"],
        "properties": {
          "error_code": {
            "type": "string",
            "enum": [
              "INVALID_REQUEST",
              "RESOURCE_NOT_FOUND",
              "SLOT_UNAVAILABLE",
              "RATE_LIMIT_EXCEEDED",
              "INTERNAL_ERROR"
            ]
          },
          "message": { "type": "string" },
          "details": {
            "type": "object",
            "additionalProperties": true
          },
          "request_id": { "type": "string" }
        }
      }
    },
    "securitySchemes": {
      "ApiKeyAuth": {
        "type": "apiKey",
        "in": "header",
        "name": "X-API-Key"
      }
    }
  },
  "security": [
    { "ApiKeyAuth": [] }
  ]
}
```

---

## Deployment Model in This Repo

- **Aliases**: Environment-specific aliases (`dev`, `staging`, `prod`) are created for each agent and always point to the latest prepared version.
- **Decoupling**: Use targeted applies in `terraform/orchestrator-root` to split infra changes from agent config updates.

---

## Coordinated Release (When Lambda Changes)

**Scenario:** Add a new parameter to the appointments action group.

### Step 1: Deploy Tier 2 (Lambda + Schema)

```bash
cd terraform/orchestrator-root

# Update action handler: src/orchestrator/action_handlers/appointments_api/handler.py
# Update schema: src/orchestrator/action_handlers/appointments_api/openapi_schema.json

terraform apply -var-file=environments/dev.tfvars \
  -target=module.action_groups
```

### Step 2: Deploy Tier 3 (Agents + Prepare)

```bash
terraform apply -var-file=environments/dev.tfvars \
  -target=module.agent
```

### Step 3: Verify

```bash
aws bedrock-agent-runtime invoke-agent \
  --agent-id $(terraform output -json orchestration_outputs | jq -r '.orchestrator_agent_id') \
  --agent-alias-id $(terraform output -json orchestration_outputs | jq -r '.orchestrator_alias_id') \
  --session-id "test-session-001" \
  --input-text "List my appointments" \
  output.txt
```

---

## Benefits of Decoupled Pattern

| Aspect | Benefit |
|--------|---------|
| **Agent Team Velocity** | Deploy prompts/schemas daily without infra changes |
| **Infrastructure Stability** | Lambdas/IAM rarely touched, reducing risk |
| **Testing** | Validate in dev/staging before production apply |
| **Rollback** | Revert changes and re-apply to restore prior version |
| **Version Control** | Clear versioning of instructions vs infrastructure |
| **Cost** | No duplicate infrastructure for staged validation |
| **Compliance** | Clear separation of concerns for audits |

---

## Monitoring & Observability

- **CloudWatch Logs**: `/aws/lambda/${project_name}-<action_group>`
- **X-Ray**: Enabled in action group Lambdas via Terraform
- **Key metrics**: Lambda errors, throttles, duration, and Bedrock agent errors

---

## Recommended Workflow

### Daily Agent Updates

```bash
# Update prompts
edit: terraform/modules/orchestrator/agent/prompts/orchestrator.txt

# Apply Tier 3 only
cd terraform/orchestrator-root
terraform apply -var-file=environments/dev.tfvars -target=module.agent
```

### Monthly Infrastructure Updates

```bash
# Update Lambda code
edit: src/orchestrator/action_handlers/agent_02_time/handler.py

# Apply Tier 1 + Tier 2
cd terraform/orchestrator-root
terraform apply -var-file=environments/dev.tfvars \
  -target=module.security \
  -target=module.action_groups
```

---

## Migration from Monolithic to Decoupled

Use the same `terraform/orchestrator-root` state and split CI pipelines by target:

1. **Infra pipeline**: `-target=module.security -target=module.action_groups`
2. **Agent pipeline**: `-target=module.agent`

This keeps outputs in one state file while allowing separate deployment cadence.

---

## Summary

**This decoupled pattern enables:**

✅ **Fast agent iteration** - Deploy prompts/schemas in minutes, not hours
✅ **Stable infrastructure** - Touch Lambdas/IAM only when absolutely necessary
✅ **Safe deployments** - Environment aliases updated on each apply
✅ **Version control** - Clear separation of instruction vs infra versions
✅ **Feature flags** - Gradual rollout of new capabilities
✅ **Coordinated releases** - Explicit process when Lambda surface changes

**Following this pattern, agent teams can ship daily while maintaining production stability.**
