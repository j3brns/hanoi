# AWS API Gateway REST streaming notes (responseTransferMode: STREAM)

This note captures the November 2025 REST API streaming behavior summary
needed for local citation, including integration requirements and streaming
constraints.

## Configuration requirements (REST API)

- Integration type must be `AWS_PROXY`.
- Set `ResponseTransferMode` to `STREAM`.
- Use the response streaming invocation path:
  - Standard: `.../functions/FUNCTION_ARN/invocations`
  - Streaming: `.../functions/FUNCTION_ARN/response-streaming-invocations`
- Increase `timeoutInMillis` up to `900000` (15 minutes).

CloudFormation example:

```yaml
MyMethod:
  Type: AWS::ApiGateway::Method
  Properties:
    Integration:
      Type: AWS_PROXY
      IntegrationHttpMethod: POST
      ResponseTransferMode: STREAM
      Uri: !Sub "arn:aws:apigateway:${AWS::Region}:lambda:path/2021-11-15/functions/${MyLambda.Arn}/response-streaming-invocations"
```

## Lambda handler implementation (Python)

As of late 2025, the managed Python runtime does not provide a native
`streamifyResponse` equivalent. The common implementation uses the AWS Lambda
Web Adapter (LWA) with `AWS_LWA_INVOKE_MODE=RESPONSE_STREAM` and a framework
streaming response (e.g., FastAPI `StreamingResponse`).

## Implementation constraints

- Idle timeouts still apply. Regional/Private endpoints allow 5 minutes of
  silence; Edge-optimized endpoints remain capped at 30 seconds.
- Enabling STREAM disables features that require buffering (VTL response
  transformations, response caching, and content encoding).
- The first 10MB is unthrottled; beyond 10MB the stream is limited to 2MB/s.
- API Gateway expects a JSON metadata block followed by an 0x00 delimiter;
  the Lambda Web Adapter handles framing automatically.
