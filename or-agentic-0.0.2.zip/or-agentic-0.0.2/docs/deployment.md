# Deployment Guide

## Document Information

| Property | Value |
|----------|-------|
| Version | 1.1.0 |
| Last Updated | January 2026 |
| Classification | Internal |
| Owner | Platform Team |

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Environment Setup](#environment-setup)
3. [Initial Deployment](#initial-deployment)
4. [CI/CD Pipeline](#cicd-pipeline)
5. [Blue-Green Deployment](#blue-green-deployment)
6. [Rollback Procedures](#rollback-procedures)
7. [Tenant Onboarding](#tenant-onboarding)
8. [Monitoring & Validation](#monitoring--validation)
9. [Troubleshooting](#troubleshooting)
10. [Runbooks](#runbooks)

---

## Prerequisites

### Required Tools

| Tool | Version | Purpose |
|------|---------|---------|
| AWS CLI | >= 2.0 | AWS resource management |
| Terraform | >= 1.5 | Infrastructure as Code |
| Python | 3.11 | Lambda runtime |
| Git | >= 2.0 | Version control |
| jq | >= 1.6 | JSON processing |

### AWS Permissions

The deployment IAM role requires the following permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "lambda:*",
        "apigateway:*",
        "dynamodb:*",
        "s3:*",
        "wafv2:*",
        "bedrock:*",
        "bedrock-agent:*",
        "acm:*",
        "route53:*",
        "cloudwatch:*",
        "logs:*",
        "sns:*",
        "secretsmanager:*",
        "codedeploy:*",
        "appconfig:*",
        "iam:*",
        "events:*"
      ],
      "Resource": "*"
    }
  ]
}
```

### Network Requirements

```mermaid
flowchart LR
    subgraph Developer["Developer Machine"]
        CLI["AWS CLI"]
        TF["Terraform"]
    end

    subgraph AWS["AWS Services"]
        STS["STS<br/>sts.amazonaws.com"]
        S3_STATE["S3 State<br/>s3.amazonaws.com"]
        SERVICES["AWS Services<br/>*.amazonaws.com"]
    end

    CLI -->|"HTTPS 443"| STS
    TF -->|"HTTPS 443"| S3_STATE
    TF -->|"HTTPS 443"| SERVICES
```

---

## Environment Setup

### 1. Clone Repository

```bash
git clone https://github.com/your-org/telecom-virtual-assistant.git
cd telecom-virtual-assistant
```

### 2. Configure AWS Credentials

```bash
# Option 1: AWS SSO (recommended)
aws sso login --profile telecom-deploy

# Option 2: Environment variables
export AWS_ACCESS_KEY_ID="your-access-key"
export AWS_SECRET_ACCESS_KEY="your-secret-key"
export AWS_REGION="us-east-1"

# Verify credentials
aws sts get-caller-identity
```

### 3. Initialize Terraform Backend

```bash
# Create S3 bucket for state
aws s3 mb s3://va-terraform-state-${AWS_ACCOUNT_ID} --region us-east-1

# Enable versioning
aws s3api put-bucket-versioning \
    --bucket va-terraform-state-${AWS_ACCOUNT_ID} \
    --versioning-configuration Status=Enabled

# Create DynamoDB table for locking
aws dynamodb create-table \
    --table-name va-terraform-locks \
    --attribute-definitions AttributeName=LockID,AttributeType=S \
    --key-schema AttributeName=LockID,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST
```

### 4. Update Backend Configuration

Edit `terraform/main.tf`:

```hcl
terraform {
  backend "s3" {
    bucket         = "va-terraform-state-YOUR_ACCOUNT_ID"
    key            = "telecom-assistant/terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    dynamodb_table = "va-terraform-locks"
  }
}
```

### 5. Build Lambda Layer

```bash
./scripts/build-layer.sh

# Verify layer was created
ls -la dist/layer.zip
```

---

## Initial Deployment

### Deployment Flow

```mermaid
flowchart TB
    subgraph Preparation["1. Preparation"]
        BUILD["Build Lambda Layer"]
        CONFIG["Configure tfvars"]
        INIT["Terraform Init"]
    end

    subgraph Planning["2. Planning"]
        PLAN["Terraform Plan"]
        REVIEW["Review Changes"]
    end

    subgraph Deployment["3. Deployment"]
        APPLY["Terraform Apply"]
        PREPARE["Prepare Agent"]
    end

    subgraph Validation["4. Validation"]
        VALIDATE["Run Validator"]
        SMOKE["Smoke Tests"]
    end

    BUILD --> CONFIG
    CONFIG --> INIT
    INIT --> PLAN
    PLAN --> REVIEW
    REVIEW -->|"Approved"| APPLY
    APPLY --> PREPARE
    PREPARE --> VALIDATE
    VALIDATE --> SMOKE
```

### Step 1: Configure Environment Variables

Edit `terraform/environments/{env}/terraform.tfvars`:

```hcl
# terraform/environments/prod/terraform.tfvars
environment     = "prod"
aws_region      = "us-east-1"
tenant_prefix   = "APPID1234"
alert_email     = "platform-team@example.com"
log_retention_days = 30

# Domain configuration
domain_name     = "api.telecom-assistant.example.com"
route53_zone_id = "Z1234567890ABC"

# External API
external_api_endpoint = "https://api.appointments.example.com"
```

### Step 2: Initialize Terraform

```bash
cd terraform

# Initialize with backend
terraform init

# Verify providers
terraform providers
```

### Step 3: Plan Deployment

```bash
# Generate plan for review
terraform plan \
    -var-file="environments/prod/terraform.tfvars" \
    -out=tfplan

# Review plan output
terraform show tfplan
```

### Step 4: Apply Infrastructure

```bash
# Apply with auto-approve (CI/CD) or interactive
terraform apply tfplan

# Or interactive
terraform apply -var-file="environments/prod/terraform.tfvars"
```

### Step 5: Prepare Bedrock Agent

Terraform invokes `prepare-agent` automatically via the `null_resource.prepare_agent` provisioner
in `terraform/modules/bedrock-agent/main.tf`. If you need to re-run the step manually:

```bash
# Get agent ID from outputs
AGENT_ID=$(terraform output -raw bedrock_agent_id)

# Prepare the agent
aws bedrock-agent prepare-agent --agent-id $AGENT_ID

# Wait for preparation
aws bedrock-agent get-agent --agent-id $AGENT_ID \
    --query 'agent.agentStatus'
```

### Step 6: Validate Deployment

```bash
# Run deployment validator
python scripts/deployment_validator.py --environment prod

# Expected output:
# [PASS] Lambda: va-APPID1234-streaming-handler-prod
# [PASS] Lambda: va-APPID1234-action-group-prod
# [PASS] DynamoDB: va-APPID1234-sessions-prod
# [PASS] API Gateway: va-APPID1234-api-prod
# [PASS] Health Endpoint
# All validation checks passed!
```

---

## CI/CD Pipeline

### Pipeline Overview

```mermaid
flowchart LR
    subgraph Trigger["Trigger"]
        MR["Merge Request"]
        MAIN["Main Branch Push"]
    end

    subgraph Stages["Pipeline Stages"]
        VAL["Validate"]
        SEC["Security"]
        BUILD["Build"]
        TEST["Test"]
        PLAN["Plan"]
        APPLY["Apply"]
        VERIFY["Verify"]
    end

    MR --> VAL
    MAIN --> VAL
    VAL --> SEC
    SEC --> BUILD
    BUILD --> TEST
    TEST --> PLAN
    PLAN -->|"Manual"| APPLY
    APPLY --> VERIFY
```

### GitLab CI/CD Configuration

The pipeline is defined in `.gitlab-ci.yml`. Key stages:

#### Validate Stage
- Terraform format and validation
- Python linting (black, ruff, mypy)
- OpenAPI schema validation

#### Security Stage
- Checkov infrastructure scanning
- TFSec security analysis
- Bandit Python security scan

#### Build Stage
- Lambda layer packaging
- Function code packaging

#### Test Stage
- Unit tests with pytest
- Coverage reporting (>90% target)

#### Plan Stage
```yaml
plan-prod:
  stage: plan
  script:
    - terraform plan -var-file="environments/prod/terraform.tfvars" -out=tfplan
  rules:
    - if: '$CI_COMMIT_BRANCH == "main"'
      when: manual
```

#### Apply Stage
```yaml
apply-prod:
  stage: apply
  script:
    - terraform apply -auto-approve tfplan
  needs:
    - job: plan-prod
    - job: apply-staging
  rules:
    - if: '$CI_COMMIT_BRANCH == "main"'
      when: manual
```

### Running Pipeline

```bash
# Push to trigger pipeline
git push origin main

# Or manually trigger via GitLab UI
# Navigate to CI/CD > Pipelines > Run Pipeline
```

---

## Blue-Green Deployment

### Deployment Strategy

```mermaid
stateDiagram-v2
    [*] --> Blue: v1.0 (100%)

    state "Canary Deployment" as Canary {
        [*] --> Deploy_Green
        Deploy_Green --> Shift_10: Deploy v1.1
        Shift_10 --> Monitor_10: 10% traffic
        Monitor_10 --> Shift_50: Healthy (5 min)
        Monitor_10 --> Rollback: Unhealthy
        Shift_50 --> Monitor_50: 50% traffic
        Monitor_50 --> Shift_100: Healthy (5 min)
        Monitor_50 --> Rollback: Unhealthy
        Shift_100 --> Complete: 100% traffic
    }

    Blue --> Canary: New Deployment
    Canary --> Green: Success
    Canary --> Blue: Rollback

    Green --> [*]
```

### CodeDeploy Configuration

```hcl
# Deployment configuration
deployment_config_name = "CodeDeployDefault.LambdaCanary10Percent5Minutes"

# Auto-rollback settings
auto_rollback_configuration {
  enabled = true
  events  = ["DEPLOYMENT_FAILURE", "DEPLOYMENT_STOP_ON_ALARM"]
}
```

### Manual Blue-Green Deployment

#### Step 1: Deploy New Version

```bash
# Update Lambda function code
aws lambda update-function-code \
    --function-name va-APPID1234-streaming-handler-prod \
    --zip-file fileb://dist/streaming_handler.zip \
    --publish

# Get new version number
NEW_VERSION=$(aws lambda list-versions-by-function \
    --function-name va-APPID1234-streaming-handler-prod \
    --query 'Versions[-1].Version' --output text)
```

#### Step 2: Update Alias with Canary

```bash
# Shift 10% traffic to new version
aws lambda update-alias \
    --function-name va-APPID1234-streaming-handler-prod \
    --name prod \
    --routing-config AdditionalVersionWeights={"$NEW_VERSION"=0.1}
```

#### Step 3: Monitor Health

```bash
# Check error rate
aws cloudwatch get-metric-statistics \
    --namespace AWS/Lambda \
    --metric-name Errors \
    --dimensions Name=FunctionName,Value=va-APPID1234-streaming-handler-prod \
    --start-time $(date -u -v-5M +%Y-%m-%dT%H:%M:%SZ) \
    --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
    --period 60 \
    --statistics Sum
```

#### Step 4: Complete or Rollback

```bash
# If healthy, complete deployment
aws lambda update-alias \
    --function-name va-APPID1234-streaming-handler-prod \
    --name prod \
    --function-version $NEW_VERSION \
    --routing-config AdditionalVersionWeights={}

# If unhealthy, rollback
aws lambda update-alias \
    --function-name va-APPID1234-streaming-handler-prod \
    --name prod \
    --function-version $PREVIOUS_VERSION \
    --routing-config AdditionalVersionWeights={}
```

---

## Rollback Procedures

### Automatic Rollback

Triggered automatically when:
- Deployment health check fails
- CloudWatch alarms trigger
- Error rate exceeds threshold (5%)

### Manual Rollback

#### Terraform Rollback

```bash
# List state versions
aws s3api list-object-versions \
    --bucket va-terraform-state \
    --prefix telecom-assistant/terraform.tfstate

# Restore previous state
aws s3api get-object \
    --bucket va-terraform-state \
    --key telecom-assistant/terraform.tfstate \
    --version-id "previous-version-id" \
    terraform.tfstate.backup

# Apply previous state
terraform apply terraform.tfstate.backup
```

#### Lambda Rollback

```bash
# Get previous version
PREV_VERSION=$(aws lambda list-versions-by-function \
    --function-name va-APPID1234-streaming-handler-prod \
    --query 'Versions[-2].Version' --output text)

# Update alias to previous version
aws lambda update-alias \
    --function-name va-APPID1234-streaming-handler-prod \
    --name prod \
    --function-version $PREV_VERSION
```

### Rollback Decision Matrix

```mermaid
flowchart TB
    START["Issue Detected"]
    ERROR_RATE{"Error Rate > 5%?"}
    LATENCY{"P99 Latency > 15s?"}
    HEALTH{"Health Check Failing?"}
    MANUAL{"Manual Override?"}

    AUTO_ROLLBACK["Automatic Rollback"]
    MANUAL_ROLLBACK["Manual Rollback"]
    INVESTIGATE["Investigate & Monitor"]

    START --> ERROR_RATE
    ERROR_RATE -->|Yes| AUTO_ROLLBACK
    ERROR_RATE -->|No| LATENCY
    LATENCY -->|Yes| MANUAL_ROLLBACK
    LATENCY -->|No| HEALTH
    HEALTH -->|Yes| MANUAL_ROLLBACK
    HEALTH -->|No| MANUAL
    MANUAL -->|Yes| MANUAL_ROLLBACK
    MANUAL -->|No| INVESTIGATE
```

---

## Tenant Onboarding

### Onboarding Flow

```mermaid
flowchart TB
    subgraph Request["1. Request"]
        TICKET["Support Ticket"]
        CONTRACT["Contract Signed"]
    end

    subgraph Provisioning["2. Provisioning"]
        API_KEY["Generate API Key"]
        CERT["Issue Client Certificate"]
        USAGE_PLAN["Configure Usage Plan"]
    end

    subgraph Configuration["3. Configuration"]
        TRUSTSTORE["Update Truststore"]
        MONITORING["Setup Monitoring"]
        ALERTS["Configure Alerts"]
    end

    subgraph Validation["4. Validation"]
        TEST_ENV["Test in Staging"]
        VALIDATE["Validate Isolation"]
        DOCUMENT["Document Credentials"]
    end

    subgraph Handover["5. Handover"]
        CREDS["Deliver Credentials"]
        DOCS["Provide Documentation"]
        SUPPORT["Enable Support"]
    end

    TICKET --> CONTRACT
    CONTRACT --> API_KEY
    API_KEY --> CERT
    CERT --> USAGE_PLAN
    USAGE_PLAN --> TRUSTSTORE
    TRUSTSTORE --> MONITORING
    MONITORING --> ALERTS
    ALERTS --> TEST_ENV
    TEST_ENV --> VALIDATE
    VALIDATE --> DOCUMENT
    DOCUMENT --> CREDS
    CREDS --> DOCS
    DOCS --> SUPPORT
```

### Step 1: Generate API Key

```bash
# Create API key
API_KEY_ID=$(aws apigateway create-api-key \
    --name "tenant-newcustomer-prod" \
    --enabled \
    --query 'id' --output text)

# Get API key value
API_KEY_VALUE=$(aws apigateway get-api-key \
    --api-key $API_KEY_ID \
    --include-value \
    --query 'value' --output text)

echo "API Key: $API_KEY_VALUE"
```

### Step 2: Associate with Usage Plan

```bash
# Get usage plan ID
USAGE_PLAN_ID=$(aws apigateway get-usage-plans \
    --query "items[?name=='va-APPID1234-usage-plan-prod'].id" \
    --output text)

# Associate API key
aws apigateway create-usage-plan-key \
    --usage-plan-id $USAGE_PLAN_ID \
    --key-id $API_KEY_ID \
    --key-type API_KEY
```

### Step 3: Generate Client Certificate

```bash
# Generate private key
openssl genrsa -out tenant-newcustomer.key 2048

# Generate CSR
openssl req -new -key tenant-newcustomer.key \
    -out tenant-newcustomer.csr \
    -subj "/CN=tenant-newcustomer/O=Example Corp/C=US"

# Sign with CA (you maintain the CA)
openssl x509 -req -in tenant-newcustomer.csr \
    -CA ca.crt -CAkey ca.key \
    -CAcreateserial \
    -out tenant-newcustomer.crt \
    -days 365
```

### Step 4: Update Truststore

```bash
# Download current truststore
aws s3 cp s3://va-APPID1234-mtls-truststore-xxxx/truststore.pem ./

# Add new CA certificate
cat ca.crt >> truststore.pem

# Upload updated truststore
aws s3 cp truststore.pem s3://va-APPID1234-mtls-truststore-xxxx/

# Verify upload
aws s3 ls s3://va-APPID1234-mtls-truststore-xxxx/
```

### Step 5: Validate Tenant

```bash
# Test API call with new credentials
curl -X POST "https://api.telecom-assistant.example.com/v1/agent/invoke" \
    --cert tenant-newcustomer.crt \
    --key tenant-newcustomer.key \
    -H "Content-Type: application/json" \
    -H "X-Tenant-ID: tenant-newcustomer" \
    -H "X-API-Key: $API_KEY_VALUE" \
    -d '{"query": "Hello, test connection"}'
```

---

## Monitoring & Validation

### Health Check Endpoints

| Endpoint | Purpose | Auth Required |
|----------|---------|---------------|
| `GET /health` | Service health | No |
| `GET /health/ready` | Readiness probe | No |

### CloudWatch Dashboard

Access the operational dashboard:

```
https://us-east-1.console.aws.amazon.com/cloudwatch/home?region=us-east-1#dashboards:name=va-APPID1234-dashboard-prod
```

### Key Metrics to Monitor

```mermaid
flowchart TB
    subgraph SLIs["Service Level Indicators"]
        AVAIL["Availability<br/>Target: 99.9%"]
        LATENCY["Latency<br/>P99 < 15s"]
        ERROR["Error Rate<br/>< 0.1%"]
        TTFB["TTFB<br/>< 500ms"]
    end

    subgraph Alarms["CloudWatch Alarms"]
        A1["error-rate-warning<br/>> 0.5%"]
        A2["error-rate-critical<br/>> 1%"]
        A3["error-rate-severe<br/>> 5%"]
        A4["latency-warning<br/>> 5s"]
        A5["api-5xx-errors<br/>> 5 in 5min"]
    end

    AVAIL --> A1 & A2 & A3
    LATENCY --> A4
    ERROR --> A1 & A2 & A3
    TTFB --> A5
```

### Post-Deployment Validation Checklist

```bash
# Run automated validation
python scripts/deployment_validator.py --environment prod

# Manual checks
# 1. Verify Lambda functions
aws lambda list-functions --query "Functions[?starts_with(FunctionName, 'va-APPID1234')].[FunctionName,State]"

# 2. Verify API Gateway
aws apigateway get-rest-apis --query "items[?name=='va-APPID1234-api-prod']"

# 3. Verify DynamoDB tables
aws dynamodb list-tables --query "TableNames[?starts_with(@, 'va-APPID1234')]"

# 4. Test health endpoint
curl https://api.telecom-assistant.example.com/health

# 5. Check CloudWatch alarms
aws cloudwatch describe-alarms --alarm-name-prefix va-APPID1234 --state-value ALARM
```

---

## Troubleshooting

### Common Issues

#### Issue: Lambda Cold Starts > 20%

```mermaid
flowchart TB
    COLD["High Cold Start Rate"]
    PROVISIONED{"Provisioned<br/>Concurrency?"}
    MEMORY{"Memory<br/>Adequate?"}
    LAYER{"Layer Size<br/>< 50MB?"}

    FIX1["Enable Provisioned<br/>Concurrency"]
    FIX2["Increase Memory"]
    FIX3["Optimize Layer<br/>Dependencies"]

    COLD --> PROVISIONED
    PROVISIONED -->|No| FIX1
    PROVISIONED -->|Yes| MEMORY
    MEMORY -->|No| FIX2
    MEMORY -->|Yes| LAYER
    LAYER -->|No| FIX3
```

**Resolution:**
```bash
# Add provisioned concurrency
aws lambda put-provisioned-concurrency-config \
    --function-name va-APPID1234-streaming-handler-prod \
    --qualifier prod \
    --provisioned-concurrent-executions 10
```

#### Issue: API Gateway 5XX Errors

**Check Lambda errors:**
```bash
aws logs filter-log-events \
    --log-group-name /aws/lambda/va-APPID1234-streaming-handler-prod \
    --filter-pattern "ERROR" \
    --start-time $(date -d "1 hour ago" +%s000)
```

**Check circuit breaker:**
```bash
aws logs filter-log-events \
    --log-group-name /aws/lambda/va-APPID1234-streaming-handler-prod \
    --filter-pattern "circuit breaker" \
    --start-time $(date -d "1 hour ago" +%s000)
```

#### Issue: Bedrock Agent Not Responding

**Verify agent status:**
```bash
AGENT_ID=$(terraform output -raw bedrock_agent_id)
aws bedrock-agent get-agent --agent-id $AGENT_ID
```

**Re-prepare agent:**
```bash
aws bedrock-agent prepare-agent --agent-id $AGENT_ID
```

#### Issue: mTLS Certificate Validation Failing

**Check truststore:**
```bash
aws s3 ls s3://va-APPID1234-mtls-truststore-xxxx/

# Download and verify
aws s3 cp s3://va-APPID1234-mtls-truststore-xxxx/truststore.pem ./
openssl verify -CAfile truststore.pem client.crt
```

### Log Queries

**Find errors by correlation ID:**
```
fields @timestamp, @message
| filter @message like /correlation_id.*abc123/
| sort @timestamp desc
| limit 100
```

**Find all tenant requests:**
```
fields @timestamp, @message
| filter @message like /tenant_id.*tenant-123/
| sort @timestamp desc
| limit 100
```

**Find slow requests:**
```
fields @timestamp, @message, latency_ms
| filter latency_ms > 5000
| sort @timestamp desc
| limit 100
```

---

## Runbooks

### Runbook: Service Degradation

```mermaid
flowchart TB
    ALERT["Alert: Service Degradation"]
    ASSESS["Assess Impact"]
    SCOPE{"Scope?"}

    SINGLE["Single Tenant"]
    MULTI["Multiple Tenants"]
    ALL["All Traffic"]

    CHECK_TENANT["Check Tenant Config"]
    CHECK_DEPS["Check Dependencies"]
    CHECK_INFRA["Check Infrastructure"]

    SCALE{"Need to Scale?"}
    ROLLBACK{"Need Rollback?"}

    SCALE_UP["Increase Concurrency"]
    DO_ROLLBACK["Execute Rollback"]
    MONITOR["Monitor Recovery"]

    ALERT --> ASSESS
    ASSESS --> SCOPE
    SCOPE --> SINGLE
    SCOPE --> MULTI
    SCOPE --> ALL

    SINGLE --> CHECK_TENANT
    MULTI --> CHECK_DEPS
    ALL --> CHECK_INFRA

    CHECK_INFRA --> SCALE
    SCALE -->|Yes| SCALE_UP
    SCALE -->|No| ROLLBACK
    ROLLBACK -->|Yes| DO_ROLLBACK
    ROLLBACK -->|No| MONITOR

    SCALE_UP --> MONITOR
    DO_ROLLBACK --> MONITOR
```

### Runbook: Security Incident

1. **Immediate Actions**
   - Enable WAF block mode for affected IPs
   - Rotate affected API keys
   - Enable enhanced logging

2. **Investigation**
   - Query CloudWatch Logs for suspicious activity
   - Check WAF logs for attack patterns
   - Review audit logs for data access

3. **Remediation**
   - Update WAF rules
   - Revoke compromised credentials
   - Patch vulnerabilities

4. **Post-Incident**
   - Document incident timeline
   - Conduct root cause analysis
   - Implement preventive measures

### Runbook: Disaster Recovery

| Step | Action | RTO Target |
|------|--------|------------|
| 1 | Detect failure | < 1 min |
| 2 | Failover DNS | < 5 min |
| 3 | Restore from backup | < 30 min |
| 4 | Validate services | < 15 min |
| **Total** | | **< 51 min** |

```bash
# Emergency failover script
#!/bin/bash
set -e

echo "Starting disaster recovery..."

# 1. Update Route53 to failover region
aws route53 change-resource-record-sets \
    --hosted-zone-id $ZONE_ID \
    --change-batch file://failover-record.json

# 2. Deploy from latest backup
cd terraform
terraform init -backend-config="region=us-west-2"
# NOTE: Create environments/dr/terraform.tfvars before running this step.
terraform apply -var-file="environments/dr/terraform.tfvars" -auto-approve

# 3. Validate services
python scripts/deployment_validator.py --environment dr

echo "Disaster recovery complete"
```

---

## Appendix

### Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `ENVIRONMENT` | Deployment environment | `prod` |
| `TENANT_PREFIX` | Multi-tenant prefix | `APPID1234` |
| `BEDROCK_AGENT_ID` | Bedrock Agent ID | `abc123` |
| `BEDROCK_AGENT_ALIAS_ID` | Agent alias ID | `xyz789` |
| `POWERTOOLS_SERVICE_NAME` | Service name for observability | `telecom-virtual-assistant` |

### Useful Commands

```bash
# View Lambda logs in real-time
aws logs tail /aws/lambda/va-APPID1234-streaming-handler-prod --follow

# Get API Gateway URL
terraform output api_gateway_url

# Check alarm status
aws cloudwatch describe-alarms --alarm-name-prefix va-APPID1234 --state-value ALARM

# Force agent preparation
aws bedrock-agent prepare-agent --agent-id $(terraform output -raw bedrock_agent_id)

# List recent deployments
aws codedeploy list-deployments --application-name va-APPID1234-lambda-deploy-prod
```

### Support Contacts

| Role | Contact | Availability |
|------|---------|--------------|
| Platform Team | platform-team@example.com | Business hours |
| On-Call Engineer | PagerDuty | 24/7 |
| AWS Support | AWS Console | Per support plan |
