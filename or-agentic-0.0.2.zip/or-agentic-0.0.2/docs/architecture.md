# Technical Architecture

## Document Information

| Property | Value |
|----------|-------|
| Version | 1.1.0 |
| Last Updated | January 2026 |
| Classification | Internal |
| Owner | Platform Team |

---

## Table of Contents

1. [System Overview](#system-overview)
2. [Component Architecture](#component-architecture)
3. [Data Architecture](#data-architecture)
4. [Request Flow](#request-flow)
5. [Multi-Tenancy Model](#multi-tenancy-model)
6. [Security Architecture](#security-architecture)
7. [Threat Model](#threat-model)
8. [Observability Architecture](#observability-architecture)
9. [Release Architecture](#release-architecture)
10. [Cost Architecture](#cost-architecture)

---

## System Overview

### High-Level Architecture

```mermaid
flowchart TB
    subgraph Internet["Internet"]
        direction TB
        TC1["Telecom Co. A<br/>Cross-Account"]
        TC2["Telecom Co. B<br/>Cross-Account"]
        TC3["Telecom Co. N<br/>Cross-Account"]
    end

    subgraph AWS["AWS Account - APPID1234"]
        subgraph EdgeLayer["Edge Layer"]
            R53[Route 53<br/>DNS]
            ACM[ACM<br/>Certificates]
            WAF[AWS WAF<br/>Web ACL]
        end

        subgraph APILayer["API Layer"]
            APIGW[API Gateway<br/>Regional REST<br/>Streaming Enabled]
            TRUST[(S3<br/>mTLS Truststore)]
        end

        subgraph ComputeLayer["Compute Layer"]
            subgraph LambdaFunctions["Lambda Functions"]
                STREAM["Streaming Handler<br/>1024MB / 15min<br/>70 Reserved"]
                ACTION["Action Group<br/>512MB / 60s<br/>30 Reserved"]
                HEALTH["Health Handler<br/>256MB / 30s"]
            end
            LAYER["Lambda Layer<br/>AWS Powertools"]
        end

        subgraph AILayer["AI/ML Layer"]
            AGENT["Bedrock Agent<br/>Claude 3.5 Sonnet<br/>v2:0"]
            GUARD["Bedrock Guardrails<br/>Content Filtering<br/>PII Detection"]
        end

        subgraph DataLayer["Data Layer"]
            MEMORY[(Bedrock Agent Memory<br/>Session Summaries)]
            S3_ARCHIVE[(S3<br/>Audit Archive<br/>7yr Lifecycle)]
        end

        subgraph ObservabilityLayer["Observability Layer"]
            CW[CloudWatch<br/>Logs/Metrics]
            XRAY[X-Ray<br/>Tracing]
            SNS[SNS<br/>Alerts]
        end

        subgraph DeploymentLayer["Deployment Layer"]
            DEPLOY[CodeDeploy<br/>Blue-Green]
            CONFIG[AppConfig<br/>Feature Flags]
        end
    end

    subgraph ExternalServices["External Services"]
        APPT_API["Appointment<br/>Service API"]
        SECRETS["Secrets Manager<br/>API Credentials"]
    end

    TC1 & TC2 & TC3 -->|"HTTPS + mTLS"| R53
    R53 --> ACM
    ACM --> WAF
    WAF --> APIGW
    APIGW -->|"Lambda Proxy<br/>Streaming"| STREAM
    APIGW --> HEALTH
    APIGW -.->|"Truststore"| TRUST

    STREAM --> AGENT
    AGENT --> GUARD
    AGENT --> ACTION
    ACTION --> APPT_API
    ACTION -.-> SECRETS

    AGENT --> MEMORY
    STREAM --> S3_ARCHIVE
    ACTION --> S3_ARCHIVE

    STREAM --> CW
    STREAM --> XRAY
    ACTION --> CW
    CW --> SNS

    LAYER -.- STREAM
    LAYER -.- ACTION

    DEPLOY --> STREAM
    DEPLOY --> ACTION
    CONFIG --> STREAM
```

### Architecture Principles

| Principle | Implementation |
|-----------|----------------|
| **Stateless Compute** | No VPC, session state in Bedrock Agent Memory |
| **Event-Driven** | Lambda + event-driven archiving |
| **Multi-Tenant Isolation** | Tenant ID in all data, separate API keys |
| **Defense in Depth** | WAF → mTLS → API Key → Guardrails |
| **Observable** | Structured logging, distributed tracing |
| **Immutable Infrastructure** | Terraform, Lambda versions |

---

## Component Architecture

### Lambda Functions

```mermaid
stateDiagram-v2
    [*] --> Cold: Invocation
    Cold --> Warm: Init Complete
    Warm --> Processing: Request Received
    Processing --> Streaming: Bedrock Response
    Streaming --> Processing: More Chunks
    Streaming --> Complete: Final Chunk
    Complete --> Warm: Keep Alive
    Warm --> [*]: Timeout (15min)

    Processing --> Error: Exception
    Error --> Warm: Error Handled
    Error --> CircuitOpen: Threshold Exceeded
    CircuitOpen --> HalfOpen: Recovery Timeout
    HalfOpen --> Warm: Success
    HalfOpen --> CircuitOpen: Failure
```

#### Streaming Handler (`src/handlers/streaming_handler.py`)

| Property | Value |
|----------|-------|
| Runtime | Python 3.11 |
| Memory | 1024 MB |
| Timeout | 15 minutes (900s) |
| Reserved Concurrency | 70 |
| Handler | `handlers.streaming_handler.handler` |

**Responsibilities:**
- Request validation and tenant context extraction
- Session memory handled via Bedrock Agent Memory (memoryId)
- Bedrock Agent invocation with streaming
- Response streaming to API Gateway
- Audit logging with PII redaction
- Circuit breaker for Bedrock failures

#### Action Group Handler (`src/handlers/action_group.py`)

| Property | Value |
|----------|-------|
| Runtime | Python 3.11 |
| Memory | 512 MB |
| Timeout | 60 seconds |
| Reserved Concurrency | 30 |
| Handler | `handlers.action_group.handler` |

**Responsibilities:**
- Appointment CRUD operations
- External API integration with retry logic
- JWT passthrough authentication
- Tenant-aware audit logging

#### Health Handler (`src/handlers/streaming_handler.py`)

| Property | Value |
|----------|-------|
| Runtime | Python 3.11 |
| Memory | 256 MB |
| Timeout | 30 seconds |
| Handler | `handlers.streaming_handler.health_handler` |

**Responsibilities:**
- Liveness checks for API Gateway `/health`

### API Gateway Configuration

```mermaid
flowchart LR
    subgraph Endpoints["API Endpoints"]
        POST_INVOKE["POST /v1/agent/invoke"]
        GET_STATUS["GET /v1/agent/status/{id}"]
        GET_HEALTH["GET /health"]
        GET_READY["GET /health/ready"]
    end

    subgraph Config["Configuration"]
        MTLS["mTLS<br/>Client Cert Required"]
        STREAM_CFG["Streaming<br/>responseTransferMode: STREAM"]
        THROTTLE["Throttling<br/>200 req/min"]
        TIMEOUT["Timeout<br/>15 minutes"]
    end

    POST_INVOKE --> MTLS
    POST_INVOKE --> STREAM_CFG
    POST_INVOKE --> THROTTLE
    POST_INVOKE --> TIMEOUT

    GET_HEALTH --> |"No Auth"| HEALTH_LAMBDA["Health Lambda"]
```

**REST API Streaming Configuration (November 2025 GA):**

```hcl
# API Gateway Integration
resource "aws_api_gateway_integration" "invoke_post" {
  type                    = "AWS_PROXY"
  integration_http_method = "POST"
  timeout_milliseconds    = 900000  # 15 minutes

  # Streaming enabled via method settings
}

# Streaming constraints:
# - 5-minute idle timeout (Regional/Private)
# - First 10MB unrestricted bandwidth
# - Beyond 10MB: 2MB/s cap
# - No caching or VTL transformation
```

---

## Data Architecture

### Entity Relationship Diagram

```mermaid
erDiagram
    TENANT ||--o{ MEMORY_SUMMARY : stores
    TENANT ||--o{ AUDIT_EVENT : generates

    TENANT {
        string tenantId PK
        string tenantName
        string apiEndpoint
        int rateLimit
        timestamp createdAt
    }

    MEMORY_SUMMARY {
        string memoryId PK
        string tenantId FK
        string summary
        timestamp lastUpdated
        int retentionDays
    }

    AUDIT_EVENT {
        string eventId PK
        string timestamp
        string tenantId FK
        string action
        string queryRedacted
        string responseSummary
        int latencyMs
        boolean success
        int retentionDays
    }
```

### Bedrock Agent Memory & Audit Archive

#### Memory Summaries (Bedrock Agent Memory)

| Attribute | Type | Description |
|-----------|------|-------------|
| `memoryId` | String | Stable memory key per user/session |
| `tenantId` | String | Tenant identifier (request context) |
| `summary` | String | Session summary stored by the agent |
| `lastUpdated` | String | ISO 8601 timestamp |
| `retentionDays` | Number | Configurable retention window |

**Access Patterns:**
- Retrieve/update memory by `memoryId` during agent invocation
- Partition memory by tenant via request context

#### Audit Archive (S3)

| Attribute | Type | Description |
|-----------|------|-------------|
| `eventId` | String | Unique audit event ID |
| `timestamp` | String | ISO 8601 timestamp |
| `tenantId` | String | Tenant identifier |
| `action` | String | Action performed |
| `queryRedacted` | String | Redacted user query |
| `responseSummary` | String | Truncated response |
| `latencyMs` | Number | Processing time |
| `success` | Boolean | Operation result |
| `retentionDays` | Number | Archive lifecycle window |

**Access Patterns:**
- Query audit events by tenant/time range in S3 analytics
- Lifecycle policies manage retention and cold storage

### Data Lifecycle

```mermaid
flowchart LR
    subgraph Hot["Hot Storage (Bedrock Agent Memory)"]
        SESSIONS["Session Summaries<br/>Retention: configurable"]
    end

    subgraph Warm["Warm Storage (S3 Standard)"]
        ARCHIVE["Audit Archive<br/>90 days"]
    end

    subgraph Cold["Cold Storage (S3 Glacier)"]
        GLACIER["Long-term Archive<br/>7 years"]
    end

    subgraph Expiry["Data Expiry"]
        DELETE["Permanent Deletion<br/>After 7 years"]
    end

    SESSIONS -->|"Retention Expiry"| DELETE
    ARCHIVE -->|"Lifecycle: 90 days"| GLACIER
    GLACIER -->|"Lifecycle: 7 years"| DELETE
```

---

## Request Flow

### Agent Invocation Sequence

```mermaid
sequenceDiagram
    autonumber
    participant Client as Tenant Client
    participant WAF as AWS WAF
    participant APIGW as API Gateway
    participant Lambda as Streaming Handler
    participant Memory as Agent Memory
    participant Agent as Bedrock Agent
    participant Action as Action Group
    participant External as External API

    Client->>+WAF: POST /v1/agent/invoke<br/>mTLS + API Key
    WAF->>WAF: Rate Limit Check<br/>(1000/5min per IP)
    WAF->>+APIGW: Forward Request
    APIGW->>APIGW: Validate API Key<br/>Extract Tenant ID
    APIGW->>+Lambda: Invoke (Streaming)

    Lambda->>Lambda: Validate Request
    Lambda->>+Agent: InvokeAgent<br/>(streamFinalResponse: true, memoryId)
    Agent->>Agent: Process with<br/>Claude 3.5 Sonnet
    Agent->>+Memory: Retrieve/Update Summary
    Memory-->>-Agent: Memory Context

    opt Action Required
        Agent->>+Action: Invoke Action Group
        Action->>+External: API Call (with retry)
        External-->>-Action: Response
        Action-->>-Agent: Action Result
    end

    loop Streaming Response
        Agent-->>Lambda: Response Chunk
        Lambda-->>APIGW: Stream Chunk
        APIGW-->>Client: Stream Chunk
    end

    Agent-->>-Lambda: Final Chunk

    Lambda->>Lambda: Write Audit Event to Archive

    Lambda-->>-APIGW: Complete
    APIGW-->>-WAF: Complete
    WAF-->>-Client: Response Complete
```

### Appointment Booking Flow

```mermaid
sequenceDiagram
    autonumber
    participant User as Field Engineer
    participant Agent as Bedrock Agent
    participant Action as Action Group
    participant API as Appointment API

    User->>Agent: "Book installation for<br/>123 Main St tomorrow at 2pm"

    Agent->>Agent: Extract Intent:<br/>Book Appointment
    Agent->>Agent: Extract Entities:<br/>- Location: 123 Main St<br/>- Date: Tomorrow<br/>- Time: 2pm<br/>- Type: Installation

    Agent->>+Action: searchAvailableSlots<br/>{date, location, type}
    Action->>+API: GET /appointments/available-slots
    API-->>-Action: Available Slots
    Action-->>-Agent: Slots Found

    Agent->>User: "I found a slot at 2pm.<br/>Confirm booking?"
    User->>Agent: "Yes, book it"

    Agent->>+Action: reserveSlot<br/>{slotId, customerId}
    Action->>+API: POST /appointments/reserve
    API-->>-Action: Reservation ID
    Action-->>-Agent: Reserved

    Agent->>+Action: bookAppointment<br/>{slotId, customerId, details}
    Action->>+API: POST /appointments
    API-->>-Action: Appointment Confirmed
    Action-->>-Agent: Booking Complete

    Agent->>User: "Appointment booked!<br/>Confirmation: CONF-12345<br/>Date: Tomorrow 2pm-4pm<br/>Location: 123 Main St"
```

---

## Multi-Tenancy Model

### Tenant Isolation Architecture

```mermaid
flowchart TB
    subgraph TenantA["Tenant A"]
        A_CERT[Client Cert A]
        A_KEY[API Key A]
        A_DATA[(Tenant A Data)]
    end

    subgraph TenantB["Tenant B"]
        B_CERT[Client Cert B]
        B_KEY[API Key B]
        B_DATA[(Tenant B Data)]
    end

    subgraph SharedInfra["Shared Infrastructure"]
        subgraph Auth["Authentication"]
            MTLS_VAL[mTLS Validation]
            KEY_VAL[API Key Validation]
        end

        subgraph Compute["Compute"]
            LAMBDA[Lambda Functions]
            AGENT2[Bedrock Agent]
        end

        subgraph Data["Data Isolation"]
            MEMORY2[(Bedrock Agent Memory)]
        end
    end

    A_CERT --> MTLS_VAL
    A_KEY --> KEY_VAL
    B_CERT --> MTLS_VAL
    B_KEY --> KEY_VAL

    MTLS_VAL --> LAMBDA
    KEY_VAL --> LAMBDA
    LAMBDA --> AGENT2
    AGENT2 --> MEMORY2

    MEMORY2 -->|"tenantId=A"| A_DATA
    MEMORY2 -->|"tenantId=B"| B_DATA
```

### Tenant Context Flow

```mermaid
flowchart LR
    subgraph Request["Incoming Request"]
        HEADER["X-Tenant-ID: tenant-123"]
        JWT["Authorization: Bearer ..."]
    end

    subgraph Processing["Context Propagation"]
        EXTRACT["Extract Tenant ID"]
        SESSION["MemoryId: tenant-123-uuid"]
        AGENT_CTX["Agent Session State"]
        ACTION_CTX["Action Parameters"]
        AUDIT_CTX["Audit Record"]
    end

    HEADER --> EXTRACT
    EXTRACT --> SESSION
    SESSION --> AGENT_CTX
    AGENT_CTX --> ACTION_CTX
    JWT --> ACTION_CTX
    ACTION_CTX --> AUDIT_CTX
```

### Cost Allocation

| Resource | Allocation Method | Tag |
|----------|-------------------|-----|
| Lambda | Per-invocation | `TenantId` |
| Bedrock Agent Memory | Per-summary | `TenantId` in session context |
| API Gateway | Per-request | `TenantId` in metrics |
| Bedrock | Per-token | Session attributes |

---

## Security Architecture

### Defense in Depth

```mermaid
flowchart TB
    subgraph Layer1["Layer 1: Network"]
        WAF_L["WAF Rules"]
        RATE["Rate Limiting<br/>1000/5min per IP"]
        GEO["Geo Restrictions"]
    end

    subgraph Layer2["Layer 2: Transport"]
        TLS["TLS 1.2+"]
        MTLS_L["Mutual TLS"]
        CERT_VAL["Certificate Validation"]
    end

    subgraph Layer3["Layer 3: Application"]
        APIKEY_L["API Key Validation"]
        INPUT_VAL["Input Validation"]
        SIZE_LIMIT["Request Size Limit<br/>10KB"]
    end

    subgraph Layer4["Layer 4: AI/ML"]
        GUARD_L["Bedrock Guardrails"]
        CONTENT["Content Filtering"]
        PII_L["PII Detection"]
        TOPIC["Topic Policies"]
    end

    subgraph Layer5["Layer 5: Data"]
        ENCRYPT["AES-256 Encryption"]
        REDACT["PII Redaction"]
        TTL["Data TTL"]
    end

    Layer1 --> Layer2
    Layer2 --> Layer3
    Layer3 --> Layer4
    Layer4 --> Layer5
```

### Authentication Flow

```mermaid
sequenceDiagram
    participant Client
    participant APIGW as API Gateway
    participant Truststore as S3 Truststore
    participant UsagePlan as Usage Plan

    Client->>+APIGW: Request with Client Cert + API Key

    APIGW->>+Truststore: Fetch CA Certificates
    Truststore-->>-APIGW: CA Bundle

    APIGW->>APIGW: Validate Client Certificate<br/>Against CA Bundle

    alt Certificate Invalid
        APIGW-->>Client: 403 Forbidden
    end

    APIGW->>+UsagePlan: Validate API Key
    UsagePlan-->>-APIGW: Tenant Config

    alt API Key Invalid
        APIGW-->>Client: 401 Unauthorized
    end

    APIGW->>APIGW: Check Rate Limit

    alt Rate Limited
        APIGW-->>Client: 429 Too Many Requests
    end

    APIGW-->>-Client: Request Authorized
```

---

## Threat Model

### STRIDE Analysis

```mermaid
flowchart TB
    subgraph Threats["STRIDE Threat Categories"]
        S["Spoofing<br/>Identity"]
        T["Tampering<br/>Data"]
        R["Repudiation<br/>Actions"]
        I["Information<br/>Disclosure"]
        D["Denial of<br/>Service"]
        E["Elevation of<br/>Privilege"]
    end

    subgraph Mitigations["Mitigations"]
        S --> S_MIT["mTLS + API Keys<br/>Certificate Pinning"]
        T --> T_MIT["TLS 1.2+<br/>Input Validation"]
        R --> R_MIT["Audit Logging<br/>7-year Retention"]
        I --> I_MIT["PII Redaction<br/>Encryption at Rest"]
        D --> D_MIT["WAF Rate Limiting<br/>Circuit Breaker"]
        E --> E_MIT["Tenant Isolation<br/>Least Privilege IAM"]
    end
```

### Attack Surface Analysis

```mermaid
flowchart LR
    subgraph External["External Attack Surface"]
        INET["Internet"]
    end

    subgraph AttackVectors["Attack Vectors"]
        AV1["API Abuse"]
        AV2["Injection Attacks"]
        AV3["Data Exfiltration"]
        AV4["Cross-Tenant Access"]
        AV5["Prompt Injection"]
    end

    subgraph Controls["Security Controls"]
        C1["Rate Limiting<br/>WAF Rules"]
        C2["Input Validation<br/>SQL/XSS Protection"]
        C3["PII Redaction<br/>Encryption"]
        C4["Tenant ID Validation<br/>API Key Binding"]
        C5["Guardrails<br/>Topic Policies"]
    end

    INET --> AV1
    INET --> AV2
    INET --> AV3
    INET --> AV4
    INET --> AV5

    AV1 --> C1
    AV2 --> C2
    AV3 --> C3
    AV4 --> C4
    AV5 --> C5
```

### Security Requirements Matrix

| Threat | Control | Implementation | Testing |
|--------|---------|----------------|---------|
| Unauthorized Access | mTLS + API Key | API Gateway custom domain | Certificate validation test |
| Injection Attacks | WAF + Input Validation | AWSManagedRulesCommonRuleSet | OWASP test suite |
| Data Breach | Encryption + PII Redaction | AES-256, Regex patterns | Data exposure scan |
| Cross-Tenant Access | Tenant ID Validation | All queries filtered | Isolation test suite |
| Prompt Injection | Guardrails | Topic/word policies | Adversarial prompts |
| DDoS | Rate Limiting | WAF 1000/5min | Load testing |

---

## Observability Architecture

### Metrics Pipeline

```mermaid
flowchart LR
    subgraph Sources["Metric Sources"]
        LAMBDA_M["Lambda<br/>Duration, Errors"]
        APIGW_M["API Gateway<br/>Latency, 4XX/5XX"]
        MEMORY_M["Bedrock Agent Memory<br/>Lookups, Latency"]
        CUSTOM["Custom Metrics<br/>TTFB, Invocations"]
    end

    subgraph CloudWatch["CloudWatch"]
        METRICS["Metrics"]
        ALARMS["Alarms"]
        DASH["Dashboard"]
    end

    subgraph Alerting["Alerting"]
        SNS_A["SNS Topic"]
        EMAIL["Email"]
        PAGER["PagerDuty"]
    end

    LAMBDA_M --> METRICS
    APIGW_M --> METRICS
    MEMORY_M --> METRICS
    CUSTOM --> METRICS

    METRICS --> ALARMS
    METRICS --> DASH
    ALARMS --> SNS_A
    SNS_A --> EMAIL
    SNS_A --> PAGER
```

### Distributed Tracing

```mermaid
flowchart TB
    subgraph XRay["X-Ray Trace"]
        SEGMENT1["API Gateway<br/>Segment"]
        SEGMENT2["Lambda<br/>Segment"]
        SUBSEG1["Bedrock Memory<br/>Subsegment"]
        SUBSEG2["Bedrock<br/>Subsegment"]
        SUBSEG3["External API<br/>Subsegment"]
    end

    SEGMENT1 --> SEGMENT2
    SEGMENT2 --> SUBSEG2
    SUBSEG2 --> SUBSEG1
    SUBSEG2 --> SUBSEG3
```

### Log Aggregation

```mermaid
flowchart LR
    subgraph LogSources["Log Sources"]
        L1["/aws/lambda/streaming-handler"]
        L2["/aws/lambda/action-group"]
        L3["/aws/apigateway/va-APPID1234"]
        L4["aws-waf-logs-va-APPID1234"]
    end

    subgraph Processing["Processing"]
        CW_LOGS["CloudWatch Logs"]
        INSIGHT["CloudWatch<br/>Logs Insights"]
    end

    subgraph Analysis["Analysis"]
        QUERY["Query by<br/>Correlation ID"]
        TENANT_Q["Query by<br/>Tenant ID"]
        ERROR_Q["Query<br/>Errors"]
    end

    L1 & L2 & L3 & L4 --> CW_LOGS
    CW_LOGS --> INSIGHT
    INSIGHT --> QUERY
    INSIGHT --> TENANT_Q
    INSIGHT --> ERROR_Q
```

---

## Release Architecture

### Blue-Green Deployment

```mermaid
stateDiagram-v2
    [*] --> Blue: Initial Deployment

    Blue --> Green: New Version Deployed
    Green --> Canary: 10% Traffic Shift

    Canary --> Monitoring: Health Check

    Monitoring --> Rollout: Healthy
    Monitoring --> Rollback: Unhealthy

    Rollout --> Green100: 100% Traffic
    Green100 --> Blue: Next Release

    Rollback --> Blue: Automatic

    state Canary {
        [*] --> Traffic10: Start
        Traffic10 --> Traffic25: 5 min
        Traffic25 --> Traffic50: 5 min
        Traffic50 --> Traffic100: 5 min
    }
```

### Deployment Pipeline

```mermaid
flowchart TB
    subgraph Validate["Validate Stage"]
        TF_VAL["Terraform Validate"]
        PY_LINT["Python Lint"]
        API_VAL["OpenAPI Validate"]
    end

    subgraph Security["Security Stage"]
        CHECKOV["Checkov Scan"]
        TFSEC["TFSec Scan"]
        BANDIT["Bandit Scan"]
    end

    subgraph Build["Build Stage"]
        LAYER["Build Lambda Layer"]
        PACKAGE["Package Functions"]
    end

    subgraph Test["Test Stage"]
        UNIT["Unit Tests"]
        COV["Coverage Report"]
    end

    subgraph Plan["Plan Stage"]
        TF_PLAN["Terraform Plan"]
    end

    subgraph Apply["Apply Stage"]
        TF_APPLY["Terraform Apply"]
    end

    subgraph Verify["Verify Stage"]
        VALIDATE["Deployment Validator"]
        SMOKE["Smoke Tests"]
    end

    Validate --> Security
    Security --> Build
    Build --> Test
    Test --> Plan
    Plan -->|"Manual Approval"| Apply
    Apply --> Verify
```

### Feature Flags

```mermaid
flowchart LR
    subgraph AppConfig["AWS AppConfig"]
        FLAGS["Feature Flags"]
        DEPLOY_STRAT["Deployment Strategy"]
    end

    subgraph Features["Available Flags"]
        F1["enable_streaming: true"]
        F2["enable_guardrails: true"]
        F3["new_appointment_flow: false"]
        F4["enhanced_logging: false"]
    end

    subgraph Lambda["Lambda Function"]
        CONFIG_EXT["AppConfig Extension"]
        FEATURE_CHECK["Feature Check"]
    end

    FLAGS --> F1 & F2 & F3 & F4
    F1 & F2 & F3 & F4 --> DEPLOY_STRAT
    DEPLOY_STRAT --> CONFIG_EXT
    CONFIG_EXT --> FEATURE_CHECK
```

---

## Cost Architecture

### Cost Breakdown (Estimated Monthly)

```mermaid
pie title Monthly Cost Distribution ($1,080 baseline)
    "Lambda Compute" : 320
    "Bedrock (Claude)" : 450
    "API Gateway" : 120
    "Bedrock Agent Memory" : 80
    "S3 + Archive" : 30
    "CloudWatch" : 50
    "Other (WAF, Secrets)" : 30
```

### Cost Optimization Strategies

| Strategy | Implementation | Savings |
|----------|----------------|---------|
| Memory retention tuning | Adjust `memory_storage_days` | ~30% |
| Reserved Concurrency | 70 streaming + 30 action | Predictable costs |
| S3 Lifecycle | Standard → Glacier → Delete | ~60% storage |
| Log Retention | 30 days (adjustable) | ~40% logs |
| Bedrock Inference | Batch prompts when possible | ~20% |

### Cost Allocation Tags

```hcl
default_tags {
  tags = {
    Project     = "TelecomAgent"
    TenantId    = "APPID1234"
    CostCenter  = "APPID1234"
    Environment = "prod"
    Owner       = "platform-team"
    ManagedBy   = "terraform"
  }
}
```

---

## Appendix

### Technology Stack

| Layer | Technology | Version |
|-------|------------|---------|
| Runtime | Python | 3.11 |
| AI/ML | AWS Bedrock | Latest |
| Model | Claude 3.5 Sonnet | v2:0 (Oct 2024) |
| IaC | Terraform | >= 1.5 |
| CI/CD | GitLab CI | Latest |
| Observability | AWS Lambda Powertools | 2.32.0 |

### Reference Links

- [AWS Bedrock Documentation](https://docs.aws.amazon.com/bedrock/)
- [API Gateway REST Streaming](https://docs.aws.amazon.com/apigateway/latest/developerguide/response-transfer-mode.html)
- [AWS Lambda Powertools](https://docs.powertools.aws.dev/lambda/python/)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
