#!/usr/bin/env python3
"""
Secret Rotation Lambda Handler

Handles automatic rotation of API credentials stored in Secrets Manager.
"""
import json
import logging
import os
from typing import Any, Dict

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def handler(event: Dict[str, Any], context: Any) -> None:
    """
    Secrets Manager rotation Lambda handler.

    This function is called by Secrets Manager during secret rotation.
    It handles four steps: createSecret, setSecret, testSecret, finishSecret
    """
    arn = event["SecretId"]
    token = event["ClientRequestToken"]
    step = event["Step"]

    secrets_client = boto3.client("secretsmanager")

    # Validate the secret version
    metadata = secrets_client.describe_secret(SecretId=arn)
    if not metadata["RotationEnabled"]:
        logger.error(f"Secret {arn} is not enabled for rotation")
        raise ValueError(f"Secret {arn} is not enabled for rotation")

    versions = metadata["VersionIdsToStages"]
    if token not in versions:
        logger.error(f"Secret version {token} has no stage for rotation")
        raise ValueError(f"Secret version {token} has no stage for rotation")

    if "AWSCURRENT" in versions[token]:
        logger.info(f"Secret version {token} already set as AWSCURRENT")
        return

    if "AWSPENDING" not in versions[token]:
        logger.error(f"Secret version {token} not set as AWSPENDING")
        raise ValueError(f"Secret version {token} not set as AWSPENDING")

    # Handle rotation step
    if step == "createSecret":
        create_secret(secrets_client, arn, token)
    elif step == "setSecret":
        set_secret(secrets_client, arn, token)
    elif step == "testSecret":
        test_secret(secrets_client, arn, token)
    elif step == "finishSecret":
        finish_secret(secrets_client, arn, token)
    else:
        raise ValueError(f"Invalid step: {step}")


def create_secret(client, arn: str, token: str) -> None:
    """
    Create the new secret version with rotated credentials.
    """
    # Check if secret already exists
    try:
        client.get_secret_value(SecretId=arn, VersionId=token, VersionStage="AWSPENDING")
        logger.info(f"createSecret: Successfully retrieved secret for {arn}.")
        return
    except client.exceptions.ResourceNotFoundException:
        pass

    # Get current secret
    current = client.get_secret_value(SecretId=arn, VersionStage="AWSCURRENT")
    current_secret = json.loads(current["SecretString"])

    # Generate new credentials
    # In production, you would call the external API to rotate credentials
    new_secret = current_secret.copy()
    new_secret["api_key"] = f"rotated-{token[:8]}"  # Placeholder

    # Store new secret
    client.put_secret_value(
        SecretId=arn,
        ClientRequestToken=token,
        SecretString=json.dumps(new_secret),
        VersionStages=["AWSPENDING"],
    )

    logger.info(f"createSecret: Successfully created new secret for {arn}.")


def set_secret(client, arn: str, token: str) -> None:
    """
    Set the new secret in the external service.
    """
    # In production, this would update the external service with new credentials
    logger.info(f"setSecret: Successfully set secret for {arn}.")


def test_secret(client, arn: str, token: str) -> None:
    """
    Test the new secret by attempting to use it.
    """
    # Get the pending secret
    pending = client.get_secret_value(SecretId=arn, VersionId=token, VersionStage="AWSPENDING")
    secret = json.loads(pending["SecretString"])

    # In production, test the credentials against the external API
    logger.info(f"testSecret: Successfully tested secret for {arn}.")


def finish_secret(client, arn: str, token: str) -> None:
    """
    Finish the secret rotation by marking the new version as current.
    """
    metadata = client.describe_secret(SecretId=arn)
    current_version = None

    for version, stages in metadata["VersionIdsToStages"].items():
        if "AWSCURRENT" in stages:
            if version == token:
                logger.info(f"finishSecret: Version {token} already marked as AWSCURRENT")
                return
            current_version = version
            break

    # Move AWSCURRENT to new version
    client.update_secret_version_stage(
        SecretId=arn,
        VersionStage="AWSCURRENT",
        MoveToVersionId=token,
        RemoveFromVersionId=current_version,
    )

    logger.info(f"finishSecret: Successfully rotated secret for {arn}.")
