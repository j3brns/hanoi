#!/bin/bash
# Build Lambda Layer for AWS Lambda Powertools and dependencies
# Version: 1.1.0

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
LAYER_DIR="${PROJECT_ROOT}/layer"
DIST_DIR="${PROJECT_ROOT}/dist"

echo "=== Building Lambda Layer ==="
echo "Project root: ${PROJECT_ROOT}"

# Clean up
rm -rf "${LAYER_DIR}"
rm -rf "${DIST_DIR}/layer.zip"
mkdir -p "${LAYER_DIR}/python"
mkdir -p "${DIST_DIR}"

# Install dependencies
echo "Installing dependencies..."
pip install \
    --target "${LAYER_DIR}/python" \
    --platform manylinux2014_x86_64 \
    --implementation cp \
    --python-version 3.11 \
    --only-binary=:all: \
    --upgrade \
    aws-lambda-powertools[all]==2.32.0 \
    httpx==0.26.0 \
    pydantic==2.5.0

# Remove unnecessary files to reduce layer size
echo "Cleaning up unnecessary files..."
find "${LAYER_DIR}" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "${LAYER_DIR}" -type d -name "*.dist-info" -exec rm -rf {} + 2>/dev/null || true
find "${LAYER_DIR}" -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
find "${LAYER_DIR}" -type f -name "*.pyc" -delete 2>/dev/null || true
find "${LAYER_DIR}" -type f -name "*.pyo" -delete 2>/dev/null || true

# Create ZIP
echo "Creating layer ZIP..."
cd "${LAYER_DIR}"
zip -r9 "${DIST_DIR}/layer.zip" python/

# Report size
LAYER_SIZE=$(du -sh "${DIST_DIR}/layer.zip" | cut -f1)
echo "=== Layer built successfully ==="
echo "Layer size: ${LAYER_SIZE}"
echo "Output: ${DIST_DIR}/layer.zip"

# Verify layer size (must be under 250MB unzipped, 50MB zipped for direct upload)
UNZIPPED_SIZE=$(unzip -l "${DIST_DIR}/layer.zip" | tail -1 | awk '{print $1}')
echo "Unzipped size: ${UNZIPPED_SIZE} bytes"

if [ "$UNZIPPED_SIZE" -gt 262144000 ]; then
    echo "WARNING: Layer exceeds 250MB unzipped limit!"
    exit 1
fi

echo "Layer is within size limits."
