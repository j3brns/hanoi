#!/usr/bin/env python3
"""
Agent Canary Monitoring Script

Monitors Bedrock Agent metrics during canary deployment to detect:
- Error rate spikes
- Latency degradation
- Throughput anomalies

Used in CI/CD pipeline to validate canary deployments before promotion.
"""
import argparse
import sys
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

import boto3
from botocore.config import Config

# Initialize clients
boto_config = Config(retries={"max_attempts": 3, "mode": "adaptive"})
cloudwatch = boto3.client("cloudwatch", config=boto_config)
bedrock_agent = boto3.client("bedrock-agent-runtime", config=boto_config)


def get_metric_statistics(
    namespace: str,
    metric_name: str,
    dimensions: List[Dict[str, str]],
    start_time: datetime,
    end_time: datetime,
    period: int = 60,
    statistics: List[str] = None,
) -> List[Dict]:
    """Get CloudWatch metric statistics."""
    if statistics is None:
        statistics = ["Sum", "Average", "Maximum"]

    try:
        response = cloudwatch.get_metric_statistics(
            Namespace=namespace,
            MetricName=metric_name,
            Dimensions=dimensions,
            StartTime=start_time,
            EndTime=end_time,
            Period=period,
            Statistics=statistics,
        )
        return response.get("Datapoints", [])
    except Exception as e:
        print(f"Error getting metric {metric_name}: {e}")
        return []


def calculate_error_rate(
    agent_id: str,
    alias_id: str,
    start_time: datetime,
    end_time: datetime,
) -> Tuple[float, int, int]:
    """
    Calculate error rate for an agent alias.

    Returns:
        Tuple of (error_rate_percent, error_count, invocation_count)
    """
    dimensions = [
        {"Name": "AgentId", "Value": agent_id},
        {"Name": "AgentAliasId", "Value": alias_id},
    ]

    # Get invocations
    invocations = get_metric_statistics(
        namespace="AWS/Bedrock",
        metric_name="Invocations",
        dimensions=dimensions,
        start_time=start_time,
        end_time=end_time,
        statistics=["Sum"],
    )

    # Get errors
    errors = get_metric_statistics(
        namespace="AWS/Bedrock",
        metric_name="InvocationErrors",
        dimensions=dimensions,
        start_time=start_time,
        end_time=end_time,
        statistics=["Sum"],
    )

    total_invocations = sum(dp.get("Sum", 0) for dp in invocations)
    total_errors = sum(dp.get("Sum", 0) for dp in errors)

    error_rate = (total_errors / total_invocations * 100) if total_invocations > 0 else 0

    return error_rate, int(total_errors), int(total_invocations)


def calculate_latency_stats(
    agent_id: str,
    alias_id: str,
    start_time: datetime,
    end_time: datetime,
) -> Dict[str, float]:
    """
    Calculate latency statistics for an agent alias.

    Returns:
        Dict with avg, p50, p90, p99, max latency in ms
    """
    dimensions = [
        {"Name": "AgentId", "Value": agent_id},
        {"Name": "AgentAliasId", "Value": alias_id},
    ]

    # Get latency metrics
    latency_data = get_metric_statistics(
        namespace="AWS/Bedrock",
        metric_name="InvocationLatency",
        dimensions=dimensions,
        start_time=start_time,
        end_time=end_time,
        statistics=["Average", "Maximum"],
    )

    if not latency_data:
        return {"avg": 0, "max": 0}

    avg_latencies = [dp.get("Average", 0) for dp in latency_data if dp.get("Average")]
    max_latencies = [dp.get("Maximum", 0) for dp in latency_data if dp.get("Maximum")]

    return {
        "avg": sum(avg_latencies) / len(avg_latencies) if avg_latencies else 0,
        "max": max(max_latencies) if max_latencies else 0,
    }


def compare_aliases(
    agent_id: str,
    blue_alias_id: str,
    green_alias_id: str,
    start_time: datetime,
    end_time: datetime,
) -> Dict[str, Dict]:
    """Compare metrics between blue and green aliases."""
    results = {}

    for alias_name, alias_id in [("blue", blue_alias_id), ("green", green_alias_id)]:
        error_rate, errors, invocations = calculate_error_rate(
            agent_id, alias_id, start_time, end_time
        )
        latency = calculate_latency_stats(agent_id, alias_id, start_time, end_time)

        results[alias_name] = {
            "alias_id": alias_id,
            "error_rate": error_rate,
            "error_count": errors,
            "invocation_count": invocations,
            "avg_latency_ms": latency["avg"],
            "max_latency_ms": latency["max"],
        }

    return results


def check_thresholds(
    metrics: Dict[str, Dict],
    error_threshold: float,
    latency_threshold: float,
) -> Tuple[bool, List[str]]:
    """
    Check if canary metrics exceed thresholds.

    Returns:
        Tuple of (passed, list_of_failures)
    """
    failures = []

    green_metrics = metrics.get("green", {})
    blue_metrics = metrics.get("blue", {})

    # Check absolute error rate
    if green_metrics.get("error_rate", 0) > error_threshold:
        failures.append(
            f"Green error rate ({green_metrics['error_rate']:.2f}%) exceeds threshold ({error_threshold}%)"
        )

    # Check if green error rate is significantly higher than blue
    if (
        green_metrics.get("error_rate", 0) > blue_metrics.get("error_rate", 0) * 2
        and green_metrics.get("invocation_count", 0) > 10  # Minimum sample size
    ):
        failures.append(
            f"Green error rate ({green_metrics['error_rate']:.2f}%) is 2x higher than blue ({blue_metrics['error_rate']:.2f}%)"
        )

    # Check absolute latency
    if green_metrics.get("avg_latency_ms", 0) > latency_threshold:
        failures.append(
            f"Green avg latency ({green_metrics['avg_latency_ms']:.0f}ms) exceeds threshold ({latency_threshold}ms)"
        )

    # Check if green latency is significantly higher than blue
    if (
        green_metrics.get("avg_latency_ms", 0) > blue_metrics.get("avg_latency_ms", 1) * 1.5
        and green_metrics.get("invocation_count", 0) > 10
    ):
        failures.append(
            f"Green avg latency ({green_metrics['avg_latency_ms']:.0f}ms) is 50%+ higher than blue ({blue_metrics['avg_latency_ms']:.0f}ms)"
        )

    return len(failures) == 0, failures


def monitor_canary(
    agent_id: str,
    blue_alias_id: str,
    green_alias_id: str,
    duration_minutes: int,
    error_threshold: float,
    latency_threshold: float,
    check_interval_seconds: int = 60,
) -> bool:
    """
    Monitor canary deployment for specified duration.

    Returns:
        True if canary passed all checks, False otherwise
    """
    print(f"\n{'='*60}")
    print(f"CANARY MONITORING STARTED")
    print(f"Duration: {duration_minutes} minutes")
    print(f"Error threshold: {error_threshold}%")
    print(f"Latency threshold: {latency_threshold}ms")
    print(f"{'='*60}\n")

    start_time = datetime.now(timezone.utc)
    end_time = start_time + timedelta(minutes=duration_minutes)

    check_count = 0
    all_passed = True

    while datetime.now(timezone.utc) < end_time:
        check_count += 1
        current_time = datetime.now(timezone.utc)
        window_start = current_time - timedelta(minutes=5)

        print(f"\n[Check #{check_count}] {current_time.strftime('%H:%M:%S UTC')}")
        print("-" * 40)

        # Get comparison metrics
        metrics = compare_aliases(
            agent_id,
            blue_alias_id,
            green_alias_id,
            window_start,
            current_time,
        )

        # Print metrics
        for alias_name, alias_metrics in metrics.items():
            print(f"\n{alias_name.upper()} ({alias_metrics['alias_id'][:8]}...):")
            print(f"  Invocations: {alias_metrics['invocation_count']}")
            print(f"  Errors: {alias_metrics['error_count']} ({alias_metrics['error_rate']:.2f}%)")
            print(f"  Avg Latency: {alias_metrics['avg_latency_ms']:.0f}ms")
            print(f"  Max Latency: {alias_metrics['max_latency_ms']:.0f}ms")

        # Check thresholds
        passed, failures = check_thresholds(metrics, error_threshold, latency_threshold)

        if not passed:
            all_passed = False
            print("\n⚠️  THRESHOLD VIOLATIONS:")
            for failure in failures:
                print(f"  - {failure}")

            # Check if we should fail fast (3 consecutive failures)
            if check_count >= 3:
                print("\n❌ CANARY FAILED - Multiple threshold violations detected")
                return False
        else:
            print("\n✅ All thresholds within limits")

        # Wait for next check
        remaining = (end_time - datetime.now(timezone.utc)).total_seconds()
        if remaining > check_interval_seconds:
            print(f"\nNext check in {check_interval_seconds}s... ({remaining/60:.1f} min remaining)")
            time.sleep(check_interval_seconds)

    print(f"\n{'='*60}")
    if all_passed:
        print("✅ CANARY MONITORING COMPLETED SUCCESSFULLY")
    else:
        print("⚠️  CANARY COMPLETED WITH WARNINGS")
    print(f"{'='*60}\n")

    return all_passed


def main():
    parser = argparse.ArgumentParser(description="Monitor Bedrock Agent canary deployment")
    parser.add_argument("--agent-id", required=True, help="Bedrock Agent ID")
    parser.add_argument("--blue-alias", required=True, help="Blue (stable) alias ID")
    parser.add_argument("--green-alias", required=True, help="Green (canary) alias ID")
    parser.add_argument("--duration", type=int, default=15, help="Monitoring duration in minutes")
    parser.add_argument("--error-threshold", type=float, default=5.0, help="Error rate threshold (%)")
    parser.add_argument("--latency-threshold", type=float, default=2000, help="Latency threshold (ms)")
    parser.add_argument("--check-interval", type=int, default=60, help="Check interval in seconds")

    args = parser.parse_args()

    success = monitor_canary(
        agent_id=args.agent_id,
        blue_alias_id=args.blue_alias,
        green_alias_id=args.green_alias,
        duration_minutes=args.duration,
        error_threshold=args.error_threshold,
        latency_threshold=args.latency_threshold,
        check_interval_seconds=args.check_interval,
    )

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
