#!/usr/bin/env python3
"""
Deployment Validator Script

Validates deployment health after Terraform apply:
1. Lambda function health checks
2. API Gateway endpoint tests
3. DynamoDB table accessibility
4. CloudWatch metrics validation

Usage:
    python deployment_validator.py --environment dev
"""
import argparse
import json
import os
import sys
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError


class DeploymentValidator:
    """Validates deployment health."""

    def __init__(self, environment: str, tenant_prefix: str = "APPID1234"):
        self.environment = environment
        self.tenant_prefix = tenant_prefix
        self.resource_prefix = f"va-{tenant_prefix}"
        self.region = os.environ.get("AWS_REGION", "us-east-1")

        # Initialize clients
        self.lambda_client = boto3.client("lambda", region_name=self.region)
        self.dynamodb = boto3.resource("dynamodb", region_name=self.region)
        self.cloudwatch = boto3.client("cloudwatch", region_name=self.region)
        self.apigateway = boto3.client("apigateway", region_name=self.region)

        self.results: List[Dict[str, Any]] = []

    def log(self, message: str, level: str = "INFO"):
        """Log message with timestamp."""
        timestamp = datetime.now().isoformat()
        print(f"[{timestamp}] [{level}] {message}")

    def add_result(self, check: str, passed: bool, details: str = ""):
        """Add validation result."""
        self.results.append({
            "check": check,
            "passed": passed,
            "details": details,
        })
        status = "PASS" if passed else "FAIL"
        self.log(f"{check}: {status} - {details}", "INFO" if passed else "ERROR")

    def validate_lambda_functions(self) -> bool:
        """Validate Lambda functions are deployed and healthy."""
        self.log("Validating Lambda functions...")

        functions = [
            f"{self.resource_prefix}-streaming-handler-{self.environment}",
            f"{self.resource_prefix}-action-group-{self.environment}",
            f"{self.resource_prefix}-health-handler-{self.environment}",
        ]

        all_passed = True
        for func_name in functions:
            try:
                response = self.lambda_client.get_function(FunctionName=func_name)
                state = response["Configuration"]["State"]

                if state == "Active":
                    self.add_result(
                        f"Lambda: {func_name}",
                        True,
                        f"State: {state}, Runtime: {response['Configuration']['Runtime']}",
                    )
                else:
                    self.add_result(
                        f"Lambda: {func_name}",
                        False,
                        f"State: {state} (expected: Active)",
                    )
                    all_passed = False

            except ClientError as e:
                self.add_result(
                    f"Lambda: {func_name}",
                    False,
                    f"Error: {e.response['Error']['Message']}",
                )
                all_passed = False

        return all_passed

    def validate_lambda_aliases(self) -> bool:
        """Validate Lambda aliases are configured."""
        self.log("Validating Lambda aliases...")

        functions = [
            f"{self.resource_prefix}-streaming-handler-{self.environment}",
            f"{self.resource_prefix}-action-group-{self.environment}",
        ]

        all_passed = True
        for func_name in functions:
            try:
                response = self.lambda_client.get_alias(
                    FunctionName=func_name,
                    Name="prod",
                )
                self.add_result(
                    f"Lambda Alias: {func_name}:prod",
                    True,
                    f"Version: {response['FunctionVersion']}",
                )
            except ClientError as e:
                # Alias might not exist yet, which is okay for dev
                if self.environment == "dev":
                    self.add_result(
                        f"Lambda Alias: {func_name}:prod",
                        True,
                        "Alias not yet created (expected for dev)",
                    )
                else:
                    self.add_result(
                        f"Lambda Alias: {func_name}:prod",
                        False,
                        f"Error: {e.response['Error']['Message']}",
                    )
                    all_passed = False

        return all_passed

    def validate_dynamodb_tables(self) -> bool:
        """Validate DynamoDB tables are accessible."""
        self.log("Validating DynamoDB tables...")

        tables = [
            f"{self.resource_prefix}-sessions-{self.environment}",
            f"{self.resource_prefix}-audit-logs-{self.environment}",
            f"{self.resource_prefix}-async-requests-{self.environment}",
        ]

        all_passed = True
        for table_name in tables:
            try:
                table = self.dynamodb.Table(table_name)
                status = table.table_status

                if status == "ACTIVE":
                    self.add_result(
                        f"DynamoDB: {table_name}",
                        True,
                        f"Status: {status}, Items: {table.item_count}",
                    )
                else:
                    self.add_result(
                        f"DynamoDB: {table_name}",
                        False,
                        f"Status: {status} (expected: ACTIVE)",
                    )
                    all_passed = False

            except ClientError as e:
                self.add_result(
                    f"DynamoDB: {table_name}",
                    False,
                    f"Error: {e.response['Error']['Message']}",
                )
                all_passed = False

        return all_passed

    def validate_api_gateway(self) -> bool:
        """Validate API Gateway is deployed."""
        self.log("Validating API Gateway...")

        api_name = f"{self.resource_prefix}-api-{self.environment}"

        try:
            response = self.apigateway.get_rest_apis()
            api = next(
                (a for a in response["items"] if a["name"] == api_name),
                None,
            )

            if api:
                # Check stage exists
                stages = self.apigateway.get_stages(restApiId=api["id"])
                stage = next(
                    (s for s in stages["item"] if s["stageName"] == self.environment),
                    None,
                )

                if stage:
                    self.add_result(
                        f"API Gateway: {api_name}",
                        True,
                        f"Stage: {self.environment}, URL: https://{api['id']}.execute-api.{self.region}.amazonaws.com/{self.environment}",
                    )
                    return True
                else:
                    self.add_result(
                        f"API Gateway: {api_name}",
                        False,
                        f"Stage {self.environment} not found",
                    )
            else:
                self.add_result(
                    f"API Gateway: {api_name}",
                    False,
                    "API not found",
                )

        except ClientError as e:
            self.add_result(
                f"API Gateway: {api_name}",
                False,
                f"Error: {e.response['Error']['Message']}",
            )

        return False

    def validate_health_endpoint(self) -> bool:
        """Invoke health check Lambda directly."""
        self.log("Validating health endpoint...")

        func_name = f"{self.resource_prefix}-health-handler-{self.environment}"

        try:
            response = self.lambda_client.invoke(
                FunctionName=func_name,
                InvocationType="RequestResponse",
                Payload=json.dumps({
                    "httpMethod": "GET",
                    "path": "/health",
                    "headers": {},
                    "requestContext": {"requestId": "test-validation"},
                }),
            )

            payload = json.loads(response["Payload"].read())

            if response["StatusCode"] == 200:
                body = json.loads(payload.get("body", "{}"))
                status = body.get("status", "unknown")

                if status == "healthy":
                    self.add_result(
                        "Health Endpoint",
                        True,
                        f"Status: {status}, Version: {body.get('version', 'unknown')}",
                    )
                    return True
                else:
                    self.add_result(
                        "Health Endpoint",
                        False,
                        f"Status: {status} (expected: healthy)",
                    )
            else:
                self.add_result(
                    "Health Endpoint",
                    False,
                    f"HTTP Status: {response['StatusCode']}",
                )

        except Exception as e:
            self.add_result(
                "Health Endpoint",
                False,
                f"Error: {str(e)}",
            )

        return False

    def validate_cloudwatch_alarms(self) -> bool:
        """Validate CloudWatch alarms are not in ALARM state."""
        self.log("Validating CloudWatch alarms...")

        try:
            response = self.cloudwatch.describe_alarms(
                AlarmNamePrefix=self.resource_prefix,
                StateValue="ALARM",
            )

            alarms_in_alarm = response.get("MetricAlarms", [])

            if not alarms_in_alarm:
                self.add_result(
                    "CloudWatch Alarms",
                    True,
                    "No alarms in ALARM state",
                )
                return True
            else:
                alarm_names = [a["AlarmName"] for a in alarms_in_alarm]
                self.add_result(
                    "CloudWatch Alarms",
                    False,
                    f"Alarms in ALARM state: {', '.join(alarm_names)}",
                )

        except ClientError as e:
            self.add_result(
                "CloudWatch Alarms",
                False,
                f"Error: {e.response['Error']['Message']}",
            )

        return False

    def validate_lambda_concurrency(self) -> bool:
        """Validate Lambda reserved concurrency matches spec."""
        self.log("Validating Lambda concurrency settings...")

        expected_concurrency = {
            f"{self.resource_prefix}-streaming-handler-{self.environment}": 70,
            f"{self.resource_prefix}-action-group-{self.environment}": 30,
        }

        all_passed = True
        for func_name, expected in expected_concurrency.items():
            try:
                response = self.lambda_client.get_function_concurrency(
                    FunctionName=func_name
                )
                actual = response.get("ReservedConcurrentExecutions", 0)

                if actual == expected:
                    self.add_result(
                        f"Concurrency: {func_name}",
                        True,
                        f"Reserved: {actual} (expected: {expected})",
                    )
                else:
                    self.add_result(
                        f"Concurrency: {func_name}",
                        False,
                        f"Reserved: {actual} (expected: {expected})",
                    )
                    all_passed = False

            except ClientError as e:
                # If no reserved concurrency, it returns error
                self.add_result(
                    f"Concurrency: {func_name}",
                    False,
                    f"No reserved concurrency set (expected: {expected})",
                )
                all_passed = False

        return all_passed

    def run_all_validations(self) -> bool:
        """Run all validation checks."""
        self.log(f"Starting deployment validation for environment: {self.environment}")
        self.log("=" * 60)

        checks = [
            self.validate_lambda_functions,
            self.validate_lambda_aliases,
            self.validate_dynamodb_tables,
            self.validate_api_gateway,
            self.validate_health_endpoint,
            self.validate_cloudwatch_alarms,
            self.validate_lambda_concurrency,
        ]

        for check in checks:
            try:
                check()
            except Exception as e:
                self.log(f"Check failed with exception: {e}", "ERROR")
            self.log("-" * 40)

        # Summary
        self.log("=" * 60)
        passed = sum(1 for r in self.results if r["passed"])
        total = len(self.results)
        self.log(f"Validation Summary: {passed}/{total} checks passed")

        failed_checks = [r for r in self.results if not r["passed"]]
        if failed_checks:
            self.log("Failed checks:", "ERROR")
            for check in failed_checks:
                self.log(f"  - {check['check']}: {check['details']}", "ERROR")
            return False

        self.log("All validation checks passed!", "INFO")
        return True


def main():
    parser = argparse.ArgumentParser(description="Validate deployment health")
    parser.add_argument(
        "--environment",
        required=True,
        choices=["dev", "staging", "prod"],
        help="Environment to validate",
    )
    parser.add_argument(
        "--tenant-prefix",
        default="APPID1234",
        help="Tenant prefix for resource naming",
    )
    args = parser.parse_args()

    validator = DeploymentValidator(
        environment=args.environment,
        tenant_prefix=args.tenant_prefix,
    )

    success = validator.run_all_validations()
    sys.exit(0 if success else 1)


# Lambda handler for EventBridge invocation
def handler(event, context):
    """Lambda handler for automated validation."""
    environment = os.environ.get("ENVIRONMENT", "dev")

    validator = DeploymentValidator(environment=environment)
    success = validator.run_all_validations()

    return {
        "statusCode": 200 if success else 500,
        "body": json.dumps({
            "success": success,
            "results": validator.results,
        }),
    }


if __name__ == "__main__":
    main()
