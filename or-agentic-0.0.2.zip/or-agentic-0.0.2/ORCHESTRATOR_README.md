# Bedrock Agents Orchestrator Pattern

Production-ready multi-agent collaboration system built on AWS Bedrock, implementing the orchestrator pattern with five specialized collaborator agents.

## Quick Start

```bash
# Navigate to orchestrator root
cd terraform/orchestrator-root

# Initialize Terraform
terraform init

# Deploy to development
terraform apply -var-file=environments/dev.tfvars

# Get orchestrator endpoint
terraform output orchestrator_endpoint
```

## Architecture Overview

### Multi-Agent Collaboration

```
┌─────────────────────────────────────────────────────────────────┐
│                      CUSTOMER REQUEST                            │
│              "Book a repair appointment for tomorrow"            │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │   ORCHESTRATOR       │
              │   Main Controller    │
              │   - Route requests   │
              │   - Coordinate flow  │
              │   - Synthesize       │
              └──────────┬───────────┘
                         │
         ┌───────────────┼────────────────┬──────────────┐
         │               │                │              │
         ▼               ▼                ▼              ▼
    ┌────────┐      ┌────────┐      ┌─────────┐   ┌──────────┐
    │ Agent  │      │ Agent  │      │ Agent   │   │ Agent    │
    │   01   │      │   02   │      │   03    │   │   04/05  │
    │Appoint.│      │  Time  │      │Calendar │   │Notif/Anal│
    └────────┘      └────────┘      └─────────┘   └──────────┘
         │               │                │              │
         ▼               ▼                ▼              ▼
    [External      [Python          [Python        [Python
     API Mock]     Functions]       Functions]     Functions]
```

### Agent Specializations

| Agent | Alias | Type | Capabilities |
|-------|-------|------|--------------|
| Orchestrator | `orchestrator` | Controller | Request routing, coordination, synthesis |
| Agent 01 | `appointments` | API | Book, reschedule, cancel appointments |
| Agent 02 | `time` | Python | Timezone conversion, business hours validation |
| Agent 03 | `calendar` | Python | Calendar management, availability search |
| Agent 04 | `notifications` | Python | Multi-channel notifications (email/SMS/push) |
| Agent 05 | `analytics` | Python | Metrics, insights, reporting |

## Three-Tier Architecture

### Tier 1: Security & IAM
**Owner**: SecOps Serena / Infra Dan

High-value, low-churn security infrastructure:
- **6 IAM Execution Roles**: One per agent with least-privilege permissions
- **Trust Policies**: Prevent confused deputy attacks
- **KMS Keys**: Session state encryption
- **Service Control**: Orchestrator can invoke sub-agents

**Module**: `terraform/modules/orchestrator/security/`

### Tier 2: Action Groups & Logic
**Owner**: MLE Alice / Dev Bob

Business logic and tooling layer:
- **5 Lambda Functions**: Action handlers for each collaborator agent
- **OpenAPI Schemas**: API definitions stored in S3
- **Lambda Permissions**: Allow Bedrock to invoke functions
- **CloudWatch Logs**: Structured logging with AWS Powertools

**Module**: `terraform/modules/orchestrator/action_groups/`

### Tier 3: Orchestration & Agents
**Owner**: Agent Anna / MLE Alice

Agent lifecycle and release management:
- **6 Bedrock Agents**: Orchestrator + 5 collaborators
- **Prepare Associations**: Critical for versioning lifecycle
- **Aliases**: Production, staging, dev endpoints
- **Environment Aliases**: Latest prepared version per environment

**Module**: `terraform/modules/orchestrator/agent/`

## Key Features

### ✅ Production-Ready
- **AWS Lambda Powertools**: Structured logging, tracing, metrics
- **Error Handling**: Comprehensive exception handling with retries
- **Input Validation**: Pydantic models for type safety
- **Observability**: CloudWatch Logs, X-Ray tracing

### ✅ Deployment Strategies
- **Environment Alias**: Each environment alias points to the latest prepared version
- **Rollback**: Revert inputs (or git commit) and re-apply to restore a prior version

### ✅ Security First
- **IAM Least Privilege**: Each agent has minimal required permissions
- **Confused Deputy Prevention**: SourceAccount conditions
- **KMS Encryption**: Agent session state encrypted
- **Guardrails Support**: Content filtering (optional)

### ✅ Developer Experience
- **Modular Design**: Three-tier separation of concerns
- **Environment Configs**: Dev, staging, prod tfvars
- **Type Safety**: Pydantic models, TypedDicts
- **Clear Documentation**: Comprehensive guides

## File Structure

```
.
├── src/orchestrator/
│   ├── action_handlers/
│   │   ├── appointments_api/         # Agent 01 (API)
│   │   │   ├── handler.py
│   │   │   └── openapi_schema.json
│   │   ├── agent_02_time/            # Agent 02 (Python)
│   │   │   ├── handler.py
│   │   │   └── openapi_schema.json
│   │   ├── agent_03_calendar/        # Agent 03 (Python)
│   │   │   └── handler.py
│   │   ├── agent_04_notifications/   # Agent 04 (Python)
│   │   │   └── handler.py
│   │   └── agent_05_analytics/       # Agent 05 (Python)
│   │       └── handler.py
│   └── agents/
│
├── terraform/
│   ├── modules/orchestrator/
│   │   ├── security/                 # Tier 1: IAM, KMS
│   │   │   ├── main.tf
│   │   │   └── variables.tf
│   │   ├── action_groups/            # Tier 2: Lambdas, Schemas
│   │   │   ├── main.tf
│   │   │   └── variables.tf
│   │   └── agent/                    # Tier 3: Agents, Aliases
│   │       ├── main.tf
│   │       ├── variables.tf
│   │       └── prompts/              # Agent system prompts
│   │           ├── orchestrator.txt
│   │           ├── agent_01_appointments.txt
│   │           ├── agent_02_time.txt
│   │           ├── agent_03_calendar.txt
│   │           ├── agent_04_notifications.txt
│   │           └── agent_05_analytics.txt
│   │
│   └── orchestrator-root/            # Root orchestrator module
│       ├── main.tf
│       ├── variables.tf
│       └── environments/
│           ├── dev.tfvars
│           ├── staging.tfvars
│           └── prod.tfvars
│
└── docs/
    └── orchestrator-deployment.md    # Comprehensive deployment guide
```

## Action Group Lambda Locations

- **Lambda source code**: `src/orchestrator/action_handlers/<action_group>/handler.py`
- **Action group names** (Terraform): `appointments_api`, `time_management`, `calendar_ops`, `notifications`, `analytics`
- **OpenAPI schemas** are currently present for:
  - `appointments_api/openapi_schema.json`
  - `agent_02_time/openapi_schema.json` (used by the `time_management` action group)
  - Additional schemas should be added if you expand action group interfaces.

## Environment Configurations

### Development
```bash
terraform apply -var-file=environments/dev.tfvars
```
- **Logging**: DEBUG level
- **Retention**: 7 days
- **Guardrails**: Disabled for speed
- **Memory**: 7 days
- **Lambda Layer**: Disabled (inline deps)

### Staging
```bash
terraform apply -var-file=environments/staging.tfvars
```
- **Logging**: INFO level
- **Retention**: 30 days
- **Guardrails**: Enabled (DRAFT)
- **Memory**: 30 days
- **Lambda Layer**: Enabled

### Production
```bash
terraform apply -var-file=environments/prod.tfvars
```
- **Logging**: WARNING level
- **Retention**: 90 days
- **Guardrails**: Enabled (versioned)
- **Memory**: 90 days
- **Lambda Layer**: Enabled

## Agent Capabilities

### Orchestrator
```
Role: Main coordinator and request router
Capabilities:
  - Route to specialized agents
  - Coordinate multi-agent workflows
  - Synthesize responses
  - Handle errors and fallbacks
```

### Agent 01: Appointments (API)
```python
# Available Functions
- viewAppointments(customer_id)
- searchSlots(service_type, start_date, end_date)
- bookAppointment(customer_id, slot_id, service_type)
- rescheduleAppointment(appointment_id, new_slot_id)
- cancelAppointment(appointment_id)

# Service Types
installation, repair, upgrade, maintenance
```

### Agent 02: Time Management (Python)
```python
# Available Functions
- getCurrentTime(timezone)
- convertTimezone(time, from_tz, to_tz)
- checkBusinessHours(time, timezone)
- calculateDuration(start_time, end_time)
- findNextBusinessDay(start_date)
- checkTimeConflicts(appointments)

# Business Hours
Monday-Friday, 9 AM - 5 PM (Eastern Time)
```

### Agent 03: Calendar Operations (Python)
```python
# Available Functions
- createCalendarEvent(calendar_id, title, start, end, ...)
- getCalendarEvents(calendar_id, start_date, end_date)
- findAvailableSlots(calendar_id, start, end, duration)
- updateCalendarEvent(event_id, updates)
- deleteCalendarEvent(event_id)
- getCalendarSummary(calendar_id, date)
```

### Agent 04: Notifications (Python)
```python
# Available Functions
- sendNotification(user_id, channel, template_id, data)
- sendBulkNotifications(user_ids, channel, template_id)
- getNotificationStatus(notification_id)
- getUserNotifications(user_id, limit, status)
- updateUserPreferences(user_id, preferences)
- getUserPreferences(user_id)
- listTemplates()

# Channels
email, sms, push

# Templates
appointment_confirmation, appointment_reminder,
appointment_cancelled, appointment_rescheduled
```

### Agent 05: Analytics (Python)
```python
# Available Functions
- trackAppointmentEvent(event_type, appointment_id, ...)
- getAppointmentMetrics(start_date, end_date, service_type)
- getServiceTypeDistribution(start_date, end_date)
- getCustomerInsights(customer_id)
- getTrendAnalysis(metric, start_date, end_date, interval)
- generateReport(report_type, start_date, end_date)

# Metrics
total_appointments, completion_rate, cancellation_rate,
service_type_distribution, customer_lifetime_value
```

## Deployment Workflow

### Initial Deployment

```bash
# 1. Review configuration
cat terraform/orchestrator-root/environments/dev.tfvars

# 2. Initialize
cd terraform/orchestrator-root
terraform init

# 3. Plan
terraform plan -var-file=environments/dev.tfvars -out=tfplan

# 4. Apply
terraform apply tfplan

# 5. Verify
terraform output orchestrator_endpoint
```

### Update Deployment

```bash
# 1. Make changes (e.g., update agent prompt)
vim terraform/modules/orchestrator/agent/prompts/agent_01_appointments.txt

# 2. Apply changes
terraform apply -var-file=environments/prod.tfvars

# 3. Monitor logs/metrics and validate behavior
```

### Rollback

```bash
# Rollback by reverting the change and re-applying
git revert HEAD
terraform apply -var-file=environments/prod.tfvars
```

## Testing

### Invoke Orchestrator

```python
import boto3
import json

client = boto3.client('bedrock-agent-runtime')

# Invoke orchestrator
response = client.invoke_agent(
    agentId='ORCHESTRATOR_AGENT_ID',
    agentAliasId='ORCHESTRATOR_ALIAS_ID',
    sessionId='test-session-123',
    inputText='Book a repair appointment for tomorrow at 2 PM'
)

# Stream response
for event in response['completion']:
    if 'chunk' in event:
        chunk = event['chunk']['bytes'].decode('utf-8')
        print(chunk, end='', flush=True)
```

### Expected Flow

```
User: "Book a repair appointment for tomorrow at 2 PM"
  ↓
Orchestrator: Routes to time agent → Validates business hours
  ↓
Orchestrator: Routes to appointments agent → Searches slots
  ↓
Appointments Agent: Finds available slot at 2 PM
  ↓
Orchestrator: Routes to appointments agent → Books appointment
  ↓
Orchestrator: Routes to notifications agent → Sends confirmation
  ↓
Response: "Appointment booked! Confirmation ID: APT-123456"
```

## Monitoring

### CloudWatch Logs
- `/aws/lambda/bedrock-orchestrator-appointments_api`
- `/aws/lambda/bedrock-orchestrator-time_management`
- `/aws/lambda/bedrock-orchestrator-calendar_ops`
- `/aws/lambda/bedrock-orchestrator-notifications`
- `/aws/lambda/bedrock-orchestrator-analytics`

### Key Metrics
- Agent invocations
- Action group errors
- Response latency (p50, p99)
- Throttling events

### Alarms (Recommended)

```hcl
resource "aws_cloudwatch_metric_alarm" "agent_errors" {
  alarm_name          = "orchestrator-agent-errors"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = "2"
  metric_name         = "Errors"
  namespace           = "AWS/Bedrock"
  period              = "300"
  statistic           = "Sum"
  threshold           = "10"
}
```

## Cost Estimates

| Environment | Monthly Cost | Usage Assumption |
|-------------|--------------|------------------|
| Development | $50-100 | 1K invocations/day |
| Staging | $100-200 | 5K invocations/day |
| Production | $200-500 | 50K invocations/day |

**Cost Breakdown:**
- Bedrock invocations: ~60% of cost
- Lambda executions: ~30% of cost
- CloudWatch Logs: ~10% of cost

## Security Considerations

### IAM Roles
Each agent has a unique execution role with:
- Bedrock model invocation permissions
- CloudWatch Logs write access
- KMS decrypt for session state
- Lambda invoke (for action groups only)
- Orchestrator: Additional permissions to invoke sub-agents

### Trust Policies
All roles include confused deputy prevention:
```json
{
  "Condition": {
    "StringEquals": {
      "aws:SourceAccount": "123456789012"
    },
    "ArnLike": {
      "aws:SourceArn": "arn:aws:bedrock:*:123456789012:agent/*"
    }
  }
}
```

### Guardrails
Optional content filtering:
- Hate speech detection
- Violence detection
- Sexual content filtering
- PII redaction

## Troubleshooting

### Common Issues

**Issue**: "Agent not found"
```bash
# Check if agent was prepared
terraform state show 'module.agent.aws_bedrockagent_agent_agent_version.orchestrator_prepared'

# Verify alias points to version
terraform state show 'module.agent.aws_bedrockagent_agent_alias.orchestrator'
```

**Issue**: "Lambda permission denied"
```bash
# Check Lambda resource policy
aws lambda get-policy \
  --function-name bedrock-orchestrator-appointments_api
```

**Issue**: "Schema not found"
```bash
# Verify S3 upload
aws s3 ls s3://bedrock-orchestrator-openapi-schemas-*/
```

## Documentation

- **[Deployment Guide](docs/orchestrator-deployment.md)**: Comprehensive deployment instructions
- **[Architecture Diagram](docs/architecture.md)**: Visual architecture reference
- **[API Reference](src/orchestrator/action_handlers/)**: OpenAPI schemas for each agent

## Support

**Questions?**
- Review CloudWatch Logs for errors
- Check Terraform state: `terraform show`
- Verify IAM permissions

**Issues?**
- Create GitHub issue with logs and Terraform output
- Include agent IDs and session IDs for debugging

## Contributing

1. Fork repository
2. Create feature branch
3. Update agent prompts or Lambda handlers
4. Test in dev environment
5. Submit pull request

## License

MIT License - See LICENSE file for details

---

**Built with ❤️ using AWS Bedrock, Terraform, and Python**

**Version**: 1.0.0
**Last Updated**: 2026-01-10
**Maintained By**: Platform Engineering Team
