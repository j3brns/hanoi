# Bedrock Agent Patterns for Telecommunications

[![CI/CD Pipeline](https://img.shields.io/badge/CI%2FCD-GitLab-orange)](https://gitlab.com)
[![Terraform](https://img.shields.io/badge/Terraform-%3E%3D1.5-purple)](https://terraform.io)
[![Python](https://img.shields.io/badge/Python-3.11-blue)](https://python.org)
[![AWS](https://img.shields.io/badge/AWS-Bedrock-yellow)](https://aws.amazon.com/bedrock/)

Production-ready AWS Bedrock Agent patterns for telecommunications appointment management. This repository demonstrates two complementary architectures:

1. **Single-Agent Pattern**: Multi-tenant virtual assistant with streaming responses
2. **Orchestrator Pattern**: Multi-agent collaboration with specialized capabilities (NEW)

## Architecture Patterns

### Pattern 1: Single-Agent Multi-Tenant (Original)

Single Bedrock Agent serving multiple tenants with strict isolation.

```mermaid
flowchart TB
    subgraph Clients["Clients"]
        T1[Client A]
        T2[Client B]
    end

    subgraph AWS["AWS Cloud"]
        APIGW[API Gateway<br/>REST + Streaming]
        STREAM[Streaming Handler]
        AGENT[Bedrock Agent]
        MEMORY[Bedrock Agent Memory]
        ACTION[Appointment Actions]
    end

    T1 & T2 -->|mTLS| APIGW
    APIGW --> STREAM
    STREAM --> AGENT
    AGENT --> MEMORY
    AGENT --> ACTION
```

**Use Cases:**
- Multi-tenant SaaS with single consistent behavior
- Streaming responses via REST API
- Simple appointment CRUD operations

**Location:** `terraform/` (main modules)

---

### Pattern 2: Orchestrator with Collaborator Agents (NEW)

One orchestrator coordinating five specialized agents for complex workflows.

```mermaid
flowchart TB
    USER[User Request] --> ORCH[Orchestrator Agent]

    ORCH --> A01[Agent 01<br/>Appointments<br/>Mock API]
    ORCH --> A02[Agent 02<br/>Time Mgmt<br/>Python]
    ORCH --> A03[Agent 03<br/>Calendar<br/>Python]
    ORCH --> A04[Agent 04<br/>Notifications<br/>Python]
    ORCH --> A05[Agent 05<br/>Analytics<br/>Python]

    A01 --> |Slot mgmt| LAMBDA1[Lambda]
    A02 --> |Timezone| LAMBDA2[Lambda]
    A03 --> |Events| LAMBDA3[Lambda]
    A04 --> |Multi-channel| LAMBDA4[Lambda]
    A05 --> |Metrics| LAMBDA5[Lambda]
```

**Agent Specializations:**

| Agent | Type | Capabilities |
|-------|------|-------------|
| **Orchestrator** | Controller | Routes requests, coordinates workflow, synthesizes responses |
| **Agent 01 - Appointments** | Mock API | View, search, book, reschedule, cancel appointments |
| **Agent 02 - Time** | Python | Timezone conversion, business hours, conflict detection |
| **Agent 03 - Calendar** | Python | Calendar events, availability, scheduling |
| **Agent 04 - Notifications** | Python | Email/SMS/push, templates, preferences |
| **Agent 05 - Analytics** | Python | Metrics, insights, trend analysis |

**Use Cases:**
- Complex multi-step workflows requiring multiple capabilities
- Modular agent responsibilities
- Independent agent development and testing

**Location:** `terraform/orchestrator-root/`

**Documentation:** See [ORCHESTRATOR_README.md](ORCHESTRATOR_README.md)

---

## Quick Start

### Pattern 1: Single-Agent (Multi-Tenant)

```bash
cd terraform

# Initialize
terraform init

# Deploy to dev
terraform apply -var-file="environments/dev/terraform.tfvars"

# Test API
curl -X POST https://your-api.execute-api.us-east-1.amazonaws.com/v1/agent/invoke \
  -H "X-Tenant-ID: tenant-001" \
  -H "X-API-Key: your-key" \
  -d '{"query": "Show my appointments"}'
```

### Pattern 2: Orchestrator (Multi-Agent)

```bash
cd terraform/orchestrator-root

# Initialize
terraform init

# Deploy to dev
terraform apply -var-file="environments/dev.tfvars"

# Test orchestrator
aws bedrock-agent-runtime invoke-agent \
  --agent-id $(terraform output -json orchestrator_endpoint | jq -r '.agent_id') \
  --agent-alias-id $(terraform output -json orchestrator_endpoint | jq -r '.alias_id') \
  --session-id "test-session" \
  --input-text "Book a repair appointment for tomorrow at 2 PM" \
  output.txt
```

---

## Deployment Process (Simplified)

Both patterns follow the same **environment progression** for SDLC compliance:

```
Dev → Staging → Production
```

### Environment Strategy

| Environment | Purpose | Deployment |
|-------------|---------|------------|
| **dev** | Active development, fast iteration | Terraform apply (no approval) |
| **staging** | Pre-production testing, QA validation | Terraform apply after dev success |
| **prod** | Production workload | Terraform apply after staging sign-off |

### Deployment Workflow

```bash
# 1. Deploy to Dev
terraform apply -var-file=environments/dev.tfvars

# 2. Test in Dev
# Run integration tests, manual validation

# 3. Deploy to Staging
terraform apply -var-file=environments/staging.tfvars

# 4. QA Approval in Staging
# Full regression testing, security scanning

# 5. Deploy to Production
terraform apply -var-file=environments/prod.tfvars

# Production deployment is instant (blue-green switch)
```

### Rollback Procedure

If issues are detected in production:

```bash
# Method 1: Git revert (creates new version from old config)
git revert HEAD
terraform apply -var-file=environments/prod.tfvars

# Method 2: Redeploy previous commit
git checkout <previous-commit>
terraform apply -var-file=environments/prod.tfvars
```

**Key Principle:** Rollback is just another deployment using a previous configuration. Terraform prepare creates a new version, alias points to it.

---

## Three-Tier Module Architecture (Orchestrator Pattern)

The orchestrator pattern uses a disciplined three-tier separation:

```
┌─────────────────────────────────────────────────────────────┐
│ TIER 3: ORCHESTRATION (Agent Lifecycle & Release)          │
│  - 6 Bedrock Agents (1 orchestrator + 5 collaborators)     │
│  - Prepare associations (version management)                 │
│  - Environment-specific aliases (dev/staging/prod)          │
│  Owner: Agent Anna / MLE Alice                              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ TIER 2: ACTION GROUPS (Business Logic & Tools)             │
│  - 5 Lambda function handlers                              │
│  - OpenAPI schemas (S3 storage)                            │
│  - Lambda resource permissions                              │
│  Owner: MLE Alice / Dev Bob                                 │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ TIER 1: SECURITY & IAM (Foundation)                        │
│  - 6 IAM execution roles (least privilege)                 │
│  - KMS key for session state encryption                     │
│  - Trust policies (confused deputy prevention)             │
│  Owner: SecOps Serena / Infra Dan                           │
└─────────────────────────────────────────────────────────────┘
```

**Benefits:**
- **Clear ownership**: Each tier has defined owners
- **Independent updates**: Change Lambda code without touching IAM
- **Security first**: Low-churn security resources in foundational tier
- **Easy rollback**: Agent changes don't require IAM updates

---

## Production Features

### Security
- ✅ **IAM Least Privilege**: Unique role per agent with minimal permissions
- ✅ **Confused Deputy Prevention**: Trust policies with SourceAccount conditions
- ✅ **Bedrock Guardrails**: Content filtering (optional, recommended for prod)
- ✅ **mTLS Support**: Client certificate authentication (single-agent pattern)

### Agent Memory (NEW)
- ✅ **Session Summaries**: Retains conversational context across sessions
- ✅ **Configurable Retention**: 7-90 days depending on environment
- ✅ **User Continuity**: Customers can resume conversations days later
- ✅ **Privacy Compliant**: Auto-deletion after retention period
- 📚 **Documentation**: See [Agent Memory Guide](docs/agent-memory-guide.md)

### Observability
- ✅ **AWS Lambda Powertools**: Structured logging, tracing, metrics
- ✅ **CloudWatch Logs**: Environment-specific retention (7/30/90 days)
- ✅ **X-Ray Tracing**: Distributed tracing across agents and Lambda
- ✅ **Custom Metrics**: Tenant-specific latency, invocation counts

### Code Quality
- ✅ **Type Safety**: Pydantic models for validation
- ✅ **Error Handling**: Comprehensive exception handling with retries
- ✅ **Testing**: Pytest with moto mocking, integration tests
- ✅ **Linting**: black, ruff, mypy, bandit

---

## Directory Structure

```
.
├── src/
│   ├── handlers/                    # Single-agent pattern
│   │   ├── streaming_handler.py     # Main agent invocation
│   │   └── action_group.py          # Appointment actions
│   └── orchestrator/                # Orchestrator pattern (NEW)
│       └── action_handlers/
│           ├── appointments_api/    # Agent 01 (Mock API)
│           ├── agent_02_time/       # Agent 02 (Time mgmt)
│           ├── agent_03_calendar/   # Agent 03 (Calendar)
│           ├── agent_04_notifications/  # Agent 04 (Notifications)
│           └── agent_05_analytics/  # Agent 05 (Analytics)
│
├── terraform/
│   ├── main.tf                      # Single-agent pattern root
│   ├── modules/                     # Single-agent modules
│   │   ├── api-gateway/
│   │   ├── bedrock-agent/
│   │   ├── lambda/
│   │   ├── dynamodb/
│   │   └── ...
│   │
│   ├── modules/orchestrator/        # Orchestrator pattern modules (NEW)
│   │   ├── security/                # Tier 1: IAM, KMS
│   │   ├── action_groups/           # Tier 2: Lambdas, Schemas
│   │   └── agent/                   # Tier 3: Agents, Aliases
│   │
│   └── orchestrator-root/           # Orchestrator root module (NEW)
│       ├── main.tf
│       ├── variables.tf
│       └── environments/
│           ├── dev.tfvars
│           ├── staging.tfvars
│           └── prod.tfvars
│
├── docs/
│   ├── architecture.md
│   ├── deployment.md
│   ├── gap-analysis.md
│   └── orchestrator-deployment.md  # Orchestrator guide (NEW)
│
├── tests/
│   ├── test_streaming_handler.py
│   ├── test_action_group.py
│   └── integration/
│
├── README.md                        # This file
└── ORCHESTRATOR_README.md           # Orchestrator deep dive (NEW)
```

Action group Lambda entrypoints live in:
- `src/handlers/action_group.py` (single-agent pattern)
- `src/orchestrator/action_handlers/*/handler.py` (orchestrator pattern)
- OpenAPI schemas currently exist in `src/orchestrator/action_handlers/appointments_api/openapi_schema.json`
  and `src/orchestrator/action_handlers/agent_02_time/openapi_schema.json`.

---

## Documentation

### General
- **[Architecture](docs/architecture.md)**: Technical architecture details
- **[Deployment](docs/deployment.md)**: Single-agent deployment guide
- **[Gap Analysis](docs/gap-analysis.md)**: Resolved deployment gaps

### Orchestrator Pattern (NEW)
- **[Orchestrator README](ORCHESTRATOR_README.md)**: Complete pattern overview
- **[Orchestrator Deployment](docs/orchestrator-deployment.md)**: Step-by-step deployment guide
- **[Agent Memory Guide](docs/agent-memory-guide.md)**: Memory configuration and usage
- **[Lambda Concurrency Guide](docs/lambda-concurrency-guide.md)**: Provisioned concurrency configuration
- **[Agent Prompts](terraform/modules/orchestrator/agent/prompts/)**: System prompts for each agent

---

## Key Differences: Single vs Orchestrator

| Aspect | Single-Agent | Orchestrator |
|--------|-------------|--------------|
| **Agent Count** | 1 | 6 (1 orchestrator + 5 collaborators) |
| **Use Case** | Simple, consistent workflows | Complex, multi-step workflows |
| **Actions** | Single action group (appointments) | 5 specialized action groups |
| **Complexity** | Lower | Higher (but modular) |
| **Deployment** | 1 agent prepare + alias | 6 agents prepare + aliases |
| **Development** | Monolithic updates | Independent agent updates |
| **Testing** | Test single agent behavior | Test agent collaboration |

---

## Cost Estimates

### Single-Agent Pattern
- **Dev**: $30-50/month
- **Staging**: $50-100/month
- **Prod**: $200-400/month (depends on tenant count and usage)

### Orchestrator Pattern
- **Dev**: $50-100/month
- **Staging**: $100-200/month
- **Prod**: $300-600/month (higher due to multiple agents)

**Cost Breakdown:**
- Bedrock invocations: ~60%
- Lambda executions: ~30%
- Storage/Logs: ~10%

---

## CI/CD Integration

Both patterns support GitLab CI/CD with environment progression:

``bash
# .gitlab-ci.yml
stages:
  - validate
  - deploy-dev
  - test-dev
  - deploy-staging
  - test-staging
  - approve-prod
  - deploy-prod

deploy-dev:
  stage: deploy-dev
  script:
    - terraform apply -var-file=environments/dev.tfvars -auto-approve

deploy-staging:
  stage: deploy-staging
  when: on_success
  script:
    - terraform apply -var-file=environments/staging.tfvars -auto-approve

deploy-prod:
  stage: deploy-prod
  when: manual  # Requires approval
  only:
    - main
  script:
    - terraform apply -var-file=environments/prod.tfvars -auto-approve
```

---

## Troubleshooting

### Common Issues

**Issue**: "Agent not found"
```bash
# Verify agent was prepared
terraform state show 'module.agent.aws_bedrockagent_agent_agent_version.orchestrator_prepared'
```

**Issue**: "Lambda permission denied"
```bash
# Check resource policy
aws lambda get-policy --function-name bedrock-orchestrator-appointments_api
```

**Issue**: "Changes not appearing"
- Ensure `aws_bedrockagent_agent_agent_version` resource exists
- Check `depends_on` chains are correct
- Verify alias points to latest version

---

## Contributing

1. Create feature branch: `git checkout -b feature/your-feature`
2. Make changes and test locally
3. Deploy to dev: `terraform apply -var-file=environments/dev.tfvars`
4. Run tests: `pytest tests/ -v`
5. Deploy to staging for QA validation
6. Create pull request with deployment evidence
7. After approval, merge to main → production deployment

---

## License

MIT License - See LICENSE file for details

---

## Support

For questions or issues:
- Check CloudWatch Logs for errors
- Review Terraform state: `terraform show`
- Consult documentation in `docs/`
- Open GitHub issue with logs and reproduction steps

---

**Version**: 2.0.0
**Last Updated**: 2026-01-10
**Maintained By**: Platform Engineering Team

**Key Enhancements in v2.0:**
- ✨ NEW: Orchestrator pattern with 5 specialized agents
- ✅ Simplified deployment workflows
- ✅ Environment progression (dev → staging → prod)
- ✅ Three-tier module architecture
- ✅ Production-ready Lambda handlers with Powertools
- ✅ Comprehensive documentation
