"""
Action Group Lambda handler for Bedrock Agent.

Handles appointment management operations:
- View appointments
- Search available slots
- Reserve slots
- Reschedule appointments
- Book appointments

Features:
- External API integration with retry logic
- JWT passthrough for authentication
- Tenant-aware operations
- Comprehensive logging and metrics
"""
import json
import os
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from enum import Enum

import boto3
import httpx
from botocore.config import Config
from botocore.exceptions import ClientError

from aws_lambda_powertools.utilities.typing import LambdaContext

from ..utils.observability import (
    logger,
    tracer,
    metrics,
    inject_lambda_context,
    log_with_context,
    record_latency,
    pii_redactor,
)
from ..utils.constants import (
    ErrorCodes,
    AppointmentStatus,
    AppointmentType,
    AUDIT_LOGS_TABLE,
)


# Configuration
EXTERNAL_API_TIMEOUT = 30  # seconds
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 2  # seconds

# Environment variables
SECRETS_ARN = os.environ.get("SECRETS_ARN", "")
EXTERNAL_API_ENDPOINT = os.environ.get("EXTERNAL_API_ENDPOINT", "")

# Initialize clients
boto_config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=30,
)
secrets_client = boto3.client("secretsmanager", config=boto_config)
dynamodb = boto3.resource("dynamodb", config=boto_config)
audit_table = dynamodb.Table(AUDIT_LOGS_TABLE)

# Cache for secrets
_secrets_cache: Dict[str, Any] = {}
_secrets_cache_time: float = 0
SECRETS_CACHE_TTL = 300  # 5 minutes


class ActionType(str, Enum):
    """Supported action types."""
    VIEW_APPOINTMENTS = "viewAppointments"
    SEARCH_SLOTS = "searchAvailableSlots"
    RESERVE_SLOT = "reserveSlot"
    RESCHEDULE = "rescheduleAppointment"
    BOOK_APPOINTMENT = "bookAppointment"
    CANCEL_APPOINTMENT = "cancelAppointment"


def get_cached_secrets() -> Dict[str, Any]:
    """Get secrets with caching."""
    global _secrets_cache, _secrets_cache_time

    if _secrets_cache and (time.time() - _secrets_cache_time) < SECRETS_CACHE_TTL:
        return _secrets_cache

    if not SECRETS_ARN:
        logger.warning("SECRETS_ARN not configured")
        return {}

    try:
        response = secrets_client.get_secret_value(SecretId=SECRETS_ARN)
        _secrets_cache = json.loads(response["SecretString"])
        _secrets_cache_time = time.time()
        return _secrets_cache
    except ClientError as e:
        logger.error("Failed to get secrets", error=str(e))
        return _secrets_cache  # Return stale cache on failure


def get_auth_headers(
    jwt_token: Optional[str],
    tenant_id: str,
) -> Dict[str, str]:
    """
    Get authentication headers for external API.

    Priority: JWT > API Key > Basic Auth
    """
    headers = {
        "Content-Type": "application/json",
        "X-Tenant-ID": tenant_id,
    }

    if jwt_token:
        headers["Authorization"] = f"Bearer {jwt_token}"
        return headers

    # Fallback to secrets
    secrets = get_cached_secrets()
    if secrets.get("api_key"):
        headers["X-API-Key"] = secrets["api_key"]
    elif secrets.get("username") and secrets.get("password"):
        import base64
        credentials = base64.b64encode(
            f"{secrets['username']}:{secrets['password']}".encode()
        ).decode()
        headers["Authorization"] = f"Basic {credentials}"

    return headers


@tracer.capture_method
def call_external_api(
    method: str,
    path: str,
    tenant_id: str,
    jwt_token: Optional[str] = None,
    body: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Call external appointment service API with retries.

    Uses pure synchronous httpx.Client for Lambda compatibility.
    Implements exponential backoff retry logic for transient failures.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE)
        path: API path
        tenant_id: Tenant identifier
        jwt_token: Optional JWT for authentication
        body: Optional request body

    Returns:
        API response as dictionary

    Raises:
        Exception: If all retry attempts fail
    """
    url = f"{EXTERNAL_API_ENDPOINT}{path}"
    headers = get_auth_headers(jwt_token, tenant_id)

    last_error = None
    for attempt in range(MAX_RETRIES):
        try:
            start_time = time.time()

            # Use synchronous httpx.Client for Lambda Powertools compatibility
            with httpx.Client(timeout=EXTERNAL_API_TIMEOUT) as client:
                if method.upper() == "GET":
                    response = client.get(url, headers=headers, params=body)
                elif method.upper() == "POST":
                    response = client.post(url, headers=headers, json=body)
                elif method.upper() == "PUT":
                    response = client.put(url, headers=headers, json=body)
                elif method.upper() == "DELETE":
                    response = client.delete(url, headers=headers)
                else:
                    raise ValueError(f"Unsupported method: {method}")

            latency_ms = (time.time() - start_time) * 1000
            record_latency("ExternalAPI", latency_ms, tenant_id)

            response.raise_for_status()
            return response.json()

        except httpx.TimeoutException as e:
            last_error = e
            logger.warning(
                f"External API timeout (attempt {attempt + 1}/{MAX_RETRIES})",
                path=path,
            )
        except httpx.HTTPStatusError as e:
            last_error = e
            if e.response.status_code < 500:
                # Don't retry client errors (4xx)
                raise
            logger.warning(
                f"External API error (attempt {attempt + 1}/{MAX_RETRIES})",
                status_code=e.response.status_code,
            )
        except Exception as e:
            last_error = e
            logger.warning(
                f"External API call failed (attempt {attempt + 1}/{MAX_RETRIES})",
                error=str(e),
            )

        if attempt < MAX_RETRIES - 1:
            # Exponential backoff: 2s, 4s, 8s
            time.sleep(RETRY_BACKOFF_BASE ** attempt)

    raise Exception(f"External API call failed after {MAX_RETRIES} attempts: {last_error}")


def parse_agent_request(event: Dict[str, Any]) -> Dict[str, Any]:
    """Parse Bedrock Agent action group request."""
    action_group = event.get("actionGroup", "")
    api_path = event.get("apiPath", "")
    http_method = event.get("httpMethod", "GET")
    parameters = event.get("parameters", [])
    request_body = event.get("requestBody", {})

    # Extract session attributes for tenant context
    session_attributes = event.get("sessionAttributes", {})
    tenant_id = session_attributes.get("tenantId", "unknown")
    jwt_token = session_attributes.get("authToken")

    # Convert parameters list to dict
    params_dict = {}
    for param in parameters:
        params_dict[param["name"]] = param["value"]

    # Extract body content if present
    body_content = {}
    if request_body:
        content = request_body.get("content", {})
        if "application/json" in content:
            properties = content["application/json"].get("properties", [])
            for prop in properties:
                body_content[prop["name"]] = prop["value"]

    return {
        "action_group": action_group,
        "api_path": api_path,
        "http_method": http_method,
        "parameters": params_dict,
        "body": body_content,
        "tenant_id": tenant_id,
        "jwt_token": jwt_token,
    }


def create_agent_response(
    action_group: str,
    api_path: str,
    http_method: str,
    response_body: Dict[str, Any],
    status_code: int = 200,
) -> Dict[str, Any]:
    """Create Bedrock Agent action group response."""
    return {
        "messageVersion": "1.0",
        "response": {
            "actionGroup": action_group,
            "apiPath": api_path,
            "httpMethod": http_method,
            "httpStatusCode": status_code,
            "responseBody": {
                "application/json": {
                    "body": json.dumps(response_body),
                },
            },
        },
    }


@tracer.capture_method
def view_appointments(
    tenant_id: str,
    jwt_token: Optional[str],
    params: Dict[str, Any],
) -> Dict[str, Any]:
    """View appointments for a customer or engineer."""
    customer_id = params.get("customerId")
    engineer_id = params.get("engineerId")
    date_from = params.get("dateFrom")
    date_to = params.get("dateTo")

    query_params = {}
    if customer_id:
        query_params["customerId"] = customer_id
    if engineer_id:
        query_params["engineerId"] = engineer_id
    if date_from:
        query_params["dateFrom"] = date_from
    if date_to:
        query_params["dateTo"] = date_to

    result = call_external_api(
        "GET",
        "/appointments",
        tenant_id,
        jwt_token,
        query_params,
    )

    return {
        "appointments": result.get("appointments", []),
        "total": result.get("total", 0),
    }


@tracer.capture_method
def search_available_slots(
    tenant_id: str,
    jwt_token: Optional[str],
    params: Dict[str, Any],
) -> Dict[str, Any]:
    """Search for available appointment slots."""
    service_type = params.get("serviceType", "maintenance")
    date_from = params.get("dateFrom")
    date_to = params.get("dateTo")
    location = params.get("location")
    duration_minutes = params.get("durationMinutes", 60)

    query_params = {
        "serviceType": service_type,
        "durationMinutes": duration_minutes,
    }
    if date_from:
        query_params["dateFrom"] = date_from
    if date_to:
        query_params["dateTo"] = date_to
    if location:
        query_params["location"] = location

    result = call_external_api(
        "GET",
        "/appointments/available-slots",
        tenant_id,
        jwt_token,
        query_params,
    )

    return {
        "availableSlots": result.get("slots", []),
        "total": result.get("total", 0),
    }


@tracer.capture_method
def reserve_slot(
    tenant_id: str,
    jwt_token: Optional[str],
    body: Dict[str, Any],
) -> Dict[str, Any]:
    """Reserve an appointment slot temporarily."""
    slot_id = body.get("slotId")
    customer_id = body.get("customerId")
    hold_duration_minutes = body.get("holdDurationMinutes", 15)

    if not slot_id or not customer_id:
        return {
            "success": False,
            "error": "slotId and customerId are required",
        }

    result = call_external_api(
        "POST",
        "/appointments/reserve",
        tenant_id,
        jwt_token,
        {
            "slotId": slot_id,
            "customerId": customer_id,
            "holdDurationMinutes": hold_duration_minutes,
        },
    )

    return {
        "success": result.get("success", False),
        "reservationId": result.get("reservationId"),
        "expiresAt": result.get("expiresAt"),
    }


@tracer.capture_method
def book_appointment(
    tenant_id: str,
    jwt_token: Optional[str],
    body: Dict[str, Any],
) -> Dict[str, Any]:
    """Book a new appointment."""
    required_fields = ["slotId", "customerId", "serviceType"]
    for field in required_fields:
        if field not in body:
            return {
                "success": False,
                "error": f"Missing required field: {field}",
            }

    result = call_external_api(
        "POST",
        "/appointments",
        tenant_id,
        jwt_token,
        {
            "slotId": body.get("slotId"),
            "customerId": body.get("customerId"),
            "serviceType": body.get("serviceType"),
            "description": body.get("description", ""),
            "contactPhone": body.get("contactPhone"),
            "contactEmail": body.get("contactEmail"),
            "notes": body.get("notes", ""),
        },
    )

    return {
        "success": result.get("success", False),
        "appointmentId": result.get("appointmentId"),
        "confirmationNumber": result.get("confirmationNumber"),
        "scheduledTime": result.get("scheduledTime"),
    }


@tracer.capture_method
def reschedule_appointment(
    tenant_id: str,
    jwt_token: Optional[str],
    body: Dict[str, Any],
) -> Dict[str, Any]:
    """Reschedule an existing appointment."""
    appointment_id = body.get("appointmentId")
    new_slot_id = body.get("newSlotId")
    reason = body.get("reason", "")

    if not appointment_id or not new_slot_id:
        return {
            "success": False,
            "error": "appointmentId and newSlotId are required",
        }

    result = call_external_api(
        "PUT",
        f"/appointments/{appointment_id}/reschedule",
        tenant_id,
        jwt_token,
        {
            "newSlotId": new_slot_id,
            "reason": reason,
        },
    )

    return {
        "success": result.get("success", False),
        "appointmentId": appointment_id,
        "newScheduledTime": result.get("newScheduledTime"),
        "previousScheduledTime": result.get("previousScheduledTime"),
    }


@tracer.capture_method
def cancel_appointment(
    tenant_id: str,
    jwt_token: Optional[str],
    body: Dict[str, Any],
) -> Dict[str, Any]:
    """Cancel an existing appointment."""
    appointment_id = body.get("appointmentId")
    reason = body.get("reason", "")

    if not appointment_id:
        return {
            "success": False,
            "error": "appointmentId is required",
        }

    result = call_external_api(
        "DELETE",
        f"/appointments/{appointment_id}",
        tenant_id,
        jwt_token,
    )

    return {
        "success": result.get("success", True),
        "appointmentId": appointment_id,
        "cancellationConfirmation": result.get("cancellationId"),
    }


def write_action_audit_log(
    tenant_id: str,
    action: str,
    parameters: Dict[str, Any],
    result: Dict[str, Any],
    success: bool,
    latency_ms: float,
) -> None:
    """Write audit log for action group execution."""
    try:
        audit_table.put_item(
            Item={
                "transactionId": f"action-{int(time.time() * 1000)}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "tenantId": tenant_id,
                "action": action,
                "query": pii_redactor.redact(json.dumps(parameters))[:500],
                "responseSummary": pii_redactor.redact(json.dumps(result))[:500],
                "latencyMs": int(latency_ms),
                "success": success,
                "ttl": int(time.time()) + (90 * 24 * 60 * 60),
            }
        )
    except ClientError as e:
        logger.error("Failed to write action audit log", error=str(e))


@inject_lambda_context
def handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """
    Main Lambda handler for Bedrock Agent action group.

    Routes requests to appropriate action handlers.
    """
    start_time = time.time()

    # Parse request
    request = parse_agent_request(event)
    tenant_id = request["tenant_id"]
    api_path = request["api_path"]
    action_group = request["action_group"]
    http_method = request["http_method"]

    log_with_context(
        "info",
        f"Processing action: {api_path}",
        tenant_id=tenant_id,
        extra={
            "action_group": action_group,
            "http_method": http_method,
        },
    )

    try:
        # Route to appropriate handler
        if api_path == "/appointments" and http_method == "GET":
            result = view_appointments(
                tenant_id,
                request["jwt_token"],
                request["parameters"],
            )
        elif api_path == "/appointments/available-slots":
            result = search_available_slots(
                tenant_id,
                request["jwt_token"],
                request["parameters"],
            )
        elif api_path == "/appointments/reserve":
            result = reserve_slot(
                tenant_id,
                request["jwt_token"],
                request["body"],
            )
        elif api_path == "/appointments" and http_method == "POST":
            result = book_appointment(
                tenant_id,
                request["jwt_token"],
                request["body"],
            )
        elif "/reschedule" in api_path:
            result = reschedule_appointment(
                tenant_id,
                request["jwt_token"],
                request["body"],
            )
        elif http_method == "DELETE":
            result = cancel_appointment(
                tenant_id,
                request["jwt_token"],
                request["body"],
            )
        else:
            result = {
                "error": f"Unknown action: {api_path}",
                "success": False,
            }

        latency_ms = (time.time() - start_time) * 1000
        success = result.get("success", True) if "error" not in result else False

        # Write audit log
        write_action_audit_log(
            tenant_id=tenant_id,
            action=api_path,
            parameters={**request["parameters"], **request["body"]},
            result=result,
            success=success,
            latency_ms=latency_ms,
        )

        log_with_context(
            "info",
            f"Action completed: {api_path}",
            tenant_id=tenant_id,
            extra={"latency_ms": latency_ms, "success": success},
        )

        return create_agent_response(
            action_group=action_group,
            api_path=api_path,
            http_method=http_method,
            response_body=result,
            status_code=200 if success else 400,
        )

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000

        log_with_context(
            "error",
            f"Action failed: {api_path}",
            tenant_id=tenant_id,
            extra={"error": str(e)},
        )

        write_action_audit_log(
            tenant_id=tenant_id,
            action=api_path,
            parameters={**request["parameters"], **request["body"]},
            result={"error": str(e)},
            success=False,
            latency_ms=latency_ms,
        )

        return create_agent_response(
            action_group=action_group,
            api_path=api_path,
            http_method=http_method,
            response_body={"error": "Internal error processing request"},
            status_code=500,
        )
