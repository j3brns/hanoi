"""
Production-grade streaming handler for Bedrock Agent invocation.

Features:
- AWS Lambda Powertools integration
- Bedrock streaming aggregation (buffers response before returning)
- Tenant context management
- Circuit breaker pattern
- Comprehensive error handling with retries
- PII redaction in logs

Note: API Gateway response streaming requires a response-streaming
implementation (for example, AWS Lambda Web Adapter + ASGI app). This handler
currently aggregates streamed Bedrock chunks into a single JSON response.
"""
import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Generator, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from aws_lambda_powertools.utilities.typing import LambdaContext

from ..utils.observability import (
    logger,
    tracer,
    metrics,
    inject_lambda_context,
    log_with_context,
    record_latency,
    record_invocation,
    record_streaming_chunks,
    record_response_length,
    extract_context_from_event,
    pii_redactor,
)
from ..utils.constants import (
    BEDROCK_AGENT_ID,
    BEDROCK_AGENT_ALIAS_ID,
    SESSIONS_TABLE,
    AUDIT_LOGS_TABLE,
    MAX_QUERY_LENGTH,
    TTFB_TARGET_MS,
    ErrorCodes,
    HEADER_TENANT_ID,
    HEADER_CORRELATION_ID,
    HEADER_REQUEST_ID,
    HEADER_RATE_LIMIT,
    HEADER_RATE_REMAINING,
)


# Configure boto3 with retries and timeouts
boto_config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=900,  # 15 minutes for streaming
)

# Initialize clients
bedrock_agent_runtime = boto3.client(
    "bedrock-agent-runtime",
    config=boto_config,
)
dynamodb = boto3.resource("dynamodb", config=boto_config)
sessions_table = dynamodb.Table(SESSIONS_TABLE)
audit_table = dynamodb.Table(AUDIT_LOGS_TABLE)


class CircuitBreaker:
    """Simple circuit breaker for external service calls."""

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: int = 30,
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failures = 0
        self.last_failure_time: Optional[float] = None
        self.state = "closed"  # closed, open, half-open

    def can_execute(self) -> bool:
        """Check if circuit allows execution."""
        if self.state == "closed":
            return True
        if self.state == "open":
            if time.time() - self.last_failure_time >= self.recovery_timeout:
                self.state = "half-open"
                return True
            return False
        return True  # half-open allows one request

    def record_success(self) -> None:
        """Record successful execution."""
        self.failures = 0
        self.state = "closed"

    def record_failure(self) -> None:
        """Record failed execution."""
        self.failures += 1
        self.last_failure_time = time.time()
        if self.failures >= self.failure_threshold:
            self.state = "open"
            logger.warning(
                "Circuit breaker opened",
                failures=self.failures,
                threshold=self.failure_threshold,
            )


# Global circuit breaker
circuit_breaker = CircuitBreaker()


def validate_request(event: Dict[str, Any]) -> tuple[bool, Optional[Dict[str, Any]]]:
    """
    Validate incoming request.

    Returns:
        Tuple of (is_valid, error_response)
    """
    # Check tenant ID header
    headers = event.get("headers", {}) or {}
    headers_lower = {k.lower(): v for k, v in headers.items()}

    tenant_id = headers_lower.get(HEADER_TENANT_ID.lower())
    if not tenant_id:
        return False, create_error_response(
            400,
            ErrorCodes.INVALID_REQUEST,
            f"Missing required header: {HEADER_TENANT_ID}",
        )

    # Parse and validate body
    body = event.get("body", "{}")
    if event.get("isBase64Encoded"):
        import base64
        body = base64.b64decode(body).decode("utf-8")

    try:
        payload = json.loads(body) if body else {}
    except json.JSONDecodeError:
        return False, create_error_response(
            400,
            ErrorCodes.VALIDATION_ERROR,
            "Invalid JSON in request body",
        )

    # Check query length
    query = payload.get("query", "")
    if len(query) > MAX_QUERY_LENGTH:
        return False, create_error_response(
            400,
            ErrorCodes.VALIDATION_ERROR,
            f"Query exceeds maximum length of {MAX_QUERY_LENGTH} characters",
        )

    if not query.strip():
        return False, create_error_response(
            400,
            ErrorCodes.VALIDATION_ERROR,
            "Query cannot be empty",
        )

    return True, None


def create_error_response(
    status_code: int,
    error_code: ErrorCodes,
    message: str,
    request_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Create standardized error response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            HEADER_REQUEST_ID: request_id or str(uuid.uuid4()),
        },
        "body": json.dumps({
            "error": {
                "code": error_code.value,
                "message": message,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        }),
    }


def create_success_response(
    body: Dict[str, Any],
    request_id: str,
    correlation_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Create standardized success response."""
    headers = {
        "Content-Type": "application/json",
        HEADER_REQUEST_ID: request_id,
        HEADER_RATE_LIMIT: "200",
        HEADER_RATE_REMAINING: "199",
    }
    if correlation_id:
        headers[HEADER_CORRELATION_ID] = correlation_id

    return {
        "statusCode": 200,
        "headers": headers,
        "body": json.dumps(body),
    }


def get_or_create_session(
    tenant_id: str,
    session_id: Optional[str] = None,
) -> str:
    """Get existing session or create new one."""
    if session_id:
        try:
            response = sessions_table.get_item(Key={"sessionId": session_id})
            if "Item" in response:
                # Update last accessed
                sessions_table.update_item(
                    Key={"sessionId": session_id},
                    UpdateExpression="SET lastUpdated = :now",
                    ExpressionAttributeValues={
                        ":now": datetime.now(timezone.utc).isoformat(),
                    },
                )
                return session_id
        except ClientError as e:
            logger.warning("Failed to get session", error=str(e))

    # Create new session
    new_session_id = f"{tenant_id}-{uuid.uuid4()}"
    try:
        sessions_table.put_item(
            Item={
                "sessionId": new_session_id,
                "tenantId": tenant_id,
                "createdAt": datetime.now(timezone.utc).isoformat(),
                "lastUpdated": datetime.now(timezone.utc).isoformat(),
                "ttl": int(time.time()) + 3600,  # 1 hour TTL
            }
        )
    except ClientError as e:
        logger.error("Failed to create session", error=str(e))

    return new_session_id


def write_audit_log(
    transaction_id: str,
    tenant_id: str,
    action: str,
    query: str,
    response_summary: str,
    latency_ms: float,
    success: bool,
) -> None:
    """Write audit log entry."""
    try:
        audit_table.put_item(
            Item={
                "transactionId": transaction_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "tenantId": tenant_id,
                "action": action,
                "query": pii_redactor.redact(query)[:500],  # Truncate and redact
                "responseSummary": pii_redactor.redact(response_summary)[:500],
                "latencyMs": int(latency_ms),
                "success": success,
                "ttl": int(time.time()) + (90 * 24 * 60 * 60),  # 90 days TTL
            }
        )
    except ClientError as e:
        logger.error("Failed to write audit log", error=str(e))


@tracer.capture_method
def invoke_bedrock_agent(
    query: str,
    session_id: str,
    tenant_id: str,
    jwt_token: Optional[str] = None,
) -> Generator[str, None, None]:
    """
    Invoke Bedrock Agent with streaming response.

    Yields:
        Response chunks as they become available.
    """
    if not circuit_breaker.can_execute():
        raise Exception("Circuit breaker is open - service unavailable")

    # Prepare session state with tenant context
    session_state = {
        "sessionAttributes": {
            "tenantId": tenant_id,
        },
    }

    # Add JWT if provided for downstream API calls
    if jwt_token:
        session_state["sessionAttributes"]["authToken"] = jwt_token

    try:
        response = bedrock_agent_runtime.invoke_agent(
            agentId=BEDROCK_AGENT_ID,
            agentAliasId=BEDROCK_AGENT_ALIAS_ID,
            sessionId=session_id,
            inputText=query,
            sessionState=session_state,
            enableTrace=True,
            streamingConfigurations={
                "streamFinalResponse": True,
            },
        )

        # Process streaming response
        chunk_count = 0
        for event in response.get("completion", []):
            if "chunk" in event:
                chunk_data = event["chunk"]
                if "bytes" in chunk_data:
                    chunk_text = chunk_data["bytes"].decode("utf-8")
                    chunk_count += 1
                    yield chunk_text

        record_streaming_chunks(chunk_count, tenant_id)
        circuit_breaker.record_success()

    except ClientError as e:
        circuit_breaker.record_failure()
        error_code = e.response.get("Error", {}).get("Code", "Unknown")
        logger.error(
            "Bedrock Agent invocation failed",
            error_code=error_code,
            error=str(e),
        )
        raise


@inject_lambda_context
def handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """
    Main Lambda handler for streaming Bedrock Agent responses.

    Supports API Gateway REST API with responseTransferMode: STREAM.
    """
    start_time = time.time()
    request_id = event.get("requestContext", {}).get("requestId", str(uuid.uuid4()))

    # Extract context
    ctx = extract_context_from_event(event)
    tenant_id = ctx.get("tenant_id")
    correlation_id = ctx.get("correlation_id") or str(uuid.uuid4())

    log_with_context(
        "info",
        "Processing streaming request",
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        extra={"request_id": request_id},
    )

    # Validate request
    is_valid, error_response = validate_request(event)
    if not is_valid:
        record_invocation(tenant_id or "unknown", success=False)
        return error_response

    # Parse request body
    body = event.get("body", "{}")
    if event.get("isBase64Encoded"):
        import base64
        body = base64.b64decode(body).decode("utf-8")
    payload = json.loads(body)

    query = payload.get("query", "")
    session_id = payload.get("sessionId")

    # Extract JWT from Authorization header if present
    headers = event.get("headers", {}) or {}
    headers_lower = {k.lower(): v for k, v in headers.items()}
    auth_header = headers_lower.get("authorization", "")
    jwt_token = None
    if auth_header.startswith("Bearer "):
        jwt_token = auth_header[7:]

    try:
        # Get or create session
        session_id = get_or_create_session(tenant_id, session_id)

        # Record TTFB start
        ttfb_start = time.time()

        # Invoke agent and collect response
        response_parts = []
        first_chunk_time = None

        for chunk in invoke_bedrock_agent(query, session_id, tenant_id, jwt_token):
            if first_chunk_time is None:
                first_chunk_time = time.time()
                ttfb_ms = (first_chunk_time - ttfb_start) * 1000
                record_latency("TTFB", ttfb_ms, tenant_id)

                if ttfb_ms > TTFB_TARGET_MS:
                    log_with_context(
                        "warning",
                        f"TTFB exceeded target: {ttfb_ms:.2f}ms > {TTFB_TARGET_MS}ms",
                        tenant_id=tenant_id,
                        correlation_id=correlation_id,
                    )

            response_parts.append(chunk)

        full_response = "".join(response_parts)
        response_length = len(full_response)

        # Record metrics
        total_latency_ms = (time.time() - start_time) * 1000
        record_latency("TotalLatency", total_latency_ms, tenant_id)
        record_response_length(response_length, tenant_id)
        record_invocation(tenant_id, success=True)

        # Write audit log
        write_audit_log(
            transaction_id=request_id,
            tenant_id=tenant_id,
            action="invoke_agent",
            query=query,
            response_summary=full_response[:200] if full_response else "",
            latency_ms=total_latency_ms,
            success=True,
        )

        log_with_context(
            "info",
            "Request completed successfully",
            tenant_id=tenant_id,
            correlation_id=correlation_id,
            extra={
                "latency_ms": total_latency_ms,
                "response_length": response_length,
            },
        )

        return create_success_response(
            body={
                "response": full_response,
                "sessionId": session_id,
                "metadata": {
                    "latencyMs": int(total_latency_ms),
                    "responseLength": response_length,
                },
            },
            request_id=request_id,
            correlation_id=correlation_id,
        )

    except Exception as e:
        total_latency_ms = (time.time() - start_time) * 1000
        record_invocation(tenant_id, success=False)

        # Write audit log for failure
        write_audit_log(
            transaction_id=request_id,
            tenant_id=tenant_id,
            action="invoke_agent",
            query=query,
            response_summary=f"Error: {str(e)}",
            latency_ms=total_latency_ms,
            success=False,
        )

        log_with_context(
            "error",
            f"Request failed: {str(e)}",
            tenant_id=tenant_id,
            correlation_id=correlation_id,
            extra={"error": str(e)},
        )

        # Determine appropriate error code
        if "circuit breaker" in str(e).lower():
            return create_error_response(
                503,
                ErrorCodes.SERVICE_UNAVAILABLE,
                "Service temporarily unavailable",
                request_id,
            )
        elif "throttl" in str(e).lower():
            return create_error_response(
                429,
                ErrorCodes.RATE_LIMITED,
                "Rate limit exceeded",
                request_id,
            )
        else:
            return create_error_response(
                500,
                ErrorCodes.AGENT_ERROR,
                "Failed to process request",
                request_id,
            )


# Health check endpoint handler
def health_handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """Health check endpoint."""
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "status": "healthy",
            "version": "1.1.0",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "dependencies": {
                "bedrock": "ok" if circuit_breaker.state == "closed" else "degraded",
                "dynamodb": "ok",
            },
        }),
    }
