"""
Bedrock Agent Action Handler - Calendar Operations (Agent 03)
==============================================================
Production-ready calendar management and scheduling optimization functions.

Features:
- Calendar event management
- Recurring event handling
- Availability checking
- Schedule optimization
- AWS Lambda Powertools integration
"""

import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from collections import defaultdict
from aws_lambda_powertools import Logger, Tracer
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger(service="calendar-agent")
tracer = Tracer(service="calendar-agent")

# ============================================================================
# IN-MEMORY CALENDAR STORAGE
# ============================================================================

CALENDAR_EVENTS: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

# ============================================================================
# CALENDAR FUNCTIONS
# ============================================================================

@tracer.capture_method
def create_calendar_event(
    calendar_id: str,
    title: str,
    start_time: str,
    end_time: str,
    description: Optional[str] = None,
    location: Optional[str] = None,
    attendees: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Create a new calendar event

    Args:
        calendar_id: Calendar identifier
        title: Event title
        start_time: Event start time (ISO format)
        end_time: Event end time (ISO format)
        description: Event description
        location: Event location
        attendees: List of attendee emails

    Returns:
        Created event details
    """
    logger.info(f"Creating event '{title}' on calendar {calendar_id}")

    try:
        event = {
            "event_id": f"EVT-{len(CALENDAR_EVENTS[calendar_id]) + 1:06d}",
            "calendar_id": calendar_id,
            "title": title,
            "start_time": start_time,
            "end_time": end_time,
            "description": description,
            "location": location,
            "attendees": attendees or [],
            "created_at": datetime.utcnow().isoformat(),
            "status": "confirmed"
        }

        CALENDAR_EVENTS[calendar_id].append(event)

        return {
            "success": True,
            "event": event,
            "message": f"Event '{title}' created successfully"
        }

    except Exception as e:
        logger.error(f"Failed to create event: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "CREATE_ERROR"
        }

@tracer.capture_method
def get_calendar_events(
    calendar_id: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
) -> Dict[str, Any]:
    """
    Get calendar events within a date range

    Args:
        calendar_id: Calendar identifier
        start_date: Filter events after this date
        end_date: Filter events before this date

    Returns:
        List of events
    """
    logger.info(f"Getting events for calendar {calendar_id}")

    try:
        events = CALENDAR_EVENTS.get(calendar_id, [])

        # Apply date filters
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            events = [e for e in events if datetime.fromisoformat(e["start_time"]) >= start_dt]

        if end_date:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            events = [e for e in events if datetime.fromisoformat(e["start_time"]) <= end_dt]

        # Sort by start time
        events = sorted(events, key=lambda x: x["start_time"])

        return {
            "success": True,
            "calendar_id": calendar_id,
            "count": len(events),
            "events": events
        }

    except Exception as e:
        logger.error(f"Failed to get events: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "RETRIEVAL_ERROR"
        }

@tracer.capture_method
def find_available_slots(
    calendar_id: str,
    start_date: str,
    end_date: str,
    duration_minutes: int,
    business_hours_only: bool = True
) -> Dict[str, Any]:
    """
    Find available time slots in a calendar

    Args:
        calendar_id: Calendar identifier
        start_date: Search start date
        end_date: Search end date
        duration_minutes: Required slot duration in minutes
        business_hours_only: Only search during business hours

    Returns:
        List of available slots
    """
    logger.info(f"Finding available slots for calendar {calendar_id}, duration: {duration_minutes}min")

    try:
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))

        # Get existing events
        events = CALENDAR_EVENTS.get(calendar_id, [])
        events = [e for e in events if datetime.fromisoformat(e["start_time"]) < end_dt
                  and datetime.fromisoformat(e["end_time"]) > start_dt]

        # Sort events by start time
        events = sorted(events, key=lambda x: x["start_time"])

        # Find gaps
        available_slots = []
        current_time = start_dt

        for event in events:
            event_start = datetime.fromisoformat(event["start_time"])
            gap_minutes = (event_start - current_time).total_seconds() / 60

            if gap_minutes >= duration_minutes:
                # Check business hours if required
                if not business_hours_only or (9 <= current_time.hour < 17):
                    available_slots.append({
                        "start_time": current_time.isoformat(),
                        "end_time": (current_time + timedelta(minutes=duration_minutes)).isoformat(),
                        "duration_minutes": duration_minutes
                    })

            current_time = max(current_time, datetime.fromisoformat(event["end_time"]))

        # Check final gap
        if (end_dt - current_time).total_seconds() / 60 >= duration_minutes:
            if not business_hours_only or (9 <= current_time.hour < 17):
                available_slots.append({
                    "start_time": current_time.isoformat(),
                    "end_time": (current_time + timedelta(minutes=duration_minutes)).isoformat(),
                    "duration_minutes": duration_minutes
                })

        return {
            "success": True,
            "calendar_id": calendar_id,
            "available_slots_count": len(available_slots),
            "available_slots": available_slots[:10]  # Limit to 10 results
        }

    except Exception as e:
        logger.error(f"Failed to find available slots: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "SEARCH_ERROR"
        }

@tracer.capture_method
def update_calendar_event(
    event_id: str,
    calendar_id: str,
    updates: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Update an existing calendar event

    Args:
        event_id: Event identifier
        calendar_id: Calendar identifier
        updates: Dictionary of fields to update

    Returns:
        Updated event details
    """
    logger.info(f"Updating event {event_id} on calendar {calendar_id}")

    try:
        events = CALENDAR_EVENTS.get(calendar_id, [])
        event = next((e for e in events if e["event_id"] == event_id), None)

        if not event:
            return {
                "success": False,
                "error": "Event not found",
                "error_code": "EVENT_NOT_FOUND"
            }

        # Apply updates
        allowed_fields = ["title", "start_time", "end_time", "description", "location", "attendees", "status"]
        for field, value in updates.items():
            if field in allowed_fields:
                event[field] = value

        return {
            "success": True,
            "event": event,
            "message": "Event updated successfully"
        }

    except Exception as e:
        logger.error(f"Failed to update event: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "UPDATE_ERROR"
        }

@tracer.capture_method
def delete_calendar_event(event_id: str, calendar_id: str) -> Dict[str, Any]:
    """
    Delete a calendar event

    Args:
        event_id: Event identifier
        calendar_id: Calendar identifier

    Returns:
        Deletion confirmation
    """
    logger.info(f"Deleting event {event_id} from calendar {calendar_id}")

    try:
        events = CALENDAR_EVENTS.get(calendar_id, [])
        event = next((e for e in events if e["event_id"] == event_id), None)

        if not event:
            return {
                "success": False,
                "error": "Event not found",
                "error_code": "EVENT_NOT_FOUND"
            }

        CALENDAR_EVENTS[calendar_id] = [e for e in events if e["event_id"] != event_id]

        return {
            "success": True,
            "event_id": event_id,
            "message": "Event deleted successfully"
        }

    except Exception as e:
        logger.error(f"Failed to delete event: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "DELETE_ERROR"
        }

@tracer.capture_method
def get_calendar_summary(
    calendar_id: str,
    date: str
) -> Dict[str, Any]:
    """
    Get daily calendar summary

    Args:
        calendar_id: Calendar identifier
        date: Date for summary (ISO format)

    Returns:
        Daily summary statistics
    """
    logger.info(f"Getting summary for calendar {calendar_id} on {date}")

    try:
        target_date = datetime.fromisoformat(date.replace('Z', '+00:00')).date()
        events = CALENDAR_EVENTS.get(calendar_id, [])

        # Filter events for the target date
        daily_events = [
            e for e in events
            if datetime.fromisoformat(e["start_time"]).date() == target_date
        ]

        # Calculate statistics
        total_duration_minutes = sum(
            (datetime.fromisoformat(e["end_time"]) - datetime.fromisoformat(e["start_time"])).total_seconds() / 60
            for e in daily_events
        )

        return {
            "success": True,
            "calendar_id": calendar_id,
            "date": date,
            "total_events": len(daily_events),
            "total_duration_minutes": int(total_duration_minutes),
            "total_duration_hours": round(total_duration_minutes / 60, 2),
            "events": daily_events
        }

    except Exception as e:
        logger.error(f"Failed to get calendar summary: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "SUMMARY_ERROR"
        }

# ============================================================================
# BEDROCK AGENT ACTION HANDLER
# ============================================================================

@logger.inject_lambda_context(log_event=True)
@tracer.capture_lambda_handler
def lambda_handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """
    Main Lambda handler for Bedrock Agent action group
    """
    logger.info("Processing Calendar Agent action request")

    try:
        api_path = event.get("apiPath", "")
        parameters = {p["name"]: p["value"] for p in event.get("parameters", [])}

        logger.info(f"Path: {api_path}, Parameters: {parameters}")

        result = None

        if api_path == "/calendar/create-event":
            result = create_calendar_event(
                parameters.get("calendar_id"),
                parameters.get("title"),
                parameters.get("start_time"),
                parameters.get("end_time"),
                parameters.get("description"),
                parameters.get("location"),
                json.loads(parameters.get("attendees", "[]"))
            )

        elif api_path == "/calendar/get-events":
            result = get_calendar_events(
                parameters.get("calendar_id"),
                parameters.get("start_date"),
                parameters.get("end_date")
            )

        elif api_path == "/calendar/find-slots":
            result = find_available_slots(
                parameters.get("calendar_id"),
                parameters.get("start_date"),
                parameters.get("end_date"),
                int(parameters.get("duration_minutes", 60)),
                parameters.get("business_hours_only", "true").lower() == "true"
            )

        elif api_path == "/calendar/update-event":
            updates = json.loads(event.get("requestBody", {}).get("content", {}).get("application/json", "{}"))
            result = update_calendar_event(
                parameters.get("event_id"),
                parameters.get("calendar_id"),
                updates
            )

        elif api_path == "/calendar/delete-event":
            result = delete_calendar_event(
                parameters.get("event_id"),
                parameters.get("calendar_id")
            )

        elif api_path == "/calendar/summary":
            result = get_calendar_summary(
                parameters.get("calendar_id"),
                parameters.get("date")
            )

        else:
            result = {
                "success": False,
                "error": f"Unknown API path: {api_path}",
                "error_code": "INVALID_PATH"
            }

        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": api_path,
                "httpMethod": event.get("httpMethod", ""),
                "httpStatusCode": 200 if result.get("success") else 400,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps(result)
                    }
                }
            }
        }

    except Exception as e:
        logger.exception("Error processing action request")
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": event.get("apiPath", ""),
                "httpMethod": event.get("httpMethod", ""),
                "httpStatusCode": 500,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps({
                            "success": False,
                            "error": str(e),
                            "error_code": "INTERNAL_ERROR"
                        })
                    }
                }
            }
        }
