"""
Bedrock Agent Action Handler - Appointments API (Agent 01)
===========================================================
Mock external appointments API for telecommunications service appointments.

Production Features:
- RESTful API mock with realistic responses
- CRUD operations for appointments
- Slot availability checking
- Concurrent booking prevention
- Input validation with Pydantic
- AWS Lambda Powertools integration
- Comprehensive error handling
"""

import json
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from aws_lambda_powertools import Logger, Tracer
from aws_lambda_powertools.utilities.typing import LambdaContext
from pydantic import BaseModel, Field, validator

# Initialize Powertools
logger = Logger(service="appointments-api")
tracer = Tracer(service="appointments-api")

# ============================================================================
# DATA MODELS
# ============================================================================

class TimeSlot(BaseModel):
    """Available time slot model"""
    slot_id: str = Field(..., description="Unique slot identifier")
    start_time: datetime
    end_time: datetime
    available: bool = True
    technician_id: Optional[str] = None
    service_type: str

class Appointment(BaseModel):
    """Appointment model"""
    appointment_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    customer_id: str
    slot_id: str
    service_type: str
    status: str = "scheduled"  # scheduled, completed, cancelled
    created_at: datetime = Field(default_factory=datetime.utcnow)
    notes: Optional[str] = None

    @validator('status')
    def validate_status(cls, v):
        allowed = ['scheduled', 'completed', 'cancelled', 'in_progress']
        if v not in allowed:
            raise ValueError(f"Status must be one of {allowed}")
        return v

# ============================================================================
# IN-MEMORY DATA STORE (Mock Database)
# ============================================================================

# Mock appointments database
APPOINTMENTS_DB: Dict[str, Dict[str, Any]] = {}

# Mock available slots (next 7 days, 9 AM - 5 PM)
def generate_mock_slots(days: int = 7) -> List[Dict[str, Any]]:
    """Generate mock time slots for the next N days"""
    slots = []
    base_date = datetime.utcnow().replace(hour=9, minute=0, second=0, microsecond=0)

    service_types = ["installation", "repair", "upgrade", "maintenance"]

    for day in range(days):
        current_date = base_date + timedelta(days=day)
        for hour in range(9, 17):  # 9 AM to 5 PM
            slot_time = current_date.replace(hour=hour)
            slot = {
                "slot_id": f"SLOT-{slot_time.strftime('%Y%m%d')}-{hour:02d}",
                "start_time": slot_time.isoformat(),
                "end_time": (slot_time + timedelta(hours=1)).isoformat(),
                "available": True,
                "technician_id": f"TECH-{(hash(str(slot_time)) % 10):03d}",
                "service_type": service_types[hour % len(service_types)]
            }
            slots.append(slot)

    return slots

AVAILABLE_SLOTS = generate_mock_slots()

# ============================================================================
# API ACTIONS
# ============================================================================

@tracer.capture_method
def view_appointments(customer_id: str) -> Dict[str, Any]:
    """
    View all appointments for a customer

    Args:
        customer_id: Customer identifier

    Returns:
        List of appointments
    """
    logger.info(f"Viewing appointments for customer: {customer_id}")

    customer_appointments = [
        appt for appt in APPOINTMENTS_DB.values()
        if appt.get("customer_id") == customer_id
    ]

    return {
        "success": True,
        "count": len(customer_appointments),
        "appointments": customer_appointments
    }

@tracer.capture_method
def search_available_slots(
    service_type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
) -> Dict[str, Any]:
    """
    Search for available time slots

    Args:
        service_type: Filter by service type
        start_date: Filter slots after this date (ISO format)
        end_date: Filter slots before this date (ISO format)

    Returns:
        List of available slots
    """
    logger.info(f"Searching slots - service_type: {service_type}, start: {start_date}, end: {end_date}")

    filtered_slots = [slot for slot in AVAILABLE_SLOTS if slot["available"]]

    # Apply filters
    if service_type:
        filtered_slots = [s for s in filtered_slots if s["service_type"] == service_type]

    if start_date:
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        filtered_slots = [
            s for s in filtered_slots
            if datetime.fromisoformat(s["start_time"]) >= start_dt
        ]

    if end_date:
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        filtered_slots = [
            s for s in filtered_slots
            if datetime.fromisoformat(s["start_time"]) <= end_dt
        ]

    return {
        "success": True,
        "count": len(filtered_slots),
        "slots": filtered_slots[:20]  # Limit to 20 results
    }

@tracer.capture_method
def book_appointment(
    customer_id: str,
    slot_id: str,
    service_type: str,
    notes: Optional[str] = None
) -> Dict[str, Any]:
    """
    Book a new appointment

    Args:
        customer_id: Customer identifier
        slot_id: Time slot identifier
        service_type: Type of service
        notes: Optional appointment notes

    Returns:
        Created appointment details
    """
    logger.info(f"Booking appointment - customer: {customer_id}, slot: {slot_id}")

    # Find the slot
    slot = next((s for s in AVAILABLE_SLOTS if s["slot_id"] == slot_id), None)

    if not slot:
        return {
            "success": False,
            "error": "Slot not found",
            "error_code": "SLOT_NOT_FOUND"
        }

    if not slot["available"]:
        return {
            "success": False,
            "error": "Slot no longer available",
            "error_code": "SLOT_UNAVAILABLE"
        }

    # Create appointment
    appointment = Appointment(
        customer_id=customer_id,
        slot_id=slot_id,
        service_type=service_type,
        notes=notes
    )

    # Store in database
    APPOINTMENTS_DB[appointment.appointment_id] = appointment.dict()

    # Mark slot as unavailable
    slot["available"] = False

    logger.info(f"Appointment created: {appointment.appointment_id}")

    return {
        "success": True,
        "appointment": appointment.dict(),
        "message": f"Appointment scheduled for {slot['start_time']}"
    }

@tracer.capture_method
def reschedule_appointment(
    appointment_id: str,
    new_slot_id: str
) -> Dict[str, Any]:
    """
    Reschedule an existing appointment

    Args:
        appointment_id: Appointment identifier
        new_slot_id: New time slot identifier

    Returns:
        Updated appointment details
    """
    logger.info(f"Rescheduling appointment {appointment_id} to slot {new_slot_id}")

    # Find appointment
    appointment = APPOINTMENTS_DB.get(appointment_id)
    if not appointment:
        return {
            "success": False,
            "error": "Appointment not found",
            "error_code": "APPOINTMENT_NOT_FOUND"
        }

    # Find new slot
    new_slot = next((s for s in AVAILABLE_SLOTS if s["slot_id"] == new_slot_id), None)
    if not new_slot or not new_slot["available"]:
        return {
            "success": False,
            "error": "New slot not available",
            "error_code": "SLOT_UNAVAILABLE"
        }

    # Free up old slot
    old_slot = next((s for s in AVAILABLE_SLOTS if s["slot_id"] == appointment["slot_id"]), None)
    if old_slot:
        old_slot["available"] = True

    # Update appointment
    appointment["slot_id"] = new_slot_id
    new_slot["available"] = False

    return {
        "success": True,
        "appointment": appointment,
        "message": f"Appointment rescheduled to {new_slot['start_time']}"
    }

@tracer.capture_method
def cancel_appointment(appointment_id: str) -> Dict[str, Any]:
    """
    Cancel an appointment

    Args:
        appointment_id: Appointment identifier

    Returns:
        Cancellation confirmation
    """
    logger.info(f"Cancelling appointment: {appointment_id}")

    appointment = APPOINTMENTS_DB.get(appointment_id)
    if not appointment:
        return {
            "success": False,
            "error": "Appointment not found",
            "error_code": "APPOINTMENT_NOT_FOUND"
        }

    # Update status
    appointment["status"] = "cancelled"

    # Free up the slot
    slot = next((s for s in AVAILABLE_SLOTS if s["slot_id"] == appointment["slot_id"]), None)
    if slot:
        slot["available"] = True

    return {
        "success": True,
        "appointment_id": appointment_id,
        "message": "Appointment cancelled successfully"
    }

# ============================================================================
# BEDROCK AGENT ACTION HANDLER
# ============================================================================

@logger.inject_lambda_context(log_event=True)
@tracer.capture_lambda_handler
def lambda_handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """
    Main Lambda handler for Bedrock Agent action group

    Expected event structure from Bedrock Agent:
    {
        "actionGroup": "AppointmentsAPI",
        "apiPath": "/appointments/search",
        "httpMethod": "GET",
        "parameters": [...],
        "requestBody": {...}
    }
    """
    logger.info("Processing Bedrock Agent action request")

    try:
        action_group = event.get("actionGroup", "")
        api_path = event.get("apiPath", "")
        http_method = event.get("httpMethod", "")

        # Extract parameters
        parameters = {p["name"]: p["value"] for p in event.get("parameters", [])}

        logger.info(f"Action: {action_group}, Path: {api_path}, Method: {http_method}")
        logger.info(f"Parameters: {parameters}")

        # Route to appropriate action
        result = None

        if api_path == "/appointments/view":
            result = view_appointments(parameters.get("customer_id"))

        elif api_path == "/appointments/search":
            result = search_available_slots(
                service_type=parameters.get("service_type"),
                start_date=parameters.get("start_date"),
                end_date=parameters.get("end_date")
            )

        elif api_path == "/appointments/book":
            result = book_appointment(
                customer_id=parameters.get("customer_id"),
                slot_id=parameters.get("slot_id"),
                service_type=parameters.get("service_type"),
                notes=parameters.get("notes")
            )

        elif api_path == "/appointments/reschedule":
            result = reschedule_appointment(
                appointment_id=parameters.get("appointment_id"),
                new_slot_id=parameters.get("new_slot_id")
            )

        elif api_path == "/appointments/cancel":
            result = cancel_appointment(parameters.get("appointment_id"))

        else:
            result = {
                "success": False,
                "error": f"Unknown API path: {api_path}",
                "error_code": "INVALID_PATH"
            }

        # Return in Bedrock Agent expected format
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": action_group,
                "apiPath": api_path,
                "httpMethod": http_method,
                "httpStatusCode": 200 if result.get("success") else 400,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps(result)
                    }
                }
            }
        }

    except Exception as e:
        logger.exception("Error processing action request")
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": event.get("apiPath", ""),
                "httpMethod": event.get("httpMethod", ""),
                "httpStatusCode": 500,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps({
                            "success": False,
                            "error": str(e),
                            "error_code": "INTERNAL_ERROR"
                        })
                    }
                }
            }
        }
