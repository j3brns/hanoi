"""
Bedrock Agent Action Handler - Analytics (Agent 05)
====================================================
Production-ready analytics and reporting functions for appointment insights.

Features:
- Appointment metrics and KPIs
- Trend analysis
- Performance reporting
- Customer insights
- AWS Lambda Powertools integration
"""

import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from collections import defaultdict, Counter
from aws_lambda_powertools import Logger, Tracer
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger(service="analytics-agent")
tracer = Tracer(service="analytics-agent")

# ============================================================================
# IN-MEMORY ANALYTICS STORE
# ============================================================================

ANALYTICS_DATA: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

# Mock appointment data for analytics
APPOINTMENT_EVENTS = []

# ============================================================================
# ANALYTICS FUNCTIONS
# ============================================================================

@tracer.capture_method
def track_appointment_event(
    event_type: str,
    appointment_id: str,
    customer_id: str,
    service_type: str,
    metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Track an appointment event for analytics

    Args:
        event_type: Event type (created, rescheduled, cancelled, completed)
        appointment_id: Appointment identifier
        customer_id: Customer identifier
        service_type: Type of service
        metadata: Additional event metadata

    Returns:
        Tracking confirmation
    """
    logger.info(f"Tracking {event_type} event for appointment {appointment_id}")

    try:
        event = {
            "event_id": f"EVT-{len(APPOINTMENT_EVENTS) + 1:08d}",
            "event_type": event_type,
            "appointment_id": appointment_id,
            "customer_id": customer_id,
            "service_type": service_type,
            "metadata": metadata or {},
            "timestamp": datetime.utcnow().isoformat()
        }

        APPOINTMENT_EVENTS.append(event)
        ANALYTICS_DATA[customer_id].append(event)

        return {
            "success": True,
            "event": event,
            "message": "Event tracked successfully"
        }

    except Exception as e:
        logger.error(f"Failed to track event: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "TRACKING_ERROR"
        }

@tracer.capture_method
def get_appointment_metrics(
    start_date: str,
    end_date: str,
    service_type: Optional[str] = None
) -> Dict[str, Any]:
    """
    Get appointment metrics for a date range

    Args:
        start_date: Start date (ISO format)
        end_date: End date (ISO format)
        service_type: Filter by service type

    Returns:
        Appointment metrics
    """
    logger.info(f"Calculating metrics from {start_date} to {end_date}")

    try:
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))

        # Filter events
        filtered_events = [
            e for e in APPOINTMENT_EVENTS
            if start_dt <= datetime.fromisoformat(e["timestamp"]) <= end_dt
        ]

        if service_type:
            filtered_events = [e for e in filtered_events if e["service_type"] == service_type]

        # Calculate metrics
        total_appointments = len([e for e in filtered_events if e["event_type"] == "created"])
        completed = len([e for e in filtered_events if e["event_type"] == "completed"])
        cancelled = len([e for e in filtered_events if e["event_type"] == "cancelled"])
        rescheduled = len([e for e in filtered_events if e["event_type"] == "rescheduled"])

        completion_rate = (completed / total_appointments * 100) if total_appointments > 0 else 0
        cancellation_rate = (cancelled / total_appointments * 100) if total_appointments > 0 else 0

        return {
            "success": True,
            "period": {
                "start_date": start_date,
                "end_date": end_date
            },
            "metrics": {
                "total_appointments": total_appointments,
                "completed": completed,
                "cancelled": cancelled,
                "rescheduled": rescheduled,
                "completion_rate": round(completion_rate, 2),
                "cancellation_rate": round(cancellation_rate, 2)
            }
        }

    except Exception as e:
        logger.error(f"Failed to calculate metrics: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "METRICS_ERROR"
        }

@tracer.capture_method
def get_service_type_distribution(
    start_date: str,
    end_date: str
) -> Dict[str, Any]:
    """
    Get distribution of appointments by service type

    Args:
        start_date: Start date (ISO format)
        end_date: End date (ISO format)

    Returns:
        Service type distribution
    """
    logger.info("Calculating service type distribution")

    try:
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))

        # Filter events
        filtered_events = [
            e for e in APPOINTMENT_EVENTS
            if start_dt <= datetime.fromisoformat(e["timestamp"]) <= end_dt
            and e["event_type"] == "created"
        ]

        # Count by service type
        service_counts = Counter(e["service_type"] for e in filtered_events)
        total = sum(service_counts.values())

        distribution = [
            {
                "service_type": service_type,
                "count": count,
                "percentage": round((count / total * 100) if total > 0 else 0, 2)
            }
            for service_type, count in service_counts.most_common()
        ]

        return {
            "success": True,
            "period": {
                "start_date": start_date,
                "end_date": end_date
            },
            "total_appointments": total,
            "distribution": distribution
        }

    except Exception as e:
        logger.error(f"Failed to calculate distribution: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "DISTRIBUTION_ERROR"
        }

@tracer.capture_method
def get_customer_insights(customer_id: str) -> Dict[str, Any]:
    """
    Get analytics insights for a specific customer

    Args:
        customer_id: Customer identifier

    Returns:
        Customer insights
    """
    logger.info(f"Getting insights for customer {customer_id}")

    try:
        customer_events = ANALYTICS_DATA.get(customer_id, [])

        if not customer_events:
            return {
                "success": True,
                "customer_id": customer_id,
                "total_events": 0,
                "message": "No events found for this customer"
            }

        # Calculate insights
        total_appointments = len([e for e in customer_events if e["event_type"] == "created"])
        completed = len([e for e in customer_events if e["event_type"] == "completed"])
        cancelled = len([e for e in customer_events if e["event_type"] == "cancelled"])
        rescheduled = len([e for e in customer_events if e["event_type"] == "rescheduled"])

        service_counts = Counter(e["service_type"] for e in customer_events if e["event_type"] == "created")
        most_common_service = service_counts.most_common(1)[0] if service_counts else ("N/A", 0)

        # First and last appointment
        sorted_events = sorted(customer_events, key=lambda x: x["timestamp"])
        first_appointment = sorted_events[0]["timestamp"] if sorted_events else None
        last_appointment = sorted_events[-1]["timestamp"] if sorted_events else None

        return {
            "success": True,
            "customer_id": customer_id,
            "insights": {
                "total_appointments": total_appointments,
                "completed": completed,
                "cancelled": cancelled,
                "rescheduled": rescheduled,
                "most_common_service": {
                    "service_type": most_common_service[0],
                    "count": most_common_service[1]
                },
                "first_appointment_date": first_appointment,
                "last_appointment_date": last_appointment,
                "customer_lifetime_days": (
                    datetime.fromisoformat(last_appointment) - datetime.fromisoformat(first_appointment)
                ).days if first_appointment and last_appointment else 0
            }
        }

    except Exception as e:
        logger.error(f"Failed to get customer insights: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "INSIGHTS_ERROR"
        }

@tracer.capture_method
def get_trend_analysis(
    metric: str,
    start_date: str,
    end_date: str,
    interval: str = "daily"
) -> Dict[str, Any]:
    """
    Get trend analysis for a specific metric

    Args:
        metric: Metric to analyze (appointments, completions, cancellations)
        start_date: Start date (ISO format)
        end_date: End date (ISO format)
        interval: Analysis interval (daily, weekly, monthly)

    Returns:
        Trend analysis data
    """
    logger.info(f"Analyzing {metric} trend from {start_date} to {end_date} ({interval})")

    try:
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))

        # Map metric to event type
        event_type_map = {
            "appointments": "created",
            "completions": "completed",
            "cancellations": "cancelled",
            "rescheduled": "rescheduled"
        }

        event_type = event_type_map.get(metric)
        if not event_type:
            return {
                "success": False,
                "error": f"Invalid metric: {metric}",
                "error_code": "INVALID_METRIC"
            }

        # Filter events
        filtered_events = [
            e for e in APPOINTMENT_EVENTS
            if start_dt <= datetime.fromisoformat(e["timestamp"]) <= end_dt
            and e["event_type"] == event_type
        ]

        # Group by interval
        trend_data = defaultdict(int)
        for event in filtered_events:
            event_dt = datetime.fromisoformat(event["timestamp"])

            if interval == "daily":
                key = event_dt.strftime("%Y-%m-%d")
            elif interval == "weekly":
                key = event_dt.strftime("%Y-W%U")
            elif interval == "monthly":
                key = event_dt.strftime("%Y-%m")
            else:
                key = event_dt.strftime("%Y-%m-%d")

            trend_data[key] += 1

        # Convert to list
        trend_list = [
            {"period": period, "count": count}
            for period, count in sorted(trend_data.items())
        ]

        return {
            "success": True,
            "metric": metric,
            "interval": interval,
            "period": {
                "start_date": start_date,
                "end_date": end_date
            },
            "data_points": len(trend_list),
            "trend_data": trend_list
        }

    except Exception as e:
        logger.error(f"Failed to analyze trend: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "TREND_ERROR"
        }

@tracer.capture_method
def generate_report(
    report_type: str,
    start_date: str,
    end_date: str
) -> Dict[str, Any]:
    """
    Generate a comprehensive analytics report

    Args:
        report_type: Type of report (summary, detailed, customer)
        start_date: Report start date
        end_date: Report end date

    Returns:
        Generated report
    """
    logger.info(f"Generating {report_type} report")

    try:
        metrics = get_appointment_metrics(start_date, end_date)
        distribution = get_service_type_distribution(start_date, end_date)

        report = {
            "report_type": report_type,
            "generated_at": datetime.utcnow().isoformat(),
            "period": {
                "start_date": start_date,
                "end_date": end_date
            },
            "summary": metrics.get("metrics", {}),
            "service_distribution": distribution.get("distribution", [])
        }

        return {
            "success": True,
            "report": report
        }

    except Exception as e:
        logger.error(f"Failed to generate report: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "REPORT_ERROR"
        }

# ============================================================================
# BEDROCK AGENT ACTION HANDLER
# ============================================================================

@logger.inject_lambda_context(log_event=True)
@tracer.capture_lambda_handler
def lambda_handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """
    Main Lambda handler for Bedrock Agent action group
    """
    logger.info("Processing Analytics Agent action request")

    try:
        api_path = event.get("apiPath", "")
        parameters = {p["name"]: p["value"] for p in event.get("parameters", [])}

        logger.info(f"Path: {api_path}, Parameters: {parameters}")

        result = None

        if api_path == "/analytics/track":
            metadata = json.loads(parameters.get("metadata", "{}"))
            result = track_appointment_event(
                parameters.get("event_type"),
                parameters.get("appointment_id"),
                parameters.get("customer_id"),
                parameters.get("service_type"),
                metadata
            )

        elif api_path == "/analytics/metrics":
            result = get_appointment_metrics(
                parameters.get("start_date"),
                parameters.get("end_date"),
                parameters.get("service_type")
            )

        elif api_path == "/analytics/distribution":
            result = get_service_type_distribution(
                parameters.get("start_date"),
                parameters.get("end_date")
            )

        elif api_path == "/analytics/customer-insights":
            result = get_customer_insights(parameters.get("customer_id"))

        elif api_path == "/analytics/trend":
            result = get_trend_analysis(
                parameters.get("metric"),
                parameters.get("start_date"),
                parameters.get("end_date"),
                parameters.get("interval", "daily")
            )

        elif api_path == "/analytics/report":
            result = generate_report(
                parameters.get("report_type"),
                parameters.get("start_date"),
                parameters.get("end_date")
            )

        else:
            result = {
                "success": False,
                "error": f"Unknown API path: {api_path}",
                "error_code": "INVALID_PATH"
            }

        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": api_path,
                "httpMethod": event.get("httpMethod", ""),
                "httpStatusCode": 200 if result.get("success") else 400,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps(result)
                    }
                }
            }
        }

    except Exception as e:
        logger.exception("Error processing action request")
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": event.get("apiPath", ""),
                "httpMethod": event.get("httpMethod", ""),
                "httpStatusCode": 500,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps({
                            "success": False,
                            "error": str(e),
                            "error_code": "INTERNAL_ERROR"
                        })
                    }
                }
            }
        }
