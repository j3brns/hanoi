"""
Bedrock Agent Action Handler - Time Management (Agent 02)
==========================================================
Production-ready time and scheduling functions for appointment coordination.

Features:
- Timezone conversions
- Business hours validation
- Duration calculations
- Conflict detection
- AWS Lambda Powertools integration
"""

import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
from zoneinfo import ZoneInfo
from aws_lambda_powertools import Logger, Tracer
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger(service="time-agent")
tracer = Tracer(service="time-agent")

# ============================================================================
# BUSINESS RULES
# ============================================================================

BUSINESS_HOURS_START = 9  # 9 AM
BUSINESS_HOURS_END = 17   # 5 PM
BUSINESS_DAYS = [0, 1, 2, 3, 4]  # Monday to Friday
DEFAULT_TIMEZONE = "America/New_York"

# ============================================================================
# TIME MANAGEMENT FUNCTIONS
# ============================================================================

@tracer.capture_method
def get_current_time(timezone_str: Optional[str] = None) -> Dict[str, Any]:
    """
    Get current time in specified timezone

    Args:
        timezone_str: IANA timezone name (e.g., 'America/New_York')

    Returns:
        Current time information
    """
    tz = ZoneInfo(timezone_str) if timezone_str else ZoneInfo(DEFAULT_TIMEZONE)
    now = datetime.now(tz)

    logger.info(f"Current time in {timezone_str or DEFAULT_TIMEZONE}: {now.isoformat()}")

    return {
        "success": True,
        "current_time": now.isoformat(),
        "timezone": str(tz),
        "timestamp": int(now.timestamp()),
        "formatted": now.strftime("%Y-%m-%d %H:%M:%S %Z")
    }

@tracer.capture_method
def convert_timezone(
    time_str: str,
    from_timezone: str,
    to_timezone: str
) -> Dict[str, Any]:
    """
    Convert time from one timezone to another

    Args:
        time_str: ISO format timestamp
        from_timezone: Source timezone
        to_timezone: Target timezone

    Returns:
        Converted time information
    """
    logger.info(f"Converting {time_str} from {from_timezone} to {to_timezone}")

    try:
        # Parse the input time
        dt = datetime.fromisoformat(time_str.replace('Z', '+00:00'))

        # Apply source timezone
        from_tz = ZoneInfo(from_timezone)
        dt_from = dt.replace(tzinfo=from_tz)

        # Convert to target timezone
        to_tz = ZoneInfo(to_timezone)
        dt_to = dt_from.astimezone(to_tz)

        return {
            "success": True,
            "original_time": dt_from.isoformat(),
            "converted_time": dt_to.isoformat(),
            "from_timezone": from_timezone,
            "to_timezone": to_timezone,
            "time_difference_hours": (dt_to.utcoffset().total_seconds() - dt_from.utcoffset().total_seconds()) / 3600
        }

    except Exception as e:
        logger.error(f"Timezone conversion failed: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "CONVERSION_ERROR"
        }

@tracer.capture_method
def is_business_hours(
    time_str: str,
    timezone_str: Optional[str] = None
) -> Dict[str, Any]:
    """
    Check if a given time falls within business hours

    Args:
        time_str: ISO format timestamp
        timezone_str: Timezone for business hours check

    Returns:
        Business hours validation result
    """
    tz = ZoneInfo(timezone_str) if timezone_str else ZoneInfo(DEFAULT_TIMEZONE)

    try:
        dt = datetime.fromisoformat(time_str.replace('Z', '+00:00'))
        dt = dt.astimezone(tz)

        is_business_day = dt.weekday() in BUSINESS_DAYS
        is_business_time = BUSINESS_HOURS_START <= dt.hour < BUSINESS_HOURS_END

        logger.info(f"Business hours check: day={is_business_day}, time={is_business_time}")

        return {
            "success": True,
            "is_business_hours": is_business_day and is_business_time,
            "is_business_day": is_business_day,
            "is_business_time": is_business_time,
            "day_of_week": dt.strftime("%A"),
            "hour": dt.hour,
            "business_hours_range": f"{BUSINESS_HOURS_START}:00-{BUSINESS_HOURS_END}:00"
        }

    except Exception as e:
        logger.error(f"Business hours check failed: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "VALIDATION_ERROR"
        }

@tracer.capture_method
def calculate_duration(start_time: str, end_time: str) -> Dict[str, Any]:
    """
    Calculate duration between two timestamps

    Args:
        start_time: Start timestamp (ISO format)
        end_time: End timestamp (ISO format)

    Returns:
        Duration information
    """
    logger.info(f"Calculating duration from {start_time} to {end_time}")

    try:
        start = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_time.replace('Z', '+00:00'))

        duration = end - start
        total_seconds = int(duration.total_seconds())

        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        return {
            "success": True,
            "duration_seconds": total_seconds,
            "duration_minutes": total_seconds // 60,
            "duration_hours": total_seconds / 3600,
            "formatted_duration": f"{hours}h {minutes}m {seconds}s",
            "is_positive": total_seconds >= 0
        }

    except Exception as e:
        logger.error(f"Duration calculation failed: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "CALCULATION_ERROR"
        }

@tracer.capture_method
def find_next_business_day(
    start_date: Optional[str] = None,
    timezone_str: Optional[str] = None
) -> Dict[str, Any]:
    """
    Find the next business day from a given date

    Args:
        start_date: Starting date (ISO format), defaults to today
        timezone_str: Timezone for calculation

    Returns:
        Next business day information
    """
    tz = ZoneInfo(timezone_str) if timezone_str else ZoneInfo(DEFAULT_TIMEZONE)

    try:
        if start_date:
            dt = datetime.fromisoformat(start_date.replace('Z', '+00:00')).astimezone(tz)
        else:
            dt = datetime.now(tz)

        # Find next business day
        next_day = dt + timedelta(days=1)
        while next_day.weekday() not in BUSINESS_DAYS:
            next_day += timedelta(days=1)

        # Set to start of business hours
        next_business_day = next_day.replace(hour=BUSINESS_HOURS_START, minute=0, second=0, microsecond=0)

        logger.info(f"Next business day: {next_business_day.isoformat()}")

        return {
            "success": True,
            "next_business_day": next_business_day.isoformat(),
            "day_name": next_business_day.strftime("%A"),
            "days_from_start": (next_business_day.date() - dt.date()).days,
            "business_hours_start": f"{BUSINESS_HOURS_START}:00"
        }

    except Exception as e:
        logger.error(f"Next business day calculation failed: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "CALCULATION_ERROR"
        }

@tracer.capture_method
def check_time_conflicts(
    appointments: List[Dict[str, str]]
) -> Dict[str, Any]:
    """
    Check for time conflicts in a list of appointments

    Args:
        appointments: List of appointments with start_time and end_time

    Returns:
        Conflict detection results
    """
    logger.info(f"Checking conflicts for {len(appointments)} appointments")

    conflicts = []

    try:
        # Parse and sort appointments
        parsed_appointments = []
        for i, appt in enumerate(appointments):
            start = datetime.fromisoformat(appt["start_time"].replace('Z', '+00:00'))
            end = datetime.fromisoformat(appt["end_time"].replace('Z', '+00:00'))
            parsed_appointments.append({
                "index": i,
                "start": start,
                "end": end,
                "original": appt
            })

        parsed_appointments.sort(key=lambda x: x["start"])

        # Check for overlaps
        for i in range(len(parsed_appointments) - 1):
            current = parsed_appointments[i]
            next_appt = parsed_appointments[i + 1]

            if current["end"] > next_appt["start"]:
                conflicts.append({
                    "appointment_1_index": current["index"],
                    "appointment_2_index": next_appt["index"],
                    "conflict_type": "overlap",
                    "overlap_duration_minutes": int((current["end"] - next_appt["start"]).total_seconds() / 60)
                })

        return {
            "success": True,
            "has_conflicts": len(conflicts) > 0,
            "conflict_count": len(conflicts),
            "conflicts": conflicts
        }

    except Exception as e:
        logger.error(f"Conflict detection failed: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "error_code": "DETECTION_ERROR"
        }

# ============================================================================
# BEDROCK AGENT ACTION HANDLER
# ============================================================================

@logger.inject_lambda_context(log_event=True)
@tracer.capture_lambda_handler
def lambda_handler(event: Dict[str, Any], context: LambdaContext) -> Dict[str, Any]:
    """
    Main Lambda handler for Bedrock Agent action group
    """
    logger.info("Processing Time Agent action request")

    try:
        api_path = event.get("apiPath", "")
        parameters = {p["name"]: p["value"] for p in event.get("parameters", [])}

        logger.info(f"Path: {api_path}, Parameters: {parameters}")

        # Route to appropriate function
        result = None

        if api_path == "/time/current":
            result = get_current_time(parameters.get("timezone"))

        elif api_path == "/time/convert":
            result = convert_timezone(
                parameters.get("time"),
                parameters.get("from_timezone"),
                parameters.get("to_timezone")
            )

        elif api_path == "/time/business-hours":
            result = is_business_hours(
                parameters.get("time"),
                parameters.get("timezone")
            )

        elif api_path == "/time/duration":
            result = calculate_duration(
                parameters.get("start_time"),
                parameters.get("end_time")
            )

        elif api_path == "/time/next-business-day":
            result = find_next_business_day(
                parameters.get("start_date"),
                parameters.get("timezone")
            )

        elif api_path == "/time/check-conflicts":
            # Parse appointments from request body
            appointments = json.loads(event.get("requestBody", {}).get("content", {}).get("application/json", "[]"))
            result = check_time_conflicts(appointments)

        else:
            result = {
                "success": False,
                "error": f"Unknown API path: {api_path}",
                "error_code": "INVALID_PATH"
            }

        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": api_path,
                "httpMethod": event.get("httpMethod", ""),
                "httpStatusCode": 200 if result.get("success") else 400,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps(result)
                    }
                }
            }
        }

    except Exception as e:
        logger.exception("Error processing action request")
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "apiPath": event.get("apiPath", ""),
                "httpMethod": event.get("httpMethod", ""),
                "httpStatusCode": 500,
                "responseBody": {
                    "application/json": {
                        "body": json.dumps({
                            "success": False,
                            "error": str(e),
                            "error_code": "INTERNAL_ERROR"
                        })
                    }
                }
            }
        }
