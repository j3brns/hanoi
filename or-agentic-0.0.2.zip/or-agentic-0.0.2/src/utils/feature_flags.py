"""
Feature Flags Client for Agent Canary Deployments

Uses AWS AppConfig to dynamically route requests between blue/green agent aliases.
Supports:
- Percentage-based canary rollout
- Tenant-specific feature flags
- Immediate rollback capability
"""
import hashlib
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

from .observability import logger

# Configuration
APPCONFIG_APP_ID = os.environ.get("APPCONFIG_APP_ID", "")
APPCONFIG_ENV_ID = os.environ.get("APPCONFIG_ENV_ID", "")
APPCONFIG_CONFIG_PROFILE_ID = os.environ.get("APPCONFIG_CONFIG_PROFILE_ID", "")
APPCONFIG_POLL_INTERVAL_SECONDS = int(os.environ.get("APPCONFIG_POLL_INTERVAL", "30"))

# Default agent aliases
DEFAULT_BLUE_ALIAS = os.environ.get("BEDROCK_AGENT_ALIAS_BLUE", "")
DEFAULT_GREEN_ALIAS = os.environ.get("BEDROCK_AGENT_ALIAS_GREEN", "")

# Initialize AppConfig client
boto_config = Config(
    retries={"max_attempts": 3, "mode": "adaptive"},
    connect_timeout=5,
    read_timeout=10,
)
appconfig_client = boto3.client("appconfigdata", config=boto_config)


@dataclass
class AgentCanaryConfig:
    """Configuration for agent canary deployment."""
    enabled: bool = False
    percentage: int = 0
    blue_alias_id: str = ""
    green_alias_id: str = ""
    active_alias: str = "blue"


@dataclass
class FeatureFlags:
    """Feature flags from AppConfig."""
    enable_streaming: bool = True
    enable_guardrails: bool = True
    agent_canary: AgentCanaryConfig = None
    max_concurrent_requests: int = 100
    default_timeout_seconds: int = 30

    def __post_init__(self):
        if self.agent_canary is None:
            self.agent_canary = AgentCanaryConfig()


class FeatureFlagClient:
    """
    Client for retrieving feature flags from AWS AppConfig.

    Implements caching with configurable TTL and automatic refresh.
    """

    def __init__(self):
        self._cache: Optional[FeatureFlags] = None
        self._cache_time: float = 0
        self._config_token: Optional[str] = None
        self._poll_interval = APPCONFIG_POLL_INTERVAL_SECONDS

    def _start_configuration_session(self) -> Optional[str]:
        """Start AppConfig configuration session."""
        if not all([APPCONFIG_APP_ID, APPCONFIG_ENV_ID, APPCONFIG_CONFIG_PROFILE_ID]):
            logger.warning("AppConfig not fully configured, using defaults")
            return None

        try:
            response = appconfig_client.start_configuration_session(
                ApplicationIdentifier=APPCONFIG_APP_ID,
                EnvironmentIdentifier=APPCONFIG_ENV_ID,
                ConfigurationProfileIdentifier=APPCONFIG_CONFIG_PROFILE_ID,
                RequiredMinimumPollIntervalInSeconds=self._poll_interval,
            )
            return response.get("InitialConfigurationToken")
        except ClientError as e:
            logger.error("Failed to start AppConfig session", error=str(e))
            return None

    def _get_latest_configuration(self) -> Optional[Dict[str, Any]]:
        """Get latest configuration from AppConfig."""
        if not self._config_token:
            self._config_token = self._start_configuration_session()

        if not self._config_token:
            return None

        try:
            response = appconfig_client.get_latest_configuration(
                ConfigurationToken=self._config_token
            )

            # Update token for next poll
            self._config_token = response.get("NextPollConfigurationToken")

            # Parse configuration if present
            content = response.get("Configuration")
            if content:
                import json
                return json.loads(content.read().decode("utf-8"))

            return None  # No update available

        except ClientError as e:
            logger.error("Failed to get AppConfig configuration", error=str(e))
            self._config_token = None  # Reset token on error
            return None

    def get_flags(self, force_refresh: bool = False) -> FeatureFlags:
        """
        Get current feature flags.

        Uses cached values if within poll interval unless force_refresh is True.
        """
        current_time = time.time()

        # Return cached if still valid
        if (
            not force_refresh
            and self._cache is not None
            and (current_time - self._cache_time) < self._poll_interval
        ):
            return self._cache

        # Try to get latest configuration
        config = self._get_latest_configuration()

        if config:
            # Parse flags
            flags_data = config.get("flags", {})
            values_data = config.get("values", {})

            # Parse canary config
            canary_data = flags_data.get("agent_canary", {})
            canary_config = AgentCanaryConfig(
                enabled=canary_data.get("enabled", False),
                percentage=canary_data.get("percentage", 0),
                blue_alias_id=canary_data.get("blue_alias_id", DEFAULT_BLUE_ALIAS),
                green_alias_id=canary_data.get("green_alias_id", DEFAULT_GREEN_ALIAS),
                active_alias=canary_data.get("active_alias", "blue"),
            )

            self._cache = FeatureFlags(
                enable_streaming=flags_data.get("enable_streaming", {}).get("enabled", True),
                enable_guardrails=flags_data.get("enable_guardrails", {}).get("enabled", True),
                agent_canary=canary_config,
                max_concurrent_requests=values_data.get("max_concurrent_requests", 100),
                default_timeout_seconds=values_data.get("default_timeout_seconds", 30),
            )
            self._cache_time = current_time

        # Return cached or default
        if self._cache is None:
            self._cache = FeatureFlags(
                agent_canary=AgentCanaryConfig(
                    blue_alias_id=DEFAULT_BLUE_ALIAS,
                    green_alias_id=DEFAULT_GREEN_ALIAS,
                )
            )
            self._cache_time = current_time

        return self._cache


# Global client instance
_feature_flag_client = FeatureFlagClient()


def get_feature_flags(force_refresh: bool = False) -> FeatureFlags:
    """Get current feature flags."""
    return _feature_flag_client.get_flags(force_refresh)


def select_agent_alias(
    tenant_id: str,
    session_id: str,
    flags: Optional[FeatureFlags] = None,
) -> str:
    """
    Select which agent alias to use based on canary configuration.

    Uses consistent hashing to ensure the same session always routes to the same alias.
    This prevents mid-conversation switches between agent versions.

    Args:
        tenant_id: Tenant identifier
        session_id: Session identifier
        flags: Optional feature flags (will fetch if not provided)

    Returns:
        Agent alias ID to use for this request
    """
    if flags is None:
        flags = get_feature_flags()

    canary = flags.agent_canary

    # If canary not enabled, use the active alias
    if not canary.enabled:
        if canary.active_alias == "green":
            return canary.green_alias_id or DEFAULT_GREEN_ALIAS
        return canary.blue_alias_id or DEFAULT_BLUE_ALIAS

    # Use consistent hashing based on session_id for sticky routing
    # This ensures the same session always goes to the same alias
    hash_input = f"{tenant_id}:{session_id}"
    hash_value = int(hashlib.md5(hash_input.encode()).hexdigest(), 16)
    bucket = hash_value % 100

    if bucket < canary.percentage:
        logger.info(
            "Routing to canary (green) alias",
            tenant_id=tenant_id,
            session_id=session_id,
            canary_percentage=canary.percentage,
        )
        return canary.green_alias_id or DEFAULT_GREEN_ALIAS
    else:
        return canary.blue_alias_id or DEFAULT_BLUE_ALIAS


def is_feature_enabled(feature_name: str) -> bool:
    """
    Check if a specific feature is enabled.

    Args:
        feature_name: Name of the feature (e.g., 'enable_streaming')

    Returns:
        True if feature is enabled
    """
    flags = get_feature_flags()
    return getattr(flags, feature_name, False)
