"""
Observability module using AWS Lambda Powertools.

Provides:
- Structured logging with PII redaction
- X-Ray distributed tracing
- CloudWatch custom metrics with tenant dimensions
"""
import re
from typing import Any, Dict, Optional
from functools import wraps

from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.metrics import MetricUnit
from aws_lambda_powertools.utilities.typing import LambdaContext

from .constants import PII_PATTERNS, HEADER_CORRELATION_ID, HEADER_TENANT_ID

# Initialize Powertools
logger = Logger(
    service="telecom-virtual-assistant",
    log_uncaught_exceptions=True,
)

tracer = Tracer(service="telecom-virtual-assistant")

metrics = Metrics(
    service="telecom-virtual-assistant",
    namespace="TelecomAgent/Appointments",
)


class PIIRedactor:
    """Redacts PII from log messages."""

    def __init__(self):
        self.patterns = [re.compile(p, re.IGNORECASE) for p in PII_PATTERNS]

    def redact(self, text: str) -> str:
        """Redact PII patterns from text."""
        if not text:
            return text
        result = text
        for pattern in self.patterns:
            result = pattern.sub("[REDACTED]", result)
        return result

    def redact_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively redact PII from dictionary values."""
        if not data:
            return data
        result = {}
        for key, value in data.items():
            if isinstance(value, str):
                result[key] = self.redact(value)
            elif isinstance(value, dict):
                result[key] = self.redact_dict(value)
            elif isinstance(value, list):
                result[key] = [
                    self.redact(v) if isinstance(v, str)
                    else self.redact_dict(v) if isinstance(v, dict)
                    else v
                    for v in value
                ]
            else:
                result[key] = value
        return result


# Global PII redactor instance
pii_redactor = PIIRedactor()


def log_with_context(
    level: str,
    message: str,
    tenant_id: Optional[str] = None,
    correlation_id: Optional[str] = None,
    extra: Optional[Dict[str, Any]] = None,
    redact_pii: bool = True,
) -> None:
    """
    Log message with tenant context and optional PII redaction.

    Args:
        level: Log level (info, warning, error, debug)
        message: Log message
        tenant_id: Tenant identifier
        correlation_id: Request correlation ID
        extra: Additional context to log
        redact_pii: Whether to redact PII patterns
    """
    log_data = {
        "tenant_id": tenant_id,
        "correlation_id": correlation_id,
    }

    if extra:
        if redact_pii:
            extra = pii_redactor.redact_dict(extra)
        log_data.update(extra)

    if redact_pii:
        message = pii_redactor.redact(message)

    log_func = getattr(logger, level, logger.info)
    log_func(message, **log_data)


def add_tenant_dimension(tenant_id: str) -> None:
    """Add tenant dimension to metrics."""
    metrics.add_dimension(name="TenantId", value=tenant_id)


def record_latency(
    operation: str,
    latency_ms: float,
    tenant_id: Optional[str] = None,
) -> None:
    """Record operation latency metric."""
    if tenant_id:
        add_tenant_dimension(tenant_id)
    metrics.add_metric(
        name=f"{operation}Latency",
        unit=MetricUnit.Milliseconds,
        value=latency_ms,
    )


def record_invocation(
    tenant_id: str,
    success: bool = True,
) -> None:
    """Record agent invocation metric."""
    add_tenant_dimension(tenant_id)
    metrics.add_metric(
        name="Invocations",
        unit=MetricUnit.Count,
        value=1,
    )
    if success:
        metrics.add_metric(
            name="SuccessfulInvocations",
            unit=MetricUnit.Count,
            value=1,
        )
    else:
        metrics.add_metric(
            name="FailedInvocations",
            unit=MetricUnit.Count,
            value=1,
        )


def record_streaming_chunks(count: int, tenant_id: Optional[str] = None) -> None:
    """Record number of streaming chunks."""
    if tenant_id:
        add_tenant_dimension(tenant_id)
    metrics.add_metric(
        name="StreamingChunks",
        unit=MetricUnit.Count,
        value=count,
    )


def record_response_length(length: int, tenant_id: Optional[str] = None) -> None:
    """Record response length metric."""
    if tenant_id:
        add_tenant_dimension(tenant_id)
    metrics.add_metric(
        name="ResponseLength",
        unit=MetricUnit.Bytes,
        value=length,
    )


def extract_context_from_event(event: Dict[str, Any]) -> Dict[str, Optional[str]]:
    """Extract tenant and correlation context from API Gateway event."""
    headers = event.get("headers", {}) or {}
    # Handle case-insensitive headers
    headers_lower = {k.lower(): v for k, v in headers.items()}

    return {
        "tenant_id": headers_lower.get(HEADER_TENANT_ID.lower()),
        "correlation_id": headers_lower.get(HEADER_CORRELATION_ID.lower()),
        "request_id": event.get("requestContext", {}).get("requestId"),
    }


def inject_lambda_context(handler):
    """
    Decorator to inject Lambda context and set up observability.

    Combines Powertools decorators with custom context injection.
    """
    @tracer.capture_lambda_handler
    @logger.inject_lambda_context(log_event=True)
    @metrics.log_metrics(capture_cold_start_metric=True)
    @wraps(handler)
    def wrapper(event: Dict[str, Any], context: LambdaContext):
        # Extract context from event
        ctx = extract_context_from_event(event)

        # Append context to logger
        logger.append_keys(
            tenant_id=ctx.get("tenant_id"),
            correlation_id=ctx.get("correlation_id"),
            request_id=ctx.get("request_id"),
        )

        # Add tenant dimension if available
        if ctx.get("tenant_id"):
            add_tenant_dimension(ctx["tenant_id"])

        return handler(event, context)

    return wrapper
