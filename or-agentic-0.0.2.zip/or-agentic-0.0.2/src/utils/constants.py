"""Constants and configuration for the Telecom Virtual Assistant."""
from dataclasses import dataclass
from enum import Enum
from typing import Optional
import os


class ErrorCodes(str, Enum):
    """Standardized error codes for API responses."""
    INVALID_REQUEST = "INVALID_REQUEST"
    UNAUTHORIZED = "UNAUTHORIZED"
    FORBIDDEN = "FORBIDDEN"
    NOT_FOUND = "NOT_FOUND"
    TENANT_NOT_FOUND = "TENANT_NOT_FOUND"
    RATE_LIMITED = "RATE_LIMITED"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
    AGENT_ERROR = "AGENT_ERROR"
    TIMEOUT = "TIMEOUT"
    VALIDATION_ERROR = "VALIDATION_ERROR"


class AppointmentStatus(str, Enum):
    """Appointment status values."""
    SCHEDULED = "scheduled"
    CONFIRMED = "confirmed"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    RESCHEDULED = "rescheduled"


class AppointmentType(str, Enum):
    """Types of telecommunications appointments."""
    INSTALLATION = "installation"
    MAINTENANCE = "maintenance"
    REPAIR = "repair"
    UPGRADE = "upgrade"
    INSPECTION = "inspection"


@dataclass
class TenantConfig:
    """Tenant-specific configuration."""
    tenant_id: str
    tenant_name: str
    api_endpoint: Optional[str] = None
    rate_limit: int = 200  # requests per minute
    max_concurrent: int = 20

    @classmethod
    def from_header(cls, tenant_id: str) -> "TenantConfig":
        """Create tenant config from tenant ID header."""
        return cls(
            tenant_id=tenant_id,
            tenant_name=f"tenant-{tenant_id}",
            api_endpoint=os.environ.get(f"TENANT_{tenant_id}_API_ENDPOINT"),
        )


# Environment configuration
TENANT_PREFIX = os.environ.get("TENANT_PREFIX", "APPID1234")
BEDROCK_AGENT_ID = os.environ.get("BEDROCK_AGENT_ID", "")
BEDROCK_AGENT_ALIAS_ID = os.environ.get("BEDROCK_AGENT_ALIAS_ID", "")
ENVIRONMENT = os.environ.get("ENVIRONMENT", "dev")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")

# DynamoDB table names
SESSIONS_TABLE = f"va-{TENANT_PREFIX}-sessions-{ENVIRONMENT}"
AUDIT_LOGS_TABLE = f"va-{TENANT_PREFIX}-audit-logs-{ENVIRONMENT}"
ASYNC_REQUESTS_TABLE = f"va-{TENANT_PREFIX}-async-requests-{ENVIRONMENT}"

# Performance thresholds
MAX_QUERY_LENGTH = 10000  # 10KB limit
STREAM_TIMEOUT_SECONDS = 900  # 15 minutes
IDLE_TIMEOUT_SECONDS = 300  # 5 minutes
TTFB_TARGET_MS = 500

# Rate limiting
WAF_RATE_LIMIT_PER_5MIN = 1000  # Aligned with 200 req/min tenant throughput

# Headers
HEADER_TENANT_ID = "X-Tenant-ID"
HEADER_CORRELATION_ID = "X-Correlation-ID"
HEADER_REQUEST_ID = "X-Request-ID"
HEADER_RATE_LIMIT = "X-RateLimit-Limit"
HEADER_RATE_REMAINING = "X-RateLimit-Remaining"
HEADER_RATE_RESET = "X-RateLimit-Reset"

# PII patterns for redaction
PII_PATTERNS = [
    r"\b\d{3}-\d{2}-\d{4}\b",  # SSN
    r"\b\d{16}\b",  # Credit card
    r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",  # Email
    r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b",  # Phone
]
