"""
Certificate Expiration Monitor

Monitors ACM certificates and alerts before expiration.
Triggered by EventBridge daily schedule.
"""
import json
import logging
import os
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for certificate monitoring.

    Checks certificate expiration and sends alerts via SNS.
    """
    certificate_arn = os.environ.get("CERTIFICATE_ARN", "")
    environment = os.environ.get("ENVIRONMENT", "dev")
    sns_topic_arn = os.environ.get("SNS_TOPIC_ARN", "")

    acm = boto3.client("acm")
    sns = boto3.client("sns")

    results = []

    try:
        # Get certificate details
        response = acm.describe_certificate(CertificateArn=certificate_arn)
        cert = response["Certificate"]

        domain = cert["DomainName"]
        status = cert["Status"]
        not_after = cert.get("NotAfter")

        if not_after:
            days_until_expiry = (not_after - datetime.now(timezone.utc)).days

            result = {
                "domain": domain,
                "status": status,
                "expires": not_after.isoformat(),
                "days_until_expiry": days_until_expiry,
            }
            results.append(result)

            # Alert thresholds
            if days_until_expiry <= 7:
                severity = "CRITICAL"
                message = f"CRITICAL: Certificate for {domain} expires in {days_until_expiry} days!"
            elif days_until_expiry <= 14:
                severity = "WARNING"
                message = f"WARNING: Certificate for {domain} expires in {days_until_expiry} days"
            elif days_until_expiry <= 30:
                severity = "INFO"
                message = f"INFO: Certificate for {domain} expires in {days_until_expiry} days"
            else:
                severity = None
                message = None

            if severity and sns_topic_arn:
                sns.publish(
                    TopicArn=sns_topic_arn,
                    Subject=f"[{severity}] Certificate Expiration Alert - {environment}",
                    Message=json.dumps({
                        "severity": severity,
                        "message": message,
                        "certificate": result,
                        "environment": environment,
                    }, indent=2),
                )
                logger.info(f"Sent {severity} alert for {domain}")

        else:
            logger.warning(f"Certificate {domain} has no expiration date")
            results.append({
                "domain": domain,
                "status": status,
                "error": "No expiration date found",
            })

    except ClientError as e:
        logger.error(f"Failed to check certificate: {e}")
        results.append({
            "error": str(e),
            "certificate_arn": certificate_arn,
        })

    return {
        "statusCode": 200,
        "body": json.dumps({
            "checked_at": datetime.now(timezone.utc).isoformat(),
            "results": results,
        }),
    }


def check_all_certificates(region: str = "us-east-1") -> List[Dict[str, Any]]:
    """
    Check all certificates in the account.

    Returns list of certificates with expiration info.
    """
    acm = boto3.client("acm", region_name=region)
    results = []

    try:
        paginator = acm.get_paginator("list_certificates")
        for page in paginator.paginate():
            for cert_summary in page["CertificateSummaryList"]:
                cert_arn = cert_summary["CertificateArn"]

                try:
                    response = acm.describe_certificate(CertificateArn=cert_arn)
                    cert = response["Certificate"]

                    not_after = cert.get("NotAfter")
                    days_until_expiry = None
                    if not_after:
                        days_until_expiry = (
                            not_after - datetime.now(timezone.utc)
                        ).days

                    results.append({
                        "arn": cert_arn,
                        "domain": cert["DomainName"],
                        "status": cert["Status"],
                        "type": cert["Type"],
                        "expires": not_after.isoformat() if not_after else None,
                        "days_until_expiry": days_until_expiry,
                        "in_use_by": cert.get("InUseBy", []),
                    })

                except ClientError as e:
                    logger.warning(f"Failed to describe certificate {cert_arn}: {e}")
                    results.append({
                        "arn": cert_arn,
                        "error": str(e),
                    })

    except ClientError as e:
        logger.error(f"Failed to list certificates: {e}")

    return results


def get_expiring_soon(days: int = 30, region: str = "us-east-1") -> List[Dict[str, Any]]:
    """
    Get certificates expiring within specified days.
    """
    all_certs = check_all_certificates(region)

    return [
        cert for cert in all_certs
        if cert.get("days_until_expiry") is not None
        and cert["days_until_expiry"] <= days
    ]


if __name__ == "__main__":
    # CLI usage for manual checks
    import argparse

    parser = argparse.ArgumentParser(description="Check certificate expiration")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--days", type=int, default=30, help="Days threshold")
    args = parser.parse_args()

    expiring = get_expiring_soon(days=args.days, region=args.region)

    if expiring:
        print(f"Certificates expiring within {args.days} days:")
        for cert in expiring:
            print(f"  - {cert['domain']}: {cert['days_until_expiry']} days")
    else:
        print(f"No certificates expiring within {args.days} days")
