# Telecom Virtual Assistant Lambda Functions
__version__ = "1.1.0"
