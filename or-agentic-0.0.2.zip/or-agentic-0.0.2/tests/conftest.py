"""Pytest configuration and fixtures."""
import json
import os
import pytest
from unittest.mock import MagicMock, patch

# Set test environment variables
os.environ["ENVIRONMENT"] = "test"
os.environ["TENANT_PREFIX"] = "APPID1234"
os.environ["BEDROCK_AGENT_ID"] = "test-agent-id"
os.environ["BEDROCK_AGENT_ALIAS_ID"] = "test-alias-id"
os.environ["AWS_REGION"] = "us-east-1"
os.environ["POWERTOOLS_SERVICE_NAME"] = "test-service"
os.environ["POWERTOOLS_METRICS_NAMESPACE"] = "Test/Metrics"


@pytest.fixture
def mock_dynamodb():
    """Mock DynamoDB resource."""
    with patch("boto3.resource") as mock:
        table = MagicMock()
        table.get_item.return_value = {"Item": {"sessionId": "test-session"}}
        table.put_item.return_value = {}
        mock.return_value.Table.return_value = table
        yield table


@pytest.fixture
def mock_bedrock():
    """Mock Bedrock Agent Runtime client."""
    with patch("boto3.client") as mock:
        client = MagicMock()
        client.invoke_agent.return_value = {
            "completion": [
                {"chunk": {"bytes": b"Hello, "}},
                {"chunk": {"bytes": b"how can I help you?"}},
            ]
        }
        mock.return_value = client
        yield client


@pytest.fixture
def sample_api_gateway_event():
    """Sample API Gateway event."""
    return {
        "httpMethod": "POST",
        "path": "/v1/agent/invoke",
        "headers": {
            "X-Tenant-ID": "tenant-123",
            "X-Correlation-ID": "corr-456",
            "Content-Type": "application/json",
        },
        "body": json.dumps({
            "query": "Show me my appointments for next week",
            "sessionId": "session-789",
        }),
        "isBase64Encoded": False,
        "requestContext": {
            "requestId": "request-abc",
            "stage": "test",
        },
    }


@pytest.fixture
def sample_bedrock_agent_event():
    """Sample Bedrock Agent action group event."""
    return {
        "actionGroup": "AppointmentManagement",
        "apiPath": "/appointments",
        "httpMethod": "GET",
        "parameters": [
            {"name": "customerId", "value": "cust-123"},
            {"name": "dateFrom", "value": "2026-01-10"},
        ],
        "requestBody": {},
        "sessionAttributes": {
            "tenantId": "tenant-123",
            "authToken": "test-jwt-token",
        },
    }


@pytest.fixture
def lambda_context():
    """Mock Lambda context."""
    context = MagicMock()
    context.function_name = "test-function"
    context.memory_limit_in_mb = 1024
    context.invoked_function_arn = "arn:aws:lambda:us-east-1:123456789:function:test"
    context.aws_request_id = "test-request-id"
    context.get_remaining_time_in_millis.return_value = 900000
    return context
