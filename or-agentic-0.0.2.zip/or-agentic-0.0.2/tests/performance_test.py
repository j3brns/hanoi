"""
Performance tests using Locust.

Tests per specification:
- 20 concurrent requests per tenant (yields ~200 req/min at 6s avg response)
- 10 tenants simultaneously
- TTFB < 500ms
- Error rate < 0.1%

Usage:
    locust -f tests/performance_test.py --host https://api.example.com
"""
import json
import random
import string
import time
from typing import Any, Dict

from locust import HttpUser, task, between, events
from locust.runners import MasterRunner


# Test configuration
TENANTS = [f"tenant-{i}" for i in range(1, 11)]  # 10 tenants
QUERIES = [
    "Show me my appointments for next week",
    "Find available installation slots for tomorrow",
    "Book the 2pm slot for fiber installation",
    "Reschedule my appointment to next Monday",
    "Cancel my appointment for today",
    "What are my upcoming maintenance appointments?",
    "Search for repair slots in the afternoon",
    "Show appointment history for the last month",
]


class TelecomAssistantUser(HttpUser):
    """Simulates a telecom field engineer or service coordinator."""

    wait_time = between(1, 3)  # 1-3 seconds between requests

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.tenant_id = random.choice(TENANTS)
        self.session_id = None
        self.ttfb_times = []

    def on_start(self):
        """Initialize user session."""
        self.session_id = f"{self.tenant_id}-{self._generate_id()}"

    def _generate_id(self, length: int = 8) -> str:
        """Generate random ID."""
        return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))

    def _get_headers(self) -> Dict[str, str]:
        """Get request headers with tenant context."""
        return {
            "X-Tenant-ID": self.tenant_id,
            "X-Correlation-ID": self._generate_id(16),
            "Content-Type": "application/json",
            "X-API-Key": "test-api-key",  # Replace with actual key in production
        }

    @task(10)
    def invoke_agent(self):
        """Invoke the virtual assistant with a random query."""
        query = random.choice(QUERIES)

        payload = {
            "query": query,
            "sessionId": self.session_id,
        }

        start_time = time.time()

        with self.client.post(
            "/v1/agent/invoke",
            headers=self._get_headers(),
            json=payload,
            catch_response=True,
        ) as response:
            # Calculate TTFB
            ttfb = (time.time() - start_time) * 1000

            if response.status_code == 200:
                try:
                    data = response.json()

                    # Validate response structure
                    if "response" not in data:
                        response.failure("Missing 'response' field")
                        return

                    # Check TTFB against target
                    if ttfb > 500:
                        response.failure(f"TTFB exceeded target: {ttfb:.2f}ms > 500ms")
                    else:
                        response.success()
                        self.ttfb_times.append(ttfb)

                    # Update session ID if provided
                    if "sessionId" in data:
                        self.session_id = data["sessionId"]

                except json.JSONDecodeError:
                    response.failure("Invalid JSON response")

            elif response.status_code == 429:
                response.failure("Rate limited")
            elif response.status_code == 503:
                response.failure("Service unavailable")
            else:
                response.failure(f"Unexpected status: {response.status_code}")

    @task(3)
    def health_check(self):
        """Check health endpoint."""
        with self.client.get("/health", catch_response=True) as response:
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("status") == "healthy":
                        response.success()
                    else:
                        response.failure(f"Unhealthy: {data.get('status')}")
                except json.JSONDecodeError:
                    response.failure("Invalid JSON")
            else:
                response.failure(f"Status: {response.status_code}")

    @task(2)
    def view_appointments(self):
        """View appointments query."""
        payload = {
            "query": f"Show me all appointments for customer cust-{random.randint(1, 100)}",
            "sessionId": self.session_id,
        }

        with self.client.post(
            "/v1/agent/invoke",
            headers=self._get_headers(),
            json=payload,
            catch_response=True,
        ) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Status: {response.status_code}")


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """Report test results on completion."""
    if isinstance(environment.runner, MasterRunner):
        return

    print("\n" + "=" * 60)
    print("PERFORMANCE TEST SUMMARY")
    print("=" * 60)

    stats = environment.stats
    total = stats.total

    print(f"Total Requests: {total.num_requests}")
    print(f"Failed Requests: {total.num_failures}")
    print(f"Error Rate: {(total.num_failures / max(total.num_requests, 1)) * 100:.2f}%")
    print(f"Avg Response Time: {total.avg_response_time:.2f}ms")
    print(f"P50 Response Time: {total.get_response_time_percentile(0.5):.2f}ms")
    print(f"P90 Response Time: {total.get_response_time_percentile(0.9):.2f}ms")
    print(f"P99 Response Time: {total.get_response_time_percentile(0.99):.2f}ms")
    print(f"Requests/sec: {total.current_rps:.2f}")

    # Validate against spec requirements
    print("\n" + "-" * 60)
    print("SPEC VALIDATION")
    print("-" * 60)

    error_rate = (total.num_failures / max(total.num_requests, 1)) * 100
    if error_rate < 0.1:
        print(f"[PASS] Error rate: {error_rate:.3f}% < 0.1%")
    else:
        print(f"[FAIL] Error rate: {error_rate:.3f}% >= 0.1%")

    p99 = total.get_response_time_percentile(0.99)
    if p99 < 15000:  # 15 seconds
        print(f"[PASS] P99 latency: {p99:.2f}ms < 15000ms")
    else:
        print(f"[FAIL] P99 latency: {p99:.2f}ms >= 15000ms")

    avg = total.avg_response_time
    if avg < 5000:  # 5 seconds
        print(f"[PASS] Avg latency: {avg:.2f}ms < 5000ms")
    else:
        print(f"[FAIL] Avg latency: {avg:.2f}ms >= 5000ms")

    print("=" * 60)


# Custom metrics collection
class CustomMetrics:
    """Collect custom metrics during test."""

    def __init__(self):
        self.ttfb_samples = []
        self.tenant_request_counts = {}

    def record_ttfb(self, ttfb_ms: float):
        self.ttfb_samples.append(ttfb_ms)

    def record_tenant_request(self, tenant_id: str):
        self.tenant_request_counts[tenant_id] = (
            self.tenant_request_counts.get(tenant_id, 0) + 1
        )

    def get_avg_ttfb(self) -> float:
        if not self.ttfb_samples:
            return 0
        return sum(self.ttfb_samples) / len(self.ttfb_samples)

    def get_ttfb_p95(self) -> float:
        if not self.ttfb_samples:
            return 0
        sorted_samples = sorted(self.ttfb_samples)
        idx = int(len(sorted_samples) * 0.95)
        return sorted_samples[idx]


custom_metrics = CustomMetrics()
