"""Unit tests for streaming handler Lambda function."""
import json
import pytest
from unittest.mock import MagicMock, patch, AsyncMock
from datetime import datetime

# Import after setting environment variables
import sys
sys.path.insert(0, "src")


class TestValidateRequest:
    """Tests for request validation."""

    def test_missing_tenant_id_header(self, sample_api_gateway_event):
        """Test validation fails without X-Tenant-ID header."""
        from src.handlers.streaming_handler import validate_request

        event = sample_api_gateway_event.copy()
        del event["headers"]["X-Tenant-ID"]

        is_valid, error = validate_request(event)

        assert is_valid is False
        assert error is not None
        assert error["statusCode"] == 400
        body = json.loads(error["body"])
        assert body["error"]["code"] == "INVALID_REQUEST"

    def test_empty_query(self, sample_api_gateway_event):
        """Test validation fails with empty query."""
        from src.handlers.streaming_handler import validate_request

        event = sample_api_gateway_event.copy()
        event["body"] = json.dumps({"query": ""})

        is_valid, error = validate_request(event)

        assert is_valid is False
        assert error is not None
        assert error["statusCode"] == 400
        body = json.loads(error["body"])
        assert body["error"]["code"] == "VALIDATION_ERROR"

    def test_query_too_long(self, sample_api_gateway_event):
        """Test validation fails when query exceeds max length."""
        from src.handlers.streaming_handler import validate_request

        event = sample_api_gateway_event.copy()
        event["body"] = json.dumps({"query": "x" * 11000})  # Over 10KB

        is_valid, error = validate_request(event)

        assert is_valid is False
        assert error is not None
        assert error["statusCode"] == 400

    def test_valid_request(self, sample_api_gateway_event):
        """Test validation passes for valid request."""
        from src.handlers.streaming_handler import validate_request

        is_valid, error = validate_request(sample_api_gateway_event)

        assert is_valid is True
        assert error is None

    def test_invalid_json_body(self, sample_api_gateway_event):
        """Test validation fails with invalid JSON body."""
        from src.handlers.streaming_handler import validate_request

        event = sample_api_gateway_event.copy()
        event["body"] = "not valid json"

        is_valid, error = validate_request(event)

        assert is_valid is False
        assert error is not None
        assert error["statusCode"] == 400


class TestCreateErrorResponse:
    """Tests for error response creation."""

    def test_error_response_structure(self):
        """Test error response has correct structure."""
        from src.handlers.streaming_handler import create_error_response
        from src.utils.constants import ErrorCodes

        response = create_error_response(
            status_code=400,
            error_code=ErrorCodes.VALIDATION_ERROR,
            message="Test error message",
            request_id="test-123",
        )

        assert response["statusCode"] == 400
        assert "X-Request-ID" in response["headers"]
        body = json.loads(response["body"])
        assert body["error"]["code"] == "VALIDATION_ERROR"
        assert body["error"]["message"] == "Test error message"
        assert "timestamp" in body["error"]


class TestCreateSuccessResponse:
    """Tests for success response creation."""

    def test_success_response_structure(self):
        """Test success response has correct structure."""
        from src.handlers.streaming_handler import create_success_response

        response = create_success_response(
            body={"response": "Hello", "sessionId": "sess-123"},
            request_id="req-456",
            correlation_id="corr-789",
        )

        assert response["statusCode"] == 200
        assert response["headers"]["X-Request-ID"] == "req-456"
        assert response["headers"]["X-Correlation-ID"] == "corr-789"
        assert "X-RateLimit-Limit" in response["headers"]


class TestCircuitBreaker:
    """Tests for circuit breaker functionality."""

    def test_circuit_starts_closed(self):
        """Test circuit breaker starts in closed state."""
        from src.handlers.streaming_handler import CircuitBreaker

        cb = CircuitBreaker()
        assert cb.state == "closed"
        assert cb.can_execute() is True

    def test_circuit_opens_after_failures(self):
        """Test circuit opens after threshold failures."""
        from src.handlers.streaming_handler import CircuitBreaker

        cb = CircuitBreaker(failure_threshold=3)

        for _ in range(3):
            cb.record_failure()

        assert cb.state == "open"
        assert cb.can_execute() is False

    def test_circuit_resets_on_success(self):
        """Test circuit resets to closed on success."""
        from src.handlers.streaming_handler import CircuitBreaker

        cb = CircuitBreaker(failure_threshold=3)
        cb.record_failure()
        cb.record_failure()
        cb.record_success()

        assert cb.state == "closed"
        assert cb.failures == 0


class TestObservability:
    """Tests for observability module."""

    def test_pii_redaction_ssn(self):
        """Test SSN is redacted."""
        from src.utils.observability import PIIRedactor

        redactor = PIIRedactor()
        text = "My SSN is 123-45-6789"

        result = redactor.redact(text)

        assert "123-45-6789" not in result
        assert "[REDACTED]" in result

    def test_pii_redaction_email(self):
        """Test email is redacted."""
        from src.utils.observability import PIIRedactor

        redactor = PIIRedactor()
        text = "Contact me at test@example.com"

        result = redactor.redact(text)

        assert "test@example.com" not in result
        assert "[REDACTED]" in result

    def test_pii_redaction_phone(self):
        """Test phone number is redacted."""
        from src.utils.observability import PIIRedactor

        redactor = PIIRedactor()
        text = "Call me at 555-123-4567"

        result = redactor.redact(text)

        assert "555-123-4567" not in result
        assert "[REDACTED]" in result

    def test_pii_redaction_dict(self):
        """Test PII redaction in dictionary."""
        from src.utils.observability import PIIRedactor

        redactor = PIIRedactor()
        data = {
            "name": "John",
            "email": "john@example.com",
            "nested": {
                "phone": "555-123-4567",
            },
        }

        result = redactor.redact_dict(data)

        assert result["name"] == "John"
        assert "john@example.com" not in result["email"]
        assert "555-123-4567" not in result["nested"]["phone"]


class TestConstants:
    """Tests for constants module."""

    def test_tenant_config_from_header(self):
        """Test TenantConfig creation from header."""
        from src.utils.constants import TenantConfig

        config = TenantConfig.from_header("tenant-123")

        assert config.tenant_id == "tenant-123"
        assert config.tenant_name == "tenant-tenant-123"
        assert config.rate_limit == 200

    def test_error_codes_values(self):
        """Test ErrorCodes enum values."""
        from src.utils.constants import ErrorCodes

        assert ErrorCodes.INVALID_REQUEST.value == "INVALID_REQUEST"
        assert ErrorCodes.RATE_LIMITED.value == "RATE_LIMITED"
        assert ErrorCodes.AGENT_ERROR.value == "AGENT_ERROR"


class TestHealthHandler:
    """Tests for health handler."""

    def test_health_handler_returns_healthy(self, lambda_context):
        """Test health handler returns healthy status."""
        from src.handlers.streaming_handler import health_handler

        event = {"httpMethod": "GET", "path": "/health"}

        response = health_handler(event, lambda_context)

        assert response["statusCode"] == 200
        body = json.loads(response["body"])
        assert body["status"] == "healthy"
        assert "version" in body
        assert "dependencies" in body


class TestStreamingHandler:
    """Integration tests for streaming handler."""

    @patch("src.handlers.streaming_handler.bedrock_agent_runtime")
    @patch("src.handlers.streaming_handler.sessions_table")
    @patch("src.handlers.streaming_handler.audit_table")
    def test_handler_success(
        self,
        mock_audit,
        mock_sessions,
        mock_bedrock,
        sample_api_gateway_event,
        lambda_context,
    ):
        """Test handler successfully processes request."""
        from src.handlers.streaming_handler import handler

        # Setup mocks
        mock_sessions.get_item.return_value = {}
        mock_sessions.put_item.return_value = {}
        mock_audit.put_item.return_value = {}

        mock_bedrock.invoke_agent.return_value = {
            "completion": [
                {"chunk": {"bytes": b"Hello, "}},
                {"chunk": {"bytes": b"how can I help?"}},
            ]
        }

        response = handler(sample_api_gateway_event, lambda_context)

        assert response["statusCode"] == 200
        body = json.loads(response["body"])
        assert "response" in body
        assert "sessionId" in body
        assert body["response"] == "Hello, how can I help?"

    @patch("src.handlers.streaming_handler.bedrock_agent_runtime")
    @patch("src.handlers.streaming_handler.sessions_table")
    @patch("src.handlers.streaming_handler.audit_table")
    def test_handler_missing_tenant_id(
        self,
        mock_audit,
        mock_sessions,
        mock_bedrock,
        sample_api_gateway_event,
        lambda_context,
    ):
        """Test handler rejects request without tenant ID."""
        from src.handlers.streaming_handler import handler

        event = sample_api_gateway_event.copy()
        del event["headers"]["X-Tenant-ID"]

        response = handler(event, lambda_context)

        assert response["statusCode"] == 400
        body = json.loads(response["body"])
        assert body["error"]["code"] == "INVALID_REQUEST"
