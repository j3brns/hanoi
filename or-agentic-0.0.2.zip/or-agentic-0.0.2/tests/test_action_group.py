"""Unit tests for action group Lambda function."""
import json
import pytest
from unittest.mock import MagicMock, patch, AsyncMock

import sys
sys.path.insert(0, "src")


class TestParseAgentRequest:
    """Tests for Bedrock Agent request parsing."""

    def test_parse_basic_request(self, sample_bedrock_agent_event):
        """Test parsing basic Bedrock Agent request."""
        from src.handlers.action_group import parse_agent_request

        result = parse_agent_request(sample_bedrock_agent_event)

        assert result["action_group"] == "AppointmentManagement"
        assert result["api_path"] == "/appointments"
        assert result["http_method"] == "GET"
        assert result["tenant_id"] == "tenant-123"
        assert result["jwt_token"] == "test-jwt-token"
        assert result["parameters"]["customerId"] == "cust-123"

    def test_parse_request_with_body(self, sample_bedrock_agent_event):
        """Test parsing request with body content."""
        from src.handlers.action_group import parse_agent_request

        event = sample_bedrock_agent_event.copy()
        event["requestBody"] = {
            "content": {
                "application/json": {
                    "properties": [
                        {"name": "slotId", "value": "slot-123"},
                        {"name": "description", "value": "Test booking"},
                    ]
                }
            }
        }

        result = parse_agent_request(event)

        assert result["body"]["slotId"] == "slot-123"
        assert result["body"]["description"] == "Test booking"


class TestCreateAgentResponse:
    """Tests for Bedrock Agent response creation."""

    def test_success_response(self):
        """Test creating success response."""
        from src.handlers.action_group import create_agent_response

        response = create_agent_response(
            action_group="AppointmentManagement",
            api_path="/appointments",
            http_method="GET",
            response_body={"appointments": [], "total": 0},
            status_code=200,
        )

        assert response["messageVersion"] == "1.0"
        assert response["response"]["httpStatusCode"] == 200
        assert response["response"]["actionGroup"] == "AppointmentManagement"

        body = json.loads(
            response["response"]["responseBody"]["application/json"]["body"]
        )
        assert body["total"] == 0

    def test_error_response(self):
        """Test creating error response."""
        from src.handlers.action_group import create_agent_response

        response = create_agent_response(
            action_group="AppointmentManagement",
            api_path="/appointments",
            http_method="POST",
            response_body={"success": False, "error": "Invalid slot"},
            status_code=400,
        )

        assert response["response"]["httpStatusCode"] == 400


class TestViewAppointments:
    """Tests for view appointments action."""

    @patch("src.handlers.action_group.call_external_api_sync")
    def test_view_appointments_success(self, mock_api):
        """Test viewing appointments successfully."""
        from src.handlers.action_group import view_appointments

        mock_api.return_value = {
            "appointments": [
                {"id": "apt-1", "date": "2026-01-10", "status": "confirmed"}
            ],
            "total": 1,
        }

        result = view_appointments(
            tenant_id="tenant-123",
            jwt_token="test-token",
            params={"customerId": "cust-123"},
        )

        assert result["total"] == 1
        assert len(result["appointments"]) == 1
        mock_api.assert_called_once()


class TestSearchAvailableSlots:
    """Tests for search available slots action."""

    @patch("src.handlers.action_group.call_external_api_sync")
    def test_search_slots_success(self, mock_api):
        """Test searching slots successfully."""
        from src.handlers.action_group import search_available_slots

        mock_api.return_value = {
            "slots": [
                {"id": "slot-1", "time": "2026-01-10T14:00:00Z"},
                {"id": "slot-2", "time": "2026-01-10T15:00:00Z"},
            ],
            "total": 2,
        }

        result = search_available_slots(
            tenant_id="tenant-123",
            jwt_token="test-token",
            params={"serviceType": "installation", "dateFrom": "2026-01-10"},
        )

        assert result["total"] == 2
        assert len(result["availableSlots"]) == 2


class TestBookAppointment:
    """Tests for book appointment action."""

    @patch("src.handlers.action_group.call_external_api_sync")
    def test_book_appointment_success(self, mock_api):
        """Test booking appointment successfully."""
        from src.handlers.action_group import book_appointment

        mock_api.return_value = {
            "success": True,
            "appointmentId": "apt-123",
            "confirmationNumber": "CONF-456",
            "scheduledTime": "2026-01-10T14:00:00Z",
        }

        result = book_appointment(
            tenant_id="tenant-123",
            jwt_token="test-token",
            body={
                "slotId": "slot-1",
                "customerId": "cust-123",
                "serviceType": "installation",
            },
        )

        assert result["success"] is True
        assert result["appointmentId"] == "apt-123"
        assert result["confirmationNumber"] == "CONF-456"

    def test_book_appointment_missing_required_fields(self):
        """Test booking fails with missing required fields."""
        from src.handlers.action_group import book_appointment

        result = book_appointment(
            tenant_id="tenant-123",
            jwt_token="test-token",
            body={"slotId": "slot-1"},  # Missing customerId and serviceType
        )

        assert result["success"] is False
        assert "error" in result


class TestRescheduleAppointment:
    """Tests for reschedule appointment action."""

    @patch("src.handlers.action_group.call_external_api_sync")
    def test_reschedule_success(self, mock_api):
        """Test rescheduling appointment successfully."""
        from src.handlers.action_group import reschedule_appointment

        mock_api.return_value = {
            "success": True,
            "newScheduledTime": "2026-01-11T14:00:00Z",
            "previousScheduledTime": "2026-01-10T14:00:00Z",
        }

        result = reschedule_appointment(
            tenant_id="tenant-123",
            jwt_token="test-token",
            body={
                "appointmentId": "apt-123",
                "newSlotId": "slot-2",
                "reason": "Customer requested",
            },
        )

        assert result["success"] is True
        assert result["appointmentId"] == "apt-123"

    def test_reschedule_missing_appointment_id(self):
        """Test reschedule fails without appointment ID."""
        from src.handlers.action_group import reschedule_appointment

        result = reschedule_appointment(
            tenant_id="tenant-123",
            jwt_token="test-token",
            body={"newSlotId": "slot-2"},
        )

        assert result["success"] is False


class TestCancelAppointment:
    """Tests for cancel appointment action."""

    @patch("src.handlers.action_group.call_external_api_sync")
    def test_cancel_success(self, mock_api):
        """Test cancelling appointment successfully."""
        from src.handlers.action_group import cancel_appointment

        mock_api.return_value = {
            "success": True,
            "cancellationId": "cancel-789",
        }

        result = cancel_appointment(
            tenant_id="tenant-123",
            jwt_token="test-token",
            body={"appointmentId": "apt-123", "reason": "No longer needed"},
        )

        assert result["success"] is True

    def test_cancel_missing_appointment_id(self):
        """Test cancel fails without appointment ID."""
        from src.handlers.action_group import cancel_appointment

        result = cancel_appointment(
            tenant_id="tenant-123",
            jwt_token="test-token",
            body={},
        )

        assert result["success"] is False


class TestActionGroupHandler:
    """Integration tests for action group handler."""

    @patch("src.handlers.action_group.audit_table")
    @patch("src.handlers.action_group.call_external_api_sync")
    def test_handler_view_appointments(
        self,
        mock_api,
        mock_audit,
        sample_bedrock_agent_event,
        lambda_context,
    ):
        """Test handler routes to view appointments correctly."""
        from src.handlers.action_group import handler

        mock_api.return_value = {"appointments": [], "total": 0}
        mock_audit.put_item.return_value = {}

        response = handler(sample_bedrock_agent_event, lambda_context)

        assert response["response"]["httpStatusCode"] == 200
        body = json.loads(
            response["response"]["responseBody"]["application/json"]["body"]
        )
        assert "appointments" in body

    @patch("src.handlers.action_group.audit_table")
    @patch("src.handlers.action_group.call_external_api_sync")
    def test_handler_book_appointment(
        self,
        mock_api,
        mock_audit,
        sample_bedrock_agent_event,
        lambda_context,
    ):
        """Test handler routes to book appointment correctly."""
        from src.handlers.action_group import handler

        event = sample_bedrock_agent_event.copy()
        event["apiPath"] = "/appointments"
        event["httpMethod"] = "POST"
        event["requestBody"] = {
            "content": {
                "application/json": {
                    "properties": [
                        {"name": "slotId", "value": "slot-1"},
                        {"name": "customerId", "value": "cust-123"},
                        {"name": "serviceType", "value": "installation"},
                    ]
                }
            }
        }

        mock_api.return_value = {
            "success": True,
            "appointmentId": "apt-123",
            "confirmationNumber": "CONF-456",
        }
        mock_audit.put_item.return_value = {}

        response = handler(event, lambda_context)

        assert response["response"]["httpStatusCode"] == 200
