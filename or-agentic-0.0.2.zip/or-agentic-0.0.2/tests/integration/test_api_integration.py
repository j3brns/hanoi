"""
Integration Tests for Telecom Virtual Assistant API

These tests run after Terraform apply to validate:
- API endpoint connectivity
- Streaming response functionality
- Multi-tenant request handling
- Authentication flow
- Error handling

Run after deployment with:
    pytest tests/integration/ -v --environment=dev
"""
import json
import os
import time
from typing import Any, Dict, Generator, Optional

import boto3
import httpx
import pytest
from botocore.exceptions import ClientError


# Configuration from environment
API_URL = os.environ.get("API_URL", "")
API_KEY = os.environ.get("API_KEY", "")
ENVIRONMENT = os.environ.get("ENVIRONMENT", "dev")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")


def pytest_addoption(parser):
    """Add custom command line options."""
    parser.addoption(
        "--environment",
        action="store",
        default="dev",
        help="Environment to test (dev, staging, prod)",
    )


@pytest.fixture(scope="session")
def environment(request) -> str:
    """Get environment from command line."""
    return request.config.getoption("--environment")


@pytest.fixture(scope="session")
def api_config(environment: str) -> Dict[str, str]:
    """
    Load API configuration from Terraform outputs.

    Retrieves the API URL and key from the deployed infrastructure.
    """
    # Try environment variables first
    if API_URL and API_KEY:
        return {
            "url": API_URL,
            "api_key": API_KEY,
        }

    # Fall back to reading from Terraform outputs file
    try:
        with open("terraform/outputs.json", "r") as f:
            outputs = json.load(f)
            return {
                "url": outputs.get("api_gateway_url", {}).get("value", ""),
                "api_key": os.environ.get("API_KEY", "test-key"),
            }
    except FileNotFoundError:
        pytest.skip("Terraform outputs not found - run after terraform apply")
    except json.JSONDecodeError:
        pytest.skip("Invalid Terraform outputs file")

    return {"url": "", "api_key": ""}


@pytest.fixture(scope="session")
def http_client() -> Generator[httpx.Client, None, None]:
    """Create HTTP client for integration tests."""
    with httpx.Client(timeout=60.0) as client:
        yield client


class TestHealthEndpoint:
    """Tests for the /health endpoint."""

    def test_health_check_returns_200(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Verify health endpoint returns 200 OK."""
        response = http_client.get(f"{api_config['url']}/health")

        assert response.status_code == 200
        data = response.json()
        assert data.get("status") == "healthy"

    def test_health_check_includes_version(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Verify health endpoint includes version info."""
        response = http_client.get(f"{api_config['url']}/health")

        assert response.status_code == 200
        data = response.json()
        assert "version" in data or "timestamp" in data


class TestApiAuthentication:
    """Tests for API authentication mechanisms."""

    def test_missing_api_key_returns_403(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Requests without API key should return 403."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={"Content-Type": "application/json"},
            json={"query": "test"},
        )

        assert response.status_code == 403

    def test_invalid_api_key_returns_403(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Requests with invalid API key should return 403."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": "invalid-key-12345",
            },
            json={"query": "test"},
        )

        assert response.status_code == 403

    def test_missing_tenant_id_returns_400(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Requests without tenant ID should return 400."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
            },
            json={"query": "test"},
        )

        # Should fail validation due to missing tenant ID
        assert response.status_code in [400, 403]


class TestAgentInvocation:
    """Tests for the /v1/agent/invoke endpoint."""

    def test_valid_request_returns_200(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Valid agent invocation should return 200."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "integration-test-tenant",
                "X-Correlation-ID": f"test-{int(time.time())}",
            },
            json={
                "query": "What services do you provide?",
                "sessionId": f"test-session-{int(time.time())}",
            },
            timeout=120.0,  # Allow time for Bedrock response
        )

        assert response.status_code == 200
        data = response.json()
        assert "response" in data or "sessionId" in data

    def test_response_includes_session_id(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Agent response should include session ID."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "integration-test-tenant",
            },
            json={"query": "Hello"},
            timeout=120.0,
        )

        if response.status_code == 200:
            data = response.json()
            assert "sessionId" in data

    def test_response_includes_metadata(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Agent response should include metadata."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "integration-test-tenant",
            },
            json={"query": "Show me appointments"},
            timeout=120.0,
        )

        if response.status_code == 200:
            data = response.json()
            # Metadata may include latency, response length, etc.
            assert "metadata" in data or "response" in data


class TestMultiTenantIsolation:
    """Tests for multi-tenant request isolation."""

    def test_different_tenants_get_isolated_sessions(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Different tenants should have isolated sessions."""
        # Request for tenant A
        response_a = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "tenant-a-integration",
            },
            json={"query": "Hello from tenant A"},
            timeout=120.0,
        )

        # Request for tenant B
        response_b = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "tenant-b-integration",
            },
            json={"query": "Hello from tenant B"},
            timeout=120.0,
        )

        if response_a.status_code == 200 and response_b.status_code == 200:
            data_a = response_a.json()
            data_b = response_b.json()

            # Sessions should be different
            if "sessionId" in data_a and "sessionId" in data_b:
                assert data_a["sessionId"] != data_b["sessionId"]


class TestRateLimiting:
    """Tests for WAF rate limiting."""

    def test_rate_limit_headers_present(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Verify rate limit headers are present."""
        response = http_client.get(f"{api_config['url']}/health")

        # WAF may add rate limit headers
        # This is informational - rate limits are enforced at WAF level
        assert response.status_code == 200


class TestStreamingResponse:
    """Tests for REST API streaming functionality."""

    def test_streaming_headers_present(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Verify streaming response headers are configured."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "streaming-test-tenant",
            },
            json={"query": "Test streaming"},
            timeout=120.0,
        )

        # Check for chunked transfer encoding or streaming indicators
        if response.status_code == 200:
            # Transfer-Encoding may be 'chunked' for streaming
            transfer_encoding = response.headers.get("Transfer-Encoding", "")
            content_type = response.headers.get("Content-Type", "")

            # At minimum, should have proper content type
            assert "application/json" in content_type


class TestLatencyRequirements:
    """Tests for latency SLA compliance."""

    def test_health_endpoint_latency(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Health endpoint should respond within 1 second."""
        start_time = time.time()
        response = http_client.get(f"{api_config['url']}/health")
        latency_ms = (time.time() - start_time) * 1000

        assert response.status_code == 200
        assert latency_ms < 1000, f"Health endpoint latency {latency_ms}ms exceeds 1000ms"

    def test_ttfb_under_target(
        self,
        api_config: Dict[str, str],
    ):
        """
        Time-to-first-byte should be under 500ms target.

        Uses streaming client to measure TTFB accurately.
        """
        start_time = time.time()
        ttfb = None

        with httpx.Client(timeout=120.0) as client:
            with client.stream(
                "POST",
                f"{api_config['url']}/v1/agent/invoke",
                headers={
                    "Content-Type": "application/json",
                    "X-API-Key": api_config["api_key"],
                    "X-Tenant-ID": "ttfb-test-tenant",
                },
                json={"query": "Quick response test"},
            ) as response:
                # TTFB is time until we start receiving the response
                ttfb = (time.time() - start_time) * 1000

                # Consume the response
                _ = response.read()

        if ttfb is not None and response.status_code == 200:
            # TTFB target is 500ms, but allow some variance in integration tests
            # Log the actual value for monitoring
            print(f"TTFB: {ttfb:.2f}ms")
            # Soft assertion - log warning if over target
            if ttfb > 500:
                print(f"WARNING: TTFB {ttfb:.2f}ms exceeds 500ms target")


class TestErrorHandling:
    """Tests for error handling and response codes."""

    def test_malformed_json_returns_400(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Malformed JSON should return 400."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "error-test-tenant",
            },
            content=b"{ invalid json }",
        )

        assert response.status_code == 400

    def test_empty_query_returns_400(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Empty query should return 400."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "error-test-tenant",
            },
            json={"query": ""},
        )

        assert response.status_code in [400, 422]


class TestBedrockAgentIntegration:
    """Tests for Bedrock Agent integration (requires agent to be prepared)."""

    @pytest.mark.slow
    def test_agent_responds_to_appointment_query(
        self,
        api_config: Dict[str, str],
        http_client: httpx.Client,
    ):
        """Agent should respond to appointment-related queries."""
        response = http_client.post(
            f"{api_config['url']}/v1/agent/invoke",
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_config["api_key"],
                "X-Tenant-ID": "agent-test-tenant",
            },
            json={
                "query": "What appointment slots are available tomorrow?",
            },
            timeout=120.0,
        )

        if response.status_code == 200:
            data = response.json()
            response_text = data.get("response", "").lower()

            # Agent should understand appointment context
            # This is a soft check - agent response may vary
            assert len(data.get("response", "")) > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
